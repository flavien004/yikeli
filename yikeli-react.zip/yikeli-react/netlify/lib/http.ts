// Réponses HTTP, erreurs applicatives et validation d'entrées.
export class HttpError extends Error {
  constructor(public status: number, public code: string, message?: string) {
    super(message ?? code);
  }
}

export const json = (data: unknown, status = 200, headers: Record<string, string> = {}): Response =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers },
  });

export async function readBody(req: Request, maxBytes: number): Promise<Record<string, unknown>> {
  if (req.method === 'GET' || req.method === 'DELETE') return {};
  const text = await req.text();
  if (!text) return {};
  if (text.length > maxBytes) throw new HttpError(413, 'payload_too_large', 'Requête trop volumineuse.');
  try {
    const body = JSON.parse(text);
    if (typeof body !== 'object' || body === null || Array.isArray(body)) throw new Error();
    return body as Record<string, unknown>;
  } catch {
    throw new HttpError(400, 'invalid_json', 'Corps de requête invalide.');
  }
}

const bad = (name: string, why: string) => new HttpError(400, 'invalid_input', `Champ « ${name} » invalide : ${why}.`);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export const v = {
  str(x: unknown, name: string, min = 1, max = 200): string {
    if (typeof x !== 'string') throw bad(name, 'texte attendu');
    const s = x.trim();
    if (s.length < min || s.length > max) throw bad(name, `entre ${min} et ${max} caractères`);
    return s;
  },
  optStr(x: unknown, name: string, max = 200): string | undefined {
    if (x === undefined || x === null || x === '') return undefined;
    return v.str(x, name, 1, max);
  },
  int(x: unknown, name: string, min: number, max: number): number {
    if (typeof x !== 'number' || !Number.isInteger(x) || x < min || x > max) throw bad(name, `entier entre ${min} et ${max}`);
    return x;
  },
  num(x: unknown, name: string, min: number, max: number): number {
    if (typeof x !== 'number' || !Number.isFinite(x) || x < min || x > max) throw bad(name, `nombre entre ${min} et ${max}`);
    return x;
  },
  bool(x: unknown, name: string): boolean {
    if (typeof x !== 'boolean') throw bad(name, 'booléen attendu');
    return x;
  },
  oneOf<T extends string>(x: unknown, name: string, list: readonly T[]): T {
    if (typeof x !== 'string' || !list.includes(x as T)) throw bad(name, `valeur parmi ${list.join(', ')}`);
    return x as T;
  },
  uuid(x: unknown, name: string): string {
    if (typeof x !== 'string' || !UUID.test(x)) throw bad(name, 'identifiant invalide');
    return x;
  },
  email(x: unknown): string {
    const s = v.str(x, 'email', 3, 254).toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) throw bad('email', 'format incorrect');
    return s;
  },
  date(x: unknown, name: string): string {
    const s = v.str(x, name, 10, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || Number.isNaN(Date.parse(s))) throw bad(name, 'format AAAA-MM-JJ');
    return s;
  },
  array(x: unknown, name: string, min: number, max: number): unknown[] {
    if (!Array.isArray(x) || x.length < min || x.length > max) throw bad(name, `liste de ${min} à ${max} éléments`);
    return x;
  },
  obj(x: unknown, name: string): Record<string, unknown> {
    if (typeof x !== 'object' || x === null || Array.isArray(x)) throw bad(name, 'objet attendu');
    return x as Record<string, unknown>;
  },
};

export const METHODS = ['ESPECE', 'WAVE', 'ORANGE_MONEY', 'DJAMO', 'MTN_MONEY'] as const;
export const ROLES = ['ADMIN', 'CHEF', 'CAISSIER'] as const;
export const CATEGORIES = ['PLATS_IVOIRIENS', 'BOISSONS'] as const;
