// Conversion lignes SQL (snake_case) → objets API (camelCase). Jamais de password_hash.
import type { Row } from './db';

export const toPlat = (r: Row) => ({
  id: r.id, name: r.name, price: r.price, category: r.category,
  isActive: r.is_active, isStocked: r.is_stocked, stock: r.stock, lowStockAlert: r.low_stock_alert,
  expirationDelay: r.expiration_delay ?? undefined, imageUrl: r.image_url ?? undefined,
});

/** Version publique : pas de niveaux de stock exacts. */
export const toPublicPlat = (r: Row) => {
  const stocked = !!r.is_stocked;
  return {
    id: r.id, name: r.name, price: r.price, category: r.category,
    imageUrl: r.image_url ?? undefined,
    available: !stocked || r.stock > 0,
    maxQty: stocked ? Math.min(r.stock, 100) : 100,
    lowStock: stocked && r.stock > 0 && r.stock <= r.low_stock_alert,
  };
};

export const toUser = (r: Row) => ({
  id: r.id, name: r.name, email: r.email, phone: r.phone ?? undefined, role: r.role, isActive: r.is_active,
});

export const toClient = (r: Row) => ({
  id: r.id, name: r.name, phone: r.phone ?? undefined, address: r.address ?? undefined,
  totalSpent: r.total_spent, createdAt: r.created_at,
});

export const toCommande = (r: Row) => ({
  id: r.id, clientId: r.client_id ?? undefined, clientName: r.client_name,
  clientPhone: r.client_phone ?? undefined, clientAddress: r.client_address ?? undefined,
  type: r.type, total: r.total, status: r.status, specs: r.specs ?? undefined,
  paymentPref: r.payment_pref ?? undefined, cancelReason: r.cancel_reason ?? undefined,
  createdAt: r.created_at,
  items: ((r.commande_items ?? []) as Row[]).map(i => ({
    id: i.id, platId: i.plat_id ?? '', platName: i.plat_name, quantity: i.quantity, unitPrice: i.unit_price,
  })),
});

export const toPaiement = (r: Row) => ({
  id: r.id, commandeId: r.commande_id, userId: r.user_id ?? '', amount: r.amount, method: r.method, createdAt: r.created_at,
});

export const toDepense = (r: Row) => ({
  id: r.id, category: r.category, description: r.description, amount: r.amount, date: r.date,
  ingredientMovementId: r.ingredient_movement_id ?? undefined,
});

export const toCategory = (r: Row) => ({ id: r.id, name: r.name, isSystem: r.is_system });

export const toMouvement = (r: Row) => ({
  id: r.id, date: r.date, type: r.type, libelle: r.libelle, montant: r.montant, source: 'manuel' as const,
});

export const toIngredient = (r: Row) => ({
  id: r.id, name: r.name, unit: r.unit, stock: Number(r.stock), lowStockAlert: Number(r.low_stock_alert),
  lastUnitCost: Number(r.last_unit_cost), supplier: r.supplier ?? undefined, isActive: r.is_active,
});

export const toIngredientMovement = (r: Row) => ({
  id: r.id, ingredientId: r.ingredient_id, type: r.type, quantity: Number(r.quantity),
  unitCost: r.unit_cost === null ? undefined : Number(r.unit_cost), supplier: r.supplier ?? undefined,
  note: r.note ?? undefined, stockAfter: Number(r.stock_after), createdAt: r.created_at,
});
