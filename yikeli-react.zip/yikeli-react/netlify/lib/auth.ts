// JWT d'accès (courte durée) + refresh token opaque (cookie HttpOnly, rotation).
import { SignJWT, jwtVerify } from 'jose';
import bcrypt from 'bcryptjs';
import { createHash, randomBytes } from 'node:crypto';
import { env } from './env';
import { HttpError } from './http';

export type Role = 'ADMIN' | 'CHEF' | 'CAISSIER';
export interface AuthUser { id: string; role: Role; name: string; }

export const REFRESH_COOKIE = 'yikeli_rt';
const ISSUER = 'yikeli';
const AUDIENCE = 'yikeli-api';
const key = () => new TextEncoder().encode(env.jwtSecret);

export async function signAccessToken(u: AuthUser): Promise<string> {
  return new SignJWT({ role: u.role, name: u.name })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(u.id)
    .setIssuer(ISSUER)
    .setAudience(AUDIENCE)
    .setIssuedAt()
    .setExpirationTime(`${env.accessTtl}s`)
    .sign(key());
}

export async function verifyAccessToken(token: string): Promise<AuthUser> {
  try {
    const { payload } = await jwtVerify(token, key(), {
      algorithms: ['HS256'], issuer: ISSUER, audience: AUDIENCE,
    });
    if (!payload.sub || !['ADMIN', 'CHEF', 'CAISSIER'].includes(String(payload.role))) throw new Error('claims');
    return { id: payload.sub, role: payload.role as Role, name: String(payload.name ?? '') };
  } catch {
    throw new HttpError(401, 'token_invalid', 'Session expirée ou invalide.');
  }
}

export const hashPassword = (pw: string): Promise<string> => bcrypt.hash(pw, 12);

let dummyHash: string | undefined;
/** Compare toujours un hash (même utilisateur inconnu) pour égaliser les temps de réponse. */
export async function verifyPassword(pw: string, hash: string | undefined): Promise<boolean> {
  if (!hash) {
    dummyHash ??= await bcrypt.hash('dummy-password-for-timing', 12);
    await bcrypt.compare(pw, dummyHash);
    return false;
  }
  return bcrypt.compare(pw, hash);
}

export const newRefreshToken = (): string => randomBytes(48).toString('base64url');
export const sha256 = (s: string): string => createHash('sha256').update(s).digest('hex');

export function refreshCookie(token: string): string {
  return `${REFRESH_COOKIE}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/api/auth; Max-Age=${env.refreshTtl}`;
}
export const clearRefreshCookie = (): string =>
  `${REFRESH_COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/api/auth; Max-Age=0`;

export function readCookie(req: Request, name: string): string | undefined {
  const header = req.headers.get('cookie');
  if (!header) return undefined;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return undefined;
}

export async function authenticate(req: Request): Promise<AuthUser> {
  const h = req.headers.get('authorization') ?? '';
  const m = /^Bearer (.+)$/.exec(h);
  if (!m) throw new HttpError(401, 'token_missing', 'Authentification requise.');
  return verifyAccessToken(m[1]);
}
