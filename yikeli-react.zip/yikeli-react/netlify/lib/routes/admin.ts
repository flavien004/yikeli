import { randomUUID } from 'node:crypto';
import { db, must, fromDb, type Row } from '../db';
import { env } from '../env';
import { hashPassword } from '../auth';
import { HttpError, v, ROLES, CATEGORIES } from '../http';
import { toPlat, toUser, toCategory, toMouvement, toIngredient, toDepense } from '../mappers';
import type { Route } from './types';

const UNITS_MAX = 20;

/** Construit un objet de mise à jour à partir des seuls champs fournis. */
function patch(body: Record<string, unknown>, spec: Record<string, (x: unknown) => unknown>): Row {
  const out: Row = {};
  for (const [column, check] of Object.entries(spec)) {
    const key = column.includes(':') ? column.split(':')[0] : column;
    const col = column.includes(':') ? column.split(':')[1] : column;
    if (key in body) out[col] = check(body[key]);
  }
  if (Object.keys(out).length === 0) throw new HttpError(400, 'invalid_input', 'Aucune modification fournie.');
  return out;
}

const storagePrefix = () => `${env.supabaseUrl}/storage/v1/object/public/${env.bucket}/`;
/** Supprime l'ancienne image si elle appartient à notre bucket (best effort). */
async function removeImage(url: string | null | undefined) {
  if (!url || !url.startsWith(storagePrefix())) return;
  await db().storage.from(env.bucket).remove([url.slice(storagePrefix().length)]).catch(() => undefined);
}

const MAGIC: Record<string, (b: Buffer) => boolean> = {
  'image/jpeg': b => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  'image/png': b => b.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47])),
  'image/webp': b => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP',
};
const EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

export const adminRoutes: Route[] = [
  // ── Images ────────────────────────────────────────────────
  {
    method: 'POST', path: '/api/admin/upload-image', access: 'admin', maxBody: 2_500_000,
    async handler({ body }) {
      const type = v.oneOf(body.contentType, 'type', ['image/jpeg', 'image/png', 'image/webp'] as const);
      const b64 = v.str(body.dataBase64, 'image', 10, 2_300_000);
      const buf = Buffer.from(b64, 'base64');
      if (buf.length > 1_500_000) throw new HttpError(413, 'too_large', 'Image trop lourde (1,5 Mo maximum).');
      if (!MAGIC[type](buf)) throw new HttpError(400, 'invalid_image', 'Le fichier n’est pas une image valide.');
      const path = `plats/${randomUUID()}.${EXT[type]}`;
      const up = await db().storage.from(env.bucket).upload(path, buf, {
        contentType: type, upsert: false, cacheControl: '31536000',
      });
      if (up.error) throw new HttpError(502, 'upload_failed', 'Échec de l’envoi de l’image.');
      return { url: db().storage.from(env.bucket).getPublicUrl(path).data.publicUrl };
    },
  },

  // ── Plats ─────────────────────────────────────────────────
  {
    method: 'POST', path: '/api/plats', access: 'admin', maxBody: 5_000,
    async handler({ body }) {
      const stocked = body.isStocked === undefined ? false : v.bool(body.isStocked, 'stock surveillé');
      const row = must(await db().from('plats').insert({
        name: v.str(body.name, 'nom', 1, 100),
        price: v.int(body.price, 'prix', 0, 10_000_000),
        category: v.oneOf(body.category ?? 'PLATS_IVOIRIENS', 'catégorie', CATEGORIES),
        is_active: body.isActive === undefined ? true : v.bool(body.isActive, 'actif'),
        is_stocked: stocked,
        stock: stocked ? v.int(body.stock ?? 0, 'stock', 0, 1_000_000) : 0,
        low_stock_alert: stocked ? v.int(body.lowStockAlert ?? 0, 'seuil', 0, 1_000_000) : 0,
        expiration_delay: v.optStr(body.expirationDelay, 'conservation', 100) ?? null,
        image_url: v.optStr(body.imageUrl, 'image', 500) ?? null,
      }).select('*').single());
      return toPlat(row);
    },
  },
  {
    method: 'PATCH', path: '/api/plats/:id', access: 'admin', maxBody: 5_000,
    async handler({ params, body }) {
      const id = v.uuid(params.id, 'plat');
      const update = patch(body, {
        name: x => v.str(x, 'nom', 1, 100),
        price: x => v.int(x, 'prix', 0, 10_000_000),
        category: x => v.oneOf(x, 'catégorie', CATEGORIES),
        'isActive:is_active': x => v.bool(x, 'actif'),
        'isStocked:is_stocked': x => v.bool(x, 'stock surveillé'),
        stock: x => v.int(x, 'stock', 0, 1_000_000),
        'lowStockAlert:low_stock_alert': x => v.int(x, 'seuil', 0, 1_000_000),
        'expirationDelay:expiration_delay': x => v.optStr(x, 'conservation', 100) ?? null,
        'imageUrl:image_url': x => v.optStr(x, 'image', 500) ?? null,
      });
      const before = must(await db().from('plats').select('image_url').eq('id', id).single());
      const row = must(await db().from('plats').update(update).eq('id', id).select('*').single());
      if ('image_url' in update && before.image_url !== update.image_url) await removeImage(before.image_url);
      return toPlat(row);
    },
  },
  {
    method: 'DELETE', path: '/api/plats/:id', access: 'admin',
    async handler({ params }) {
      const id = v.uuid(params.id, 'plat');
      const { data } = await db().from('plats').select('image_url').eq('id', id).maybeSingle();
      must(await db().from('plats').delete().eq('id', id));
      await removeImage(data?.image_url);
      return { ok: true };
    },
  },

  // ── Utilisateurs ──────────────────────────────────────────
  {
    method: 'POST', path: '/api/users', access: 'admin', maxBody: 2_000,
    async handler({ body }) {
      const password = v.str(body.password, 'mot de passe', 10, 200);
      const row = must(await db().from('users').insert({
        name: v.str(body.name, 'nom', 2, 100),
        email: v.email(body.email),
        phone: v.optStr(body.phone, 'téléphone', 30) ?? null,
        role: v.oneOf(body.role ?? 'CAISSIER', 'rôle', ROLES),
        is_active: true,
        password_hash: await hashPassword(password),
      }).select('*').single());
      return toUser(row);
    },
  },
  {
    method: 'PATCH', path: '/api/users/:id', access: 'admin', maxBody: 2_000,
    async handler({ params, body, user }) {
      const id = v.uuid(params.id, 'utilisateur');
      const update = patch(body, {
        name: x => v.str(x, 'nom', 2, 100),
        email: x => v.email(x),
        phone: x => v.optStr(x, 'téléphone', 30) ?? null,
        role: x => v.oneOf(x, 'rôle', ROLES),
        'isActive:is_active': x => v.bool(x, 'actif'),
      });
      if (id === user!.id && (update.is_active === false || (update.role && update.role !== 'ADMIN'))) {
        throw new HttpError(409, 'self_lockout', 'Vous ne pouvez pas désactiver ou rétrograder votre propre compte.');
      }
      // Réinitialisation du mot de passe (optionnelle) : le hash seul est stocké
      let revoke = update.is_active === false;
      if (typeof body.password === 'string' && body.password.length > 0) {
        update.password_hash = await hashPassword(v.str(body.password, 'mot de passe', 10, 200));
        revoke = true;
      }
      const row = must(await db().from('users').update(update).eq('id', id).select('*').single());
      if (revoke) {
        await db().from('refresh_tokens').update({ revoked_at: new Date().toISOString() })
          .eq('user_id', id).is('revoked_at', null);
      }
      return toUser(row);
    },
  },
  {
    method: 'DELETE', path: '/api/users/:id', access: 'admin',
    async handler({ params, user }) {
      const id = v.uuid(params.id, 'utilisateur');
      if (id === user!.id) throw new HttpError(409, 'self_lockout', 'Vous ne pouvez pas supprimer votre propre compte.');
      must(await db().from('users').delete().eq('id', id));
      return { ok: true };
    },
  },

  // ── Types de dépense ──────────────────────────────────────
  {
    method: 'POST', path: '/api/exp-categories', access: 'admin', maxBody: 500,
    async handler({ body }) {
      const row = must(await db().from('exp_categories').insert({ name: v.str(body.name, 'nom', 1, 60) }).select('*').single());
      return toCategory(row);
    },
  },
  {
    method: 'PATCH', path: '/api/exp-categories/:id', access: 'admin', maxBody: 500,
    async handler({ params, body }) {
      const id = v.uuid(params.id, 'type');
      const cur = must(await db().from('exp_categories').select('*').eq('id', id).single());
      if (cur.is_system) throw new HttpError(409, 'system_category', 'Ce type est protégé et ne peut pas être renommé.');
      const row = must(await db().from('exp_categories').update({ name: v.str(body.name, 'nom', 1, 60) }).eq('id', id).select('*').single());
      return toCategory(row); // les dépenses existantes suivent (ON UPDATE CASCADE)
    },
  },
  {
    method: 'DELETE', path: '/api/exp-categories/:id', access: 'admin',
    async handler({ params }) {
      const id = v.uuid(params.id, 'type');
      const cur = must(await db().from('exp_categories').select('*').eq('id', id).single());
      if (cur.is_system) throw new HttpError(409, 'system_category', 'Ce type est protégé et ne peut pas être supprimé.');
      const { error } = await db().from('exp_categories').delete().eq('id', id);
      if (error) {
        if (error.code === '23503') throw new HttpError(409, 'in_use', 'Ce type est utilisé par des dépenses : suppression impossible.');
        throw fromDb(error);
      }
      return { ok: true };
    },
  },

  // ── Dépenses (modification / suppression) ─────────────────
  {
    method: 'PATCH', path: '/api/expenses/:id', access: 'admin', maxBody: 2_000,
    async handler({ params, body }) {
      const update = patch(body, {
        category: x => v.str(x, 'catégorie', 1, 60),
        description: x => v.str(x, 'description', 1, 200),
        amount: x => v.int(x, 'montant', 1, 1_000_000_000),
        date: x => v.date(x, 'date'),
      });
      return toDepense(must(await db().from('depenses').update(update).eq('id', v.uuid(params.id, 'dépense')).select('*').single()));
    },
  },
  {
    method: 'DELETE', path: '/api/expenses/:id', access: 'admin',
    async handler({ params }) {
      must(await db().from('depenses').delete().eq('id', v.uuid(params.id, 'dépense')));
      return { ok: true };
    },
  },

  // ── Paiements & commandes (suppression sécurisée par fonctions SQL) ──
  {
    method: 'DELETE', path: '/api/payments/:id', access: 'admin',
    async handler({ params }) {
      const { error } = await db().rpc('delete_payment', { p_id: v.uuid(params.id, 'paiement') });
      if (error) throw fromDb(error);
      return { ok: true };
    },
  },
  {
    method: 'DELETE', path: '/api/orders/:id', access: 'admin',
    async handler({ params }) {
      const { error } = await db().rpc('delete_order', { p_id: v.uuid(params.id, 'commande') });
      if (error) throw fromDb(error);
      return { ok: true };
    },
  },

  // ── Journal : mouvements manuels & solde initial ──────────
  {
    method: 'POST', path: '/api/movements', access: 'admin', maxBody: 2_000,
    async handler({ body, user }) {
      const row = must(await db().from('mouvements_manuels').insert({
        date: v.date(body.date, 'date'),
        type: v.oneOf(body.type, 'type', ['RECETTE', 'DEPENSE'] as const),
        libelle: v.str(body.libelle, 'libellé', 1, 200),
        montant: v.int(body.montant, 'montant', 1, 1_000_000_000),
        created_by: user!.id,
      }).select('*').single());
      return toMouvement(row);
    },
  },
  {
    method: 'DELETE', path: '/api/movements/:id', access: 'admin',
    async handler({ params }) {
      must(await db().from('mouvements_manuels').delete().eq('id', v.uuid(params.id, 'mouvement')));
      return { ok: true };
    },
  },
  {
    method: 'PATCH', path: '/api/settings', access: 'admin', maxBody: 500,
    async handler({ body }) {
      const value = v.int(body.soldeInitial, 'solde initial', -1_000_000_000, 1_000_000_000);
      must(await db().from('app_settings').upsert({ key: 'solde_initial', value }));
      return { soldeInitial: value };
    },
  },

  // ── Ingrédients : fiche, approvisionnement, ajustement ────
  {
    method: 'POST', path: '/api/ingredients', access: 'admin', maxBody: 2_000,
    async handler({ body }) {
      const row = must(await db().from('ingredients').insert({
        name: v.str(body.name, 'nom', 1, 100),
        unit: v.str(body.unit, 'unité', 1, UNITS_MAX),
        low_stock_alert: v.num(body.lowStockAlert ?? 0, 'seuil', 0, 1_000_000),
        supplier: v.optStr(body.supplier, 'fournisseur', 100) ?? null,
      }).select('*').single());
      return toIngredient(row);
    },
  },
  {
    method: 'PATCH', path: '/api/ingredients/:id', access: 'admin', maxBody: 2_000,
    async handler({ params, body }) {
      const update = patch(body, {
        name: x => v.str(x, 'nom', 1, 100),
        unit: x => v.str(x, 'unité', 1, UNITS_MAX),
        'lowStockAlert:low_stock_alert': x => v.num(x, 'seuil', 0, 1_000_000),
        supplier: x => v.optStr(x, 'fournisseur', 100) ?? null,
        'isActive:is_active': x => v.bool(x, 'actif'),
      });
      return toIngredient(must(await db().from('ingredients').update(update).eq('id', v.uuid(params.id, 'ingrédient')).select('*').single()));
    },
  },
  {
    method: 'DELETE', path: '/api/ingredients/:id', access: 'admin',
    async handler({ params }) {
      const { error } = await db().from('ingredients').delete().eq('id', v.uuid(params.id, 'ingrédient'));
      if (error) {
        if (error.code === '23503') throw new HttpError(409, 'in_use', 'Cet ingrédient a un historique : archivez-le plutôt.');
        throw fromDb(error);
      }
      return { ok: true };
    },
  },
  {
    method: 'POST', path: '/api/ingredients/:id/supply', access: 'admin', maxBody: 2_000,
    async handler({ params, body, user }) {
      const { error } = await db().rpc('supply_ingredient', {
        p_ingredient: v.uuid(params.id, 'ingrédient'),
        p_qty: v.num(body.quantity, 'quantité', 0.001, 1_000_000),
        p_unit_cost: v.num(body.unitCost ?? 0, 'coût unitaire', 0, 100_000_000),
        p_supplier: v.optStr(body.supplier, 'fournisseur', 100) ?? '',
        p_note: v.optStr(body.note, 'note', 300) ?? '',
        p_user: user!.id,
        p_record_expense: body.recordExpense === undefined ? true : v.bool(body.recordExpense, 'dépense'),
      });
      if (error) throw fromDb(error);
      return { ok: true };
    },
  },
  {
    method: 'POST', path: '/api/ingredients/:id/adjust', access: 'admin', maxBody: 2_000,
    async handler({ params, body, user }) {
      const { error } = await db().rpc('adjust_ingredient', {
        p_ingredient: v.uuid(params.id, 'ingrédient'),
        p_delta: v.num(body.delta, 'variation', -1_000_000, 1_000_000),
        p_note: v.str(body.note, 'motif', 3, 300),
        p_user: user!.id,
      });
      if (error) throw fromDb(error);
      return { ok: true };
    },
  },
];
