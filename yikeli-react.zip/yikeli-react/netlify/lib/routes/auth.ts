import { db, must, type Row } from '../db';
import { HttpError, json, v } from '../http';
import {
  signAccessToken, verifyPassword, newRefreshToken, sha256, refreshCookie, clearRefreshCookie,
  readCookie, REFRESH_COOKIE,
} from '../auth';
import { env } from '../env';
import { toUser } from '../mappers';
import type { Route } from './types';

const MAX_ATTEMPTS = 5;
const WINDOW_MS = 15 * 60 * 1000;

async function openSession(user: Row, req: Request, rawRefresh: string, headers: Record<string, string>) {
  const accessToken = await signAccessToken({ id: user.id, role: user.role, name: user.name });
  return json({ accessToken, expiresIn: env.accessTtl, user: toUser(user) }, 200, headers);
}

const denied = (code: string, message: string) =>
  json({ error: { code, message } }, 401, { 'set-cookie': clearRefreshCookie() });

export const authRoutes: Route[] = [
  {
    method: 'POST', path: '/api/auth/login', access: 'public', maxBody: 2_000,
    async handler({ req, body, ip }) {
      const email = v.email(body.email);
      const password = v.str(body.password, 'mot de passe', 1, 200);

      // Anti force brute : 5 échecs / 15 min par email (compteur en base, valable entre instances)
      const since = new Date(Date.now() - WINDOW_MS).toISOString();
      const attempts = await db().from('login_attempts').select('id', { count: 'exact', head: true })
        .eq('email', email).gte('created_at', since);
      if ((attempts.count ?? 0) >= MAX_ATTEMPTS) {
        throw new HttpError(429, 'too_many_attempts', 'Trop de tentatives. Réessayez dans 15 minutes.');
      }

      const { data: user } = await db().from('users').select('*').eq('email', email).maybeSingle();
      const ok = await verifyPassword(password, user?.password_hash);
      if (!user || !ok || !user.is_active) {
        await db().from('login_attempts').insert({ email, ip });
        throw new HttpError(401, 'invalid_credentials', 'Email ou mot de passe incorrect.');
      }

      await db().from('login_attempts').delete().eq('email', email);
      // Ménage best-effort des anciens jetons
      await db().from('refresh_tokens').delete().lt('expires_at', new Date(Date.now() - 30 * 864e5).toISOString());

      const raw = newRefreshToken();
      must(await db().from('refresh_tokens').insert({
        user_id: user.id, token_hash: sha256(raw),
        expires_at: new Date(Date.now() + env.refreshTtl * 1000).toISOString(),
        user_agent: (req.headers.get('user-agent') ?? '').slice(0, 300),
      }));
      return openSession(user, req, raw, { 'set-cookie': refreshCookie(raw) });
    },
  },

  {
    method: 'POST', path: '/api/auth/refresh', access: 'public', maxBody: 100,
    async handler({ req }) {
      const old = readCookie(req, REFRESH_COOKIE);
      if (!old) return denied('no_refresh', 'Session expirée, reconnectez-vous.');

      const fresh = newRefreshToken();
      const { data, error } = await db().rpc('rotate_refresh_token', {
        p_old_hash: sha256(old), p_new_hash: sha256(fresh),
        p_expires: new Date(Date.now() + env.refreshTtl * 1000).toISOString(),
        p_ua: (req.headers.get('user-agent') ?? '').slice(0, 300),
      });
      if (error) throw new HttpError(500, 'db_error', 'Erreur serveur.');
      const row = (data as Array<{ out_user_id: string | null; out_outcome: string }>)?.[0];
      if (!row || row.out_outcome !== 'ok' || !row.out_user_id) {
        return denied(row?.out_outcome ?? 'invalid', 'Session expirée, reconnectez-vous.');
      }

      const { data: user } = await db().from('users').select('*').eq('id', row.out_user_id).maybeSingle();
      if (!user || !user.is_active) {
        await db().from('refresh_tokens').update({ revoked_at: new Date().toISOString() })
          .eq('user_id', row.out_user_id).is('revoked_at', null);
        return denied('inactive', 'Compte désactivé.');
      }
      return openSession(user, req, fresh, { 'set-cookie': refreshCookie(fresh) });
    },
  },

  {
    method: 'POST', path: '/api/auth/logout', access: 'public', maxBody: 100,
    async handler({ req }) {
      const raw = readCookie(req, REFRESH_COOKIE);
      if (raw) {
        await db().from('refresh_tokens').update({ revoked_at: new Date().toISOString() })
          .eq('token_hash', sha256(raw)).is('revoked_at', null);
      }
      return json({ ok: true }, 200, { 'set-cookie': clearRefreshCookie() });
    },
  },

  {
    method: 'GET', path: '/api/auth/me', access: 'staff',
    async handler({ user }) {
      const { data } = await db().from('users').select('*').eq('id', user!.id).maybeSingle();
      if (!data || !data.is_active) throw new HttpError(401, 'inactive', 'Compte désactivé.');
      return { user: toUser(data) };
    },
  },
];
