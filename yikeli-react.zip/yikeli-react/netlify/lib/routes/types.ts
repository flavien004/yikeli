import type { AuthUser } from '../auth';

export interface Ctx {
  req: Request;
  params: Record<string, string>;
  body: Record<string, unknown>;
  user: AuthUser | null;
  ip: string;
}
export type Access = 'public' | 'staff' | 'admin';
export interface Route {
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  path: string;
  access: Access;
  maxBody?: number;
  handler: (c: Ctx) => Promise<Response | unknown>;
}
