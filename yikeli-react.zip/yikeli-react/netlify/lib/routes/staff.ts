import { db, must, fromDb, type Row } from '../db';
import { HttpError, v, METHODS } from '../http';
import {
  toPlat, toUser, toClient, toCommande, toPaiement, toDepense, toCategory,
  toMouvement, toIngredient, toIngredientMovement,
} from '../mappers';
import type { Route } from './types';

const days = (n: number) => new Date(Date.now() - n * 864e5).toISOString();

async function fetchCommande(id: string) {
  return toCommande(must(await db().from('commandes').select('*, commande_items(*)').eq('id', id).single()));
}

export const staffRoutes: Route[] = [
  {
    // Données initiales, limitées selon le rôle (un employé ne reçoit ni utilisateurs, ni finances globales)
    method: 'GET', path: '/api/bootstrap', access: 'staff',
    async handler({ user }) {
      const admin = user!.role === 'ADMIN';
      const since = days(admin ? 180 : 14);

      const [plats, commandes, paiements, depenses, cats] = await Promise.all([
        db().from('plats').select('*').order('category').order('name'),
        db().from('commandes').select('*, commande_items(*)').gte('created_at', since).order('created_at', { ascending: false }).limit(1000),
        db().from('paiements').select('*, commandes!inner(created_at)').gte('commandes.created_at', since).limit(5000),
        admin
          ? db().from('depenses').select('*').gte('date', since.slice(0, 10)).order('date', { ascending: false }).limit(2000)
          : db().from('depenses').select('*').eq('category', 'Provisions').order('date', { ascending: false }).limit(100),
        db().from('exp_categories').select('*').order('name'),
      ]);

      const base = {
        user: { id: user!.id, name: user!.name, role: user!.role },
        plats: must(plats).map(toPlat),
        commandes: must(commandes).map(toCommande),
        paiements: must(paiements).map(toPaiement),
        depenses: must(depenses).map(toDepense),
        expCategories: must<Row[]>(cats).filter((c: Row) => admin || c.name === 'Provisions').map(toCategory),
      };
      if (!admin) {
        return { ...base, users: [], clients: [], mouvementsManuel: [], ingredients: [], ingredientMovements: [], soldeInitial: 0 };
      }

      const [users, clients, mouv, ings, movs, settings] = await Promise.all([
        db().from('users').select('*').order('name'),
        db().from('clients').select('*').order('created_at', { ascending: false }).limit(2000),
        db().from('mouvements_manuels').select('*').order('date', { ascending: false }).limit(1000),
        db().from('ingredients').select('*').order('name'),
        db().from('ingredient_movements').select('*').order('created_at', { ascending: false }).limit(300),
        db().from('app_settings').select('*').eq('key', 'solde_initial').maybeSingle(),
      ]);
      return {
        ...base,
        users: must(users).map(toUser),
        clients: must(clients).map(toClient),
        mouvementsManuel: must(mouv).map(toMouvement),
        ingredients: must(ings).map(toIngredient),
        ingredientMovements: must(movs).map(toIngredientMovement),
        soldeInitial: Number(settings.data?.value ?? 0),
      };
    },
  },

  {
    method: 'POST', path: '/api/orders', access: 'staff', maxBody: 20_000,
    async handler({ body, user }) {
      const type = v.oneOf(body.type ?? 'SUR_PLACE', 'type', ['SUR_PLACE', 'LIVRAISON'] as const);
      const items = v.array(body.items, 'articles', 1, 50).map((raw, i) => {
        const it = v.obj(raw, `article ${i + 1}`);
        return { plat_id: v.uuid(it.platId, 'plat'), quantity: v.int(it.quantity, 'quantité', 1, 100) };
      });
      const payments = v.array(body.payments ?? [], 'paiements', 0, 10).map((raw, i) => {
        const p = v.obj(raw, `paiement ${i + 1}`);
        return { method: v.oneOf(p.method, 'mode', METHODS), amount: v.int(p.amount, 'montant', 1, 100_000_000) };
      });
      const { data, error } = await db().rpc('create_order', {
        p: {
          client_name: v.optStr(body.clientName, 'client', 100) ?? '',
          client_phone: v.optStr(body.clientPhone, 'téléphone', 30) ?? '',
          client_address: v.optStr(body.clientAddress, 'adresse', 200) ?? '',
          specs: v.optStr(body.specs, 'spécifications', 500) ?? '',
          type, items, payments, cashier_id: user!.id,
        },
      });
      if (error) throw fromDb(error);
      return fetchCommande(data as string);
    },
  },

  {
    method: 'POST', path: '/api/payments', access: 'staff', maxBody: 1_000,
    async handler({ body, user }) {
      const { data, error } = await db().rpc('add_payment', {
        p_commande: v.uuid(body.commandeId, 'commande'),
        p_method: v.oneOf(body.method, 'mode', METHODS),
        p_amount: v.int(body.amount, 'montant', 1, 100_000_000),
        p_user: user!.id,
      });
      if (error) throw fromDb(error);
      return data;
    },
  },

  {
    method: 'PATCH', path: '/api/orders/:id/status', access: 'staff', maxBody: 1_000,
    async handler({ params, body, user }) {
      const id = v.uuid(params.id, 'commande');
      const status = v.oneOf(body.status, 'statut', ['ACCEPTEE', 'SERVIE', 'ANNULEE'] as const);
      if (status === 'ANNULEE') {
        if (user!.role !== 'ADMIN') throw new HttpError(403, 'forbidden', 'Seul un administrateur peut annuler une commande.');
        const { error } = await db().rpc('cancel_order', { p_id: id, p_reason: v.str(body.reason, 'motif', 3, 300) });
        if (error) throw fromDb(error);
      } else {
        const { error } = await db().rpc('set_order_status', { p_id: id, p_status: status });
        if (error) throw fromDb(error);
      }
      return fetchCommande(id);
    },
  },

  {
    // Un employé ne peut enregistrer QUE des dépenses de catégorie « Provisions »
    method: 'POST', path: '/api/expenses', access: 'staff', maxBody: 2_000,
    async handler({ body, user }) {
      const category = v.str(body.category, 'catégorie', 1, 60);
      if (user!.role !== 'ADMIN' && category !== 'Provisions') {
        throw new HttpError(403, 'forbidden', 'Vous ne pouvez enregistrer que des dépenses de provisions.');
      }
      const row = must(await db().from('depenses').insert({
        category,
        description: v.str(body.description, 'description', 1, 200),
        amount: v.int(body.amount, 'montant', 1, 1_000_000_000),
        date: v.date(body.date, 'date'),
        created_by: user!.id,
      }).select('*').single());
      return toDepense(row);
    },
  },
];
