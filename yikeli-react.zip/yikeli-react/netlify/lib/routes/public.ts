import { db, must, fromDb } from '../db';
import { HttpError, v, METHODS } from '../http';
import { toCommande, toPublicPlat } from '../mappers';
import type { Route } from './types';

export const publicRoutes: Route[] = [
  { method: 'GET', path: '/api/health', access: 'public', handler: async () => ({ ok: true }) },

  {
    method: 'GET', path: '/api/public/menu', access: 'public',
    async handler() {
      const rows = must(await db().from('plats').select('*').eq('is_active', true).order('category').order('name'));
      return { plats: rows.map(toPublicPlat) };
    },
  },

  {
    // Commande en ligne : les prix, le stock et le total sont recalculés par la base.
    method: 'POST', path: '/api/public/orders', access: 'public', maxBody: 10_000,
    async handler({ body }) {
      const name = v.str(body.clientName, 'nom', 2, 100);
      const phone = v.str(body.clientPhone, 'téléphone', 6, 30);
      if (!/^[+0-9 ()-]+$/.test(phone)) throw new HttpError(400, 'invalid_input', 'Numéro de téléphone invalide.');
      const address = v.optStr(body.clientAddress, 'adresse', 200);
      const specs = v.optStr(body.specs, 'spécifications', 500);
      const pref = body.paymentPref ? v.oneOf(body.paymentPref, 'paiement', METHODS) : undefined;
      const items = v.array(body.items, 'articles', 1, 50).map((raw, i) => {
        const it = v.obj(raw, `article ${i + 1}`);
        return { plat_id: v.uuid(it.platId, 'plat'), quantity: v.int(it.quantity, 'quantité', 1, 100) };
      });

      // Anti-spam : 5 commandes en ligne / heure / numéro
      const since = new Date(Date.now() - 3600_000).toISOString();
      const recent = await db().from('commandes').select('id', { count: 'exact', head: true })
        .eq('client_phone', phone).eq('type', 'EN_LIGNE').gte('created_at', since);
      if ((recent.count ?? 0) >= 5) {
        throw new HttpError(429, 'too_many_orders', 'Trop de commandes récentes avec ce numéro. Appelez le restaurant.');
      }

      const { data, error } = await db().rpc('create_order', {
        p: {
          client_name: name, client_phone: phone, client_address: address ?? '', specs: specs ?? '',
          type: 'EN_LIGNE', payment_pref: pref ?? '', items,
        },
      });
      if (error) throw fromDb(error);
      // On ne renvoie au client que ce dont il a besoin
      const cmd = must(await db().from('commandes').select('*, commande_items(*)').eq('id', data as string).single());
      const dto = toCommande(cmd);
      return { id: dto.id, total: dto.total, status: dto.status, items: dto.items };
    },
  },
];
