import { db, must, check, fromDb } from '../db';
import { env, ConfigError } from '../env';
import { json } from '../http';
import { HttpError, v, METHODS } from '../http';
import { toCommande, toPublicPlat } from '../mappers';
import type { Route } from './types';

export const publicRoutes: Route[] = [
  { method: 'GET', path: '/api/health', access: 'public', handler: async () => ({ ok: true }) },

  {
    // Diagnostic : 1 URL pour savoir ce qui manque. Aucune valeur secrète n'est renvoyée, seulement des états.
    method: 'GET', path: '/api/health/db', access: 'public',
    async handler() {
      const checks: Record<string, string> = {};
      const run = async (name: string, fn: () => Promise<unknown> | unknown) => {
        try { await fn(); checks[name] = 'ok'; }
        catch (e) { checks[name] = e instanceof HttpError || e instanceof ConfigError ? e.message : 'erreur inattendue (voir les logs Netlify)'; }
      };
      await run('variable SUPABASE_URL', () => env.supabaseUrl);
      await run('variable SUPABASE_SERVICE_ROLE_KEY', () => env.serviceKey);
      await run('variable JWT_SECRET', () => env.jwtSecret);
      for (const t of ['plats', 'users', 'refresh_tokens', 'commandes']) {
        await run(`table ${t}`, async () => { check(await db().from(t).select('id', { count: 'exact' }).limit(1)); });
      }
      await run('fonction rotate_refresh_token', async () => {
        const { data, error } = await db().rpc('rotate_refresh_token', {
          p_old_hash: 'healthcheck', p_new_hash: 'healthcheck-2', p_expires: new Date().toISOString(), p_ua: 'health',
        });
        if (error) throw fromDb(error);
        if ((data as Array<{ out_outcome: string }>)?.[0]?.out_outcome !== 'invalid') throw new HttpError(500, 'db_schema', 'résultat inattendu');
      });
      const ok = Object.values(checks).every(v => v === 'ok');
      return json({ ok, checks }, ok ? 200 : 503);
    },
  },

  {
    method: 'GET', path: '/api/public/menu', access: 'public',
    async handler() {
      const rows = must(await db().from('plats').select('*').eq('is_active', true).order('category').order('name'));
      return { plats: rows.map(toPublicPlat) };
    },
  },

  {
    // Commande en ligne : les prix, le stock et le total sont recalculés par la base.
    method: 'POST', path: '/api/public/orders', access: 'public', maxBody: 10_000,
    async handler({ body }) {
      const name = v.str(body.clientName, 'nom', 2, 100);
      const phone = v.str(body.clientPhone, 'téléphone', 6, 30);
      if (!/^[+0-9 ()-]+$/.test(phone)) throw new HttpError(400, 'invalid_input', 'Numéro de téléphone invalide.');
      const address = v.optStr(body.clientAddress, 'adresse', 200);
      const specs = v.optStr(body.specs, 'spécifications', 500);
      const pref = body.paymentPref ? v.oneOf(body.paymentPref, 'paiement', METHODS) : undefined;
      const items = v.array(body.items, 'articles', 1, 50).map((raw, i) => {
        const it = v.obj(raw, `article ${i + 1}`);
        return { plat_id: v.uuid(it.platId, 'plat'), quantity: v.int(it.quantity, 'quantité', 1, 100) };
      });

      // Anti-spam : 5 commandes en ligne / heure / numéro
      const since = new Date(Date.now() - 3600_000).toISOString();
      const recent = check(await db().from('commandes').select('id', { count: 'exact' })
        .eq('client_phone', phone).eq('type', 'EN_LIGNE').gte('created_at', since).limit(1));
      if ((recent.count ?? 0) >= 5) {
        throw new HttpError(429, 'too_many_orders', 'Trop de commandes récentes avec ce numéro. Appelez le restaurant.');
      }

      const { data, error } = await db().rpc('create_order', {
        p: {
          client_name: name, client_phone: phone, client_address: address ?? '', specs: specs ?? '',
          type: 'EN_LIGNE', payment_pref: pref ?? '', items,
        },
      });
      if (error) throw fromDb(error);
      // On ne renvoie au client que ce dont il a besoin
      const cmd = must(await db().from('commandes').select('*, commande_items(*)').eq('id', data as string).single());
      const dto = toCommande(cmd);
      return { id: dto.id, total: dto.total, status: dto.status, items: dto.items };
    },
  },
];
