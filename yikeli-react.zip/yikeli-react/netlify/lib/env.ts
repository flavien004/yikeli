// Lecture paresseuse des variables d'environnement, avec erreurs de configuration explicites.
// Les valeurs ne sont jamais affichées : seuls les NOMS de variables apparaissent dans les messages.
export class ConfigError extends Error {
  constructor(public variable: string, message: string) { super(message); }
}

/** Retire espaces, retours à la ligne et guillemets collés par erreur autour de la valeur. */
const clean = (v: string) => v.trim().replace(/^(['"])(.*)\1$/s, '$2').trim();

const need = (key: string): string => {
  const raw = process.env[key];
  const v = raw ? clean(raw) : '';
  if (!v) throw new ConfigError(key, `variable ${key} manquante (à définir dans Netlify, puis redéployer le site).`);
  return v;
};

export const env = {
  get supabaseUrl(): string {
    const raw = need('SUPABASE_URL');
    const bad = new ConfigError('SUPABASE_URL', 'SUPABASE_URL invalide : elle doit ressembler à https://xxxx.supabase.co (avec https://).');
    let u: URL;
    try { u = new URL(raw); } catch { throw bad; }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') throw bad;
    return u.origin;            // ignore un éventuel « /rest/v1 » ou « / » collé à la fin
  },
  get serviceKey(): string { return need('SUPABASE_SERVICE_ROLE_KEY'); },
  get jwtSecret(): string {
    const s = need('JWT_SECRET');
    if (s.length < 32) throw new ConfigError('JWT_SECRET', 'JWT_SECRET trop court : 32 caractères minimum.');
    return s;
  },
  get bucket(): string { return process.env.SUPABASE_BUCKET ? clean(process.env.SUPABASE_BUCKET) : 'product-images'; },
  get accessTtl(): number { return Number(process.env.ACCESS_TOKEN_TTL_SECONDS || 900); },
  get refreshTtl(): number { return Number(process.env.REFRESH_TOKEN_TTL_SECONDS || 604800); },
};
