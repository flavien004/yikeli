// Lecture paresseuse des variables d'environnement (erreur claire si absente).
const need = (key: string): string => {
  const v = process.env[key];
  if (!v) throw new Error(`Variable d’environnement manquante : ${key}`);
  return v;
};

export const env = {
  get supabaseUrl() { return need('SUPABASE_URL'); },
  get serviceKey() { return need('SUPABASE_SERVICE_ROLE_KEY'); },
  get jwtSecret() {
    const s = need('JWT_SECRET');
    if (s.length < 32) throw new Error('JWT_SECRET doit contenir au moins 32 caractères');
    return s;
  },
  get bucket() { return process.env.SUPABASE_BUCKET || 'product-images'; },
  get accessTtl() { return Number(process.env.ACCESS_TOKEN_TTL_SECONDS || 900); },
  get refreshTtl() { return Number(process.env.REFRESH_TOKEN_TTL_SECONDS || 604800); },
};
