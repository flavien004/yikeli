import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { env } from './env';
import { HttpError } from './http';

export type Row = Record<string, any>;

let client: SupabaseClient | null = null;
/** Client Supabase avec la clé service_role : à n'utiliser que côté serveur. */
export const db = (): SupabaseClient =>
  (client ??= createClient(env.supabaseUrl, env.serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  }));

const KNOWN: Record<string, [number, string]> = {
  plat_unavailable: [409, 'Ce plat n’est plus disponible.'],
  invalid_items: [400, 'La commande doit contenir de 1 à 50 articles.'],
  invalid_quantity: [400, 'Quantité invalide.'],
  invalid_type: [400, 'Type de commande invalide.'],
  invalid_amount: [400, 'Montant invalide.'],
  invalid_method: [400, 'Mode de paiement invalide.'],
  invalid_status: [400, 'Statut invalide.'],
  invalid_transition: [409, 'Cette commande ne peut plus changer de statut.'],
  order_not_found: [404, 'Commande introuvable.'],
  order_cancelled: [409, 'Cette commande est annulée.'],
  already_paid: [409, 'Cette commande est déjà entièrement payée.'],
  already_cancelled: [409, 'Cette commande est déjà annulée.'],
  order_has_payments: [409, 'Cette commande a des paiements : supprimez-les d’abord (remboursement).'],
  payment_not_found: [404, 'Paiement introuvable.'],
  ingredient_not_found: [404, 'Ingrédient introuvable.'],
  stock_negative: [409, 'Le stock ne peut pas devenir négatif.'],
  note_required: [400, 'Un motif est obligatoire pour un ajustement.'],
};

/** Traduit une erreur PostgreSQL / PostgREST en erreur HTTP lisible. */
export function fromDb(error: { message: string; code?: string }): HttpError {
  const m = error.message ?? '';
  if (m.includes('stock_insufficient')) {
    const name = m.split('stock_insufficient:')[1]?.trim();
    return new HttpError(409, 'stock_insufficient', `Stock insuffisant${name ? ` : ${name}` : ''}.`);
  }
  for (const [key, [status, message]] of Object.entries(KNOWN)) {
    if (m.includes(key)) return new HttpError(status, key, message);
  }
  if (error.code === '23505') return new HttpError(409, 'duplicate', 'Cet élément existe déjà.');
  if (error.code === '23503') return new HttpError(409, 'in_use', 'Cet élément est utilisé ailleurs : suppression impossible.');
  console.error('[db]', error);
  return new HttpError(500, 'db_error', 'Erreur serveur.');
}

// Client non typé (pas de génération de types) : les lignes sont des Row, validées par le schéma SQL.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function must<T = any>(r: { data: unknown; error: { message: string; code?: string } | null }): T {
  if (r.error) throw fromDb(r.error);
  return r.data as T;
}
