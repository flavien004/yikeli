// ============================================================
// YIKÉLI — API unique (Netlify Function v2) montée sur /api/*
// ============================================================
import type { Config, Context } from '@netlify/functions';
import { authenticate } from '../lib/auth';
import { HttpError, json, readBody } from '../lib/http';
import { ConfigError } from '../lib/env';
import { authRoutes } from '../lib/routes/auth';
import { publicRoutes } from '../lib/routes/public';
import { staffRoutes } from '../lib/routes/staff';
import { adminRoutes } from '../lib/routes/admin';
import type { Route } from '../lib/routes/types';

const routes: Route[] = [...publicRoutes, ...authRoutes, ...staffRoutes, ...adminRoutes];

const compiled = routes.map(r => ({
  route: r,
  regex: new RegExp('^' + r.path.replace(/:[a-z]+/gi, '([^/]+)') + '$'),
  names: [...r.path.matchAll(/:([a-z]+)/gi)].map(m => m[1]),
}));

export default async (req: Request, context: Context): Promise<Response> => {
  try {
    const path = new URL(req.url).pathname.replace(/\/+$/, '') || '/';
    let pathMatched = false;

    for (const { route, regex, names } of compiled) {
      const m = regex.exec(path);
      if (!m) continue;
      pathMatched = true;
      if (route.method !== req.method) continue;

      const params: Record<string, string> = {};
      names.forEach((n, i) => { params[n] = decodeURIComponent(m[i + 1]); });

      const user = route.access === 'public' ? null : await authenticate(req);
      if (route.access === 'admin' && user!.role !== 'ADMIN') {
        throw new HttpError(403, 'forbidden', 'Accès réservé à l’administrateur.');
      }
      const body = await readBody(req, route.maxBody ?? 10_000);
      const result = await route.handler({ req, params, body, user, ip: context.ip ?? '' });
      return result instanceof Response ? result : json(result);
    }
    throw pathMatched
      ? new HttpError(405, 'method_not_allowed', 'Méthode non autorisée.')
      : new HttpError(404, 'not_found', 'Ressource introuvable.');
  } catch (e) {
    if (e instanceof HttpError) return json({ error: { code: e.code, message: e.message } }, e.status);
    if (e instanceof ConfigError) {
      console.error('[config]', e.message);
      return json({ error: { code: 'config_error', message: `Configuration serveur incomplète : ${e.message}` } }, 500);
    }
    console.error('[api]', e);
    return json({ error: { code: 'internal', message: 'Erreur serveur.' } }, 500);
  }
};

export const config: Config = { path: '/api/*' };
