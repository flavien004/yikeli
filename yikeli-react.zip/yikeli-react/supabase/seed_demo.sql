-- Données de démonstration OPTIONNELLES (aucune donnée personnelle).
-- À exécuter manuellement dans le SQL Editor si vous voulez un menu d'exemple.
insert into public.plats (name, price, category, is_active, is_stocked, stock, low_stock_alert, expiration_delay) values
  ('Attiéké poisson', 3000, 'PLATS_IVOIRIENS', true, true, 20, 5, '2 jours à +4°C'),
  ('Riz sauce graine', 3000, 'PLATS_IVOIRIENS', true, true, 15, 5, '1 jour à +4°C'),
  ('Kedjenou poulet', 4000, 'PLATS_IVOIRIENS', true, true, 12, 4, '24h au réfrigérateur'),
  ('Alloco poisson', 2500, 'PLATS_IVOIRIENS', true, false, 0, 0, 'À consommer le jour même'),
  ('Garba', 1500, 'PLATS_IVOIRIENS', true, true, 25, 8, '1 jour'),
  ('Jus de bissap', 500, 'BOISSONS', true, true, 30, 10, '5 jours réfrigéré'),
  ('Jus de gingembre', 500, 'BOISSONS', true, true, 30, 10, '5 jours réfrigéré'),
  ('Eau minérale', 300, 'BOISSONS', true, false, 0, 0, 'Non périssable');

insert into public.ingredients (name, unit, stock, low_stock_alert, last_unit_cost) values
  ('Attiéké', 'kg', 10, 3, 1200),
  ('Poisson (carpe)', 'kg', 8, 3, 2500),
  ('Riz', 'kg', 25, 5, 700),
  ('Huile de palme', 'L', 6, 2, 1500),
  ('Gingembre', 'kg', 2, 1, 1000);
