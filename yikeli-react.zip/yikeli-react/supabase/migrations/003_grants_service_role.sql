-- ============================================================
-- YIKÉLI — Correctif : droits du rôle service_role
--
-- À exécuter UNE FOIS dans le SQL Editor si `npm run create-admin` ou l'API répond
--   « permission denied for table users »  (code 42501).
-- Sans danger si déjà appliqué (idempotent). Les nouvelles installations l'ont déjà via 001.
-- ============================================================
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    revoke all on all tables in schema public from anon, authenticated;
    revoke all on all sequences in schema public from anon, authenticated;
    revoke execute on all functions in schema public from public, anon, authenticated;
    alter default privileges in schema public revoke all on tables from anon, authenticated;
    alter default privileges in schema public revoke all on sequences from anon, authenticated;
  end if;

  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant usage on schema public to service_role;
    grant select, insert, update, delete on all tables in schema public to service_role;
    grant usage, select on all sequences in schema public to service_role;
    grant execute on all functions in schema public to service_role;
    alter default privileges in schema public grant select, insert, update, delete on tables to service_role;
    alter default privileges in schema public grant usage, select on sequences to service_role;
    alter default privileges in schema public grant execute on functions to service_role;
  end if;
end $$;
