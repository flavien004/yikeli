-- ============================================================
-- YIKÉLI — Schéma initial (PostgreSQL / Supabase)
--
-- SÉCURITÉ : RLS activée sur TOUTES les tables, sans aucune politique.
-- Résultat : la clé anon / les utilisateurs authentifiés Supabase n'ont
-- aucun accès. Seules les Netlify Functions (clé service_role, serveur)
-- lisent et écrivent. La clé service_role ne doit jamais atteindre le navigateur.
-- ============================================================

-- ── Utilisateurs & sessions ─────────────────────────────────
create table public.users (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 100),
  email text not null check (email = lower(email) and char_length(email) <= 254),
  phone text check (phone is null or char_length(phone) <= 30),
  role text not null check (role in ('ADMIN','CHEF','CAISSIER')),
  is_active boolean not null default true,
  password_hash text not null,
  created_at timestamptz not null default now()
);
create unique index users_email_key on public.users (email);

create table public.refresh_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  token_hash text not null unique,          -- SHA-256 du jeton ; le jeton en clair n'est jamais stocké
  expires_at timestamptz not null,
  revoked_at timestamptz,
  replaced_by uuid,
  user_agent text,
  created_at timestamptz not null default now()
);
create index refresh_tokens_user_idx on public.refresh_tokens (user_id);

create table public.login_attempts (
  id bigint generated always as identity primary key,
  email text not null,
  ip text,
  created_at timestamptz not null default now()
);
create index login_attempts_email_idx on public.login_attempts (email, created_at desc);

-- ── Catalogue ───────────────────────────────────────────────
create table public.plats (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  price integer not null check (price >= 0 and price <= 10000000),
  category text not null check (category in ('PLATS_IVOIRIENS','BOISSONS')),
  is_active boolean not null default true,
  is_stocked boolean not null default false,
  stock integer not null default 0 check (stock >= 0),
  low_stock_alert integer not null default 0 check (low_stock_alert >= 0),
  expiration_delay text check (expiration_delay is null or char_length(expiration_delay) <= 100),
  image_url text check (image_url is null or char_length(image_url) <= 500),
  created_at timestamptz not null default now()
);

-- ── Ingrédients & suivi de stock ────────────────────────────
create table public.ingredients (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  unit text not null check (char_length(unit) between 1 and 20),
  stock numeric(12,3) not null default 0 check (stock >= 0),
  low_stock_alert numeric(12,3) not null default 0 check (low_stock_alert >= 0),
  last_unit_cost numeric(12,2) not null default 0 check (last_unit_cost >= 0),
  supplier text check (supplier is null or char_length(supplier) <= 100),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index ingredients_name_key on public.ingredients (lower(name));

create table public.ingredient_movements (
  id uuid primary key default gen_random_uuid(),
  ingredient_id uuid not null references public.ingredients(id) on delete restrict,
  type text not null check (type in ('APPROVISIONNEMENT','AJUSTEMENT')),
  quantity numeric(12,3) not null,          -- positif pour un approvisionnement, signé pour un ajustement
  unit_cost numeric(12,2),
  supplier text,
  note text check (note is null or char_length(note) <= 300),
  stock_after numeric(12,3) not null,
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index ingredient_movements_ing_idx on public.ingredient_movements (ingredient_id, created_at desc);

-- ── Clients, commandes, paiements ───────────────────────────
create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  phone text unique check (phone is null or char_length(phone) <= 30),
  address text check (address is null or char_length(address) <= 200),
  total_spent integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.commandes (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete set null,
  client_name text not null,
  client_phone text,
  client_address text,
  type text not null check (type in ('SUR_PLACE','EN_LIGNE','LIVRAISON')),
  total integer not null default 0 check (total >= 0),
  status text not null default 'EN_COURS' check (status in ('EN_COURS','ACCEPTEE','SERVIE','PAYEE','ANNULEE')),
  specs text check (specs is null or char_length(specs) <= 500),
  payment_pref text check (payment_pref is null or payment_pref in ('ESPECE','WAVE','ORANGE_MONEY','DJAMO','MTN_MONEY')),
  cancel_reason text,
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index commandes_created_idx on public.commandes (created_at desc);

create table public.commande_items (
  id uuid primary key default gen_random_uuid(),
  commande_id uuid not null references public.commandes(id) on delete cascade,
  plat_id uuid references public.plats(id) on delete set null,
  plat_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price integer not null check (unit_price >= 0)
);
create index commande_items_cmd_idx on public.commande_items (commande_id);

create table public.paiements (
  id uuid primary key default gen_random_uuid(),
  commande_id uuid not null references public.commandes(id) on delete cascade,
  user_id uuid references public.users(id) on delete set null,
  amount integer not null check (amount > 0),
  method text not null check (method in ('ESPECE','WAVE','ORANGE_MONEY','DJAMO','MTN_MONEY')),
  created_at timestamptz not null default now()
);
create index paiements_cmd_idx on public.paiements (commande_id);
create index paiements_created_idx on public.paiements (created_at desc);

-- ── Finances ────────────────────────────────────────────────
create table public.exp_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  is_system boolean not null default false,   -- « Provisions » est protégée (utilisée par les employés)
  created_at timestamptz not null default now()
);
create unique index exp_categories_name_key on public.exp_categories (lower(name));
alter table public.exp_categories add constraint exp_categories_name_unique unique (name);

create table public.depenses (
  id uuid primary key default gen_random_uuid(),
  category text not null references public.exp_categories(name) on update cascade on delete restrict,
  description text not null check (char_length(description) between 1 and 200),
  amount integer not null check (amount > 0),
  date date not null,
  ingredient_movement_id uuid references public.ingredient_movements(id) on delete set null,
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index depenses_date_idx on public.depenses (date desc);

create table public.mouvements_manuels (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  type text not null check (type in ('RECETTE','DEPENSE')),
  libelle text not null check (char_length(libelle) between 1 and 200),
  montant integer not null check (montant > 0),
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.app_settings (
  key text primary key,
  value jsonb not null
);

-- ── Données de base (aucune donnée personnelle) ─────────────
insert into public.exp_categories (name, is_system) values
  ('Provisions', true), ('Salaires', false), ('Loyer', false), ('Factures', false),
  ('Transport', false), ('Livraison', false), ('Taxes', false), ('Réparations', false), ('Autres', false);
insert into public.app_settings (key, value) values ('solde_initial', '0'::jsonb);

-- ── RLS : activée, aucune politique ─────────────────────────
alter table public.users enable row level security;
alter table public.refresh_tokens enable row level security;
alter table public.login_attempts enable row level security;
alter table public.plats enable row level security;
alter table public.ingredients enable row level security;
alter table public.ingredient_movements enable row level security;
alter table public.clients enable row level security;
alter table public.commandes enable row level security;
alter table public.commande_items enable row level security;
alter table public.paiements enable row level security;
alter table public.exp_categories enable row level security;
alter table public.depenses enable row level security;
alter table public.mouvements_manuels enable row level security;
alter table public.app_settings enable row level security;

-- ============================================================
-- FONCTIONS TRANSACTIONNELLES
-- Chaque fonction s'exécute dans UNE transaction : verrouillage des lignes
-- (FOR UPDATE), contrôle de stock et écritures sont atomiques.
-- ============================================================

-- Rotation d'un refresh token avec détection de réutilisation.
create or replace function public.rotate_refresh_token(
  p_old_hash text, p_new_hash text, p_expires timestamptz, p_ua text
) returns table (out_user_id uuid, out_outcome text)
language plpgsql as $$
declare
  v public.refresh_tokens%rowtype;
  v_new uuid;
begin
  select * into v from public.refresh_tokens where token_hash = p_old_hash for update;
  if not found then
    return query select null::uuid, 'invalid'::text; return;
  end if;

  if v.revoked_at is not null then
    -- Course légitime (deux onglets) : jeton remplacé il y a < 10 s → pas de sanction
    if v.replaced_by is not null and v.revoked_at > now() - interval '10 seconds' then
      return query select v.user_id, 'raced'::text; return;
    end if;
    -- Jeton déjà utilisé et révoqué : réutilisation suspecte → on révoque toutes les sessions
    update public.refresh_tokens set revoked_at = now()
      where user_id = v.user_id and revoked_at is null;
    return query select v.user_id, 'reused'::text; return;
  end if;

  if v.expires_at < now() then
    return query select v.user_id, 'expired'::text; return;
  end if;

  insert into public.refresh_tokens (user_id, token_hash, expires_at, user_agent)
    values (v.user_id, p_new_hash, p_expires, left(p_ua, 300)) returning id into v_new;
  update public.refresh_tokens set revoked_at = now(), replaced_by = v_new where id = v.id;
  return query select v.user_id, 'ok'::text;
end $$;

-- Création d'une commande (staff ou client en ligne) : prix calculés côté base.
create or replace function public.create_order(p jsonb)
returns uuid
language plpgsql as $$
declare
  r record;
  v_plat public.plats%rowtype;
  v_pay jsonb;
  v_cmd uuid;
  v_client uuid;
  v_phone text := nullif(btrim(coalesce(p->>'client_phone','')), '');
  v_name text := left(coalesce(nullif(btrim(coalesce(p->>'client_name','')), ''), 'Client comptoir'), 100);
  v_addr text := nullif(left(btrim(coalesce(p->>'client_address','')), 200), '');
  v_type text := coalesce(p->>'type', 'SUR_PLACE');
  v_cashier uuid := nullif(p->>'cashier_id','')::uuid;
  v_total int := 0;
  v_paid int := 0;
  v_applied int;
  v_amount int;
begin
  if jsonb_typeof(p->'items') is distinct from 'array'
     or jsonb_array_length(p->'items') not between 1 and 50 then
    raise exception 'invalid_items';
  end if;
  if v_type not in ('SUR_PLACE','EN_LIGNE','LIVRAISON') then
    raise exception 'invalid_type';
  end if;

  for r in select value from jsonb_array_elements(p->'items') loop
    if coalesce((r.value->>'quantity')::int, 0) not between 1 and 100 then
      raise exception 'invalid_quantity';
    end if;
  end loop;

  if v_phone is not null then
    insert into public.clients (name, phone, address)
      values (v_name, v_phone, v_addr)
      on conflict (phone) do update
        set name = excluded.name,
            address = coalesce(excluded.address, public.clients.address)
      returning id into v_client;
  end if;

  insert into public.commandes
    (client_id, client_name, client_phone, client_address, type, total, status, specs, payment_pref, created_by)
  values
    (v_client, v_name, v_phone, v_addr, v_type, 0, 'EN_COURS',
     nullif(left(btrim(coalesce(p->>'specs','')), 500), ''),
     nullif(p->>'payment_pref',''), v_cashier)
  returning id into v_cmd;

  -- Quantités regroupées par plat, ordre fixe (évite les deadlocks)
  for r in
    select (e.value->>'plat_id')::uuid as plat_id, sum((e.value->>'quantity')::int)::int as qty
    from jsonb_array_elements(p->'items') e
    group by 1 order by 1
  loop
    select * into v_plat from public.plats where id = r.plat_id for update;
    if not found or not v_plat.is_active then
      raise exception 'plat_unavailable';
    end if;
    if v_plat.is_stocked and v_plat.stock < r.qty then
      raise exception 'stock_insufficient:%', v_plat.name;
    end if;
    insert into public.commande_items (commande_id, plat_id, plat_name, quantity, unit_price)
      values (v_cmd, v_plat.id, v_plat.name, r.qty, v_plat.price);
    if v_plat.is_stocked then
      update public.plats set stock = stock - r.qty where id = v_plat.id;
    end if;
    v_total := v_total + v_plat.price * r.qty;
  end loop;
  update public.commandes set total = v_total where id = v_cmd;

  for v_pay in select value from jsonb_array_elements(coalesce(p->'payments', '[]'::jsonb)) loop
    v_amount := (v_pay->>'amount')::int;
    if v_amount is null or v_amount <= 0 then raise exception 'invalid_amount'; end if;
    if coalesce(v_pay->>'method','') not in ('ESPECE','WAVE','ORANGE_MONEY','DJAMO','MTN_MONEY') then
      raise exception 'invalid_method';
    end if;
    v_applied := least(v_amount, v_total - v_paid);   -- l'excédent est de la monnaie rendue
    if v_applied > 0 then
      insert into public.paiements (commande_id, user_id, amount, method)
        values (v_cmd, v_cashier, v_applied, v_pay->>'method');
      v_paid := v_paid + v_applied;
    end if;
  end loop;

  if v_total > 0 and v_paid >= v_total then
    update public.commandes set status = 'PAYEE' where id = v_cmd;
  end if;
  if v_client is not null and v_paid > 0 then
    update public.clients set total_spent = total_spent + v_paid where id = v_client;
  end if;
  return v_cmd;
end $$;

-- Encaissement (partiel ou total). Le statut PAYEE n'est posé QUE par cette logique.
create or replace function public.add_payment(p_commande uuid, p_method text, p_amount int, p_user uuid)
returns jsonb
language plpgsql as $$
declare
  c public.commandes%rowtype;
  v_paid int;
  v_applied int;
  v_remaining int;
  v_status text;
begin
  if p_method not in ('ESPECE','WAVE','ORANGE_MONEY','DJAMO','MTN_MONEY') then raise exception 'invalid_method'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'invalid_amount'; end if;

  select * into c from public.commandes where id = p_commande for update;
  if not found then raise exception 'order_not_found'; end if;
  if c.status = 'ANNULEE' then raise exception 'order_cancelled'; end if;

  select coalesce(sum(amount), 0) into v_paid from public.paiements where commande_id = c.id;
  v_remaining := c.total - v_paid;
  if v_remaining <= 0 then raise exception 'already_paid'; end if;

  v_applied := least(p_amount, v_remaining);
  insert into public.paiements (commande_id, user_id, amount, method)
    values (c.id, p_user, v_applied, p_method);

  v_status := c.status;
  if v_paid + v_applied >= c.total then
    v_status := 'PAYEE';
    update public.commandes set status = 'PAYEE' where id = c.id;
  end if;
  if c.client_id is not null then
    update public.clients set total_spent = total_spent + v_applied where id = c.client_id;
  end if;
  return jsonb_build_object('applied', v_applied, 'remaining', v_remaining - v_applied, 'status', v_status);
end $$;

create or replace function public.delete_payment(p_id uuid)
returns void
language plpgsql as $$
declare
  pm public.paiements%rowtype;
  c public.commandes%rowtype;
begin
  select * into pm from public.paiements where id = p_id for update;
  if not found then raise exception 'payment_not_found'; end if;
  select * into c from public.commandes where id = pm.commande_id for update;
  delete from public.paiements where id = p_id;
  if c.status = 'PAYEE' then
    update public.commandes set status = 'EN_COURS' where id = c.id;   -- le solde n'est plus réglé
  end if;
  if c.client_id is not null then
    update public.clients set total_spent = greatest(0, total_spent - pm.amount) where id = c.client_id;
  end if;
end $$;

create or replace function public.set_order_status(p_id uuid, p_status text)
returns void
language plpgsql as $$
begin
  if p_status not in ('ACCEPTEE','SERVIE') then raise exception 'invalid_status'; end if;
  update public.commandes set status = p_status
    where id = p_id and status in ('EN_COURS','ACCEPTEE','SERVIE');
  if not found then raise exception 'invalid_transition'; end if;
end $$;

create or replace function public.cancel_order(p_id uuid, p_reason text)
returns void
language plpgsql as $$
declare c public.commandes%rowtype;
begin
  select * into c from public.commandes where id = p_id for update;
  if not found then raise exception 'order_not_found'; end if;
  if c.status = 'ANNULEE' then raise exception 'already_cancelled'; end if;
  if exists (select 1 from public.paiements where commande_id = p_id) then
    raise exception 'order_has_payments';
  end if;
  update public.plats p set stock = p.stock + i.quantity
    from public.commande_items i
    where i.commande_id = p_id and i.plat_id = p.id and p.is_stocked;
  update public.commandes set status = 'ANNULEE', cancel_reason = left(p_reason, 300) where id = p_id;
end $$;

create or replace function public.delete_order(p_id uuid)
returns void
language plpgsql as $$
declare c public.commandes%rowtype;
begin
  select * into c from public.commandes where id = p_id for update;
  if not found then raise exception 'order_not_found'; end if;
  if exists (select 1 from public.paiements where commande_id = p_id) then
    raise exception 'order_has_payments';
  end if;
  if c.status <> 'ANNULEE' then
    update public.plats p set stock = p.stock + i.quantity
      from public.commande_items i
      where i.commande_id = p_id and i.plat_id = p.id and p.is_stocked;
  end if;
  delete from public.commandes where id = p_id;
end $$;

-- Approvisionnement d'UN ingrédient (+ dépense « Provisions » optionnelle)
create or replace function public.supply_ingredient(
  p_ingredient uuid, p_qty numeric, p_unit_cost numeric,
  p_supplier text, p_note text, p_user uuid, p_record_expense boolean
) returns uuid
language plpgsql as $$
declare
  i public.ingredients%rowtype;
  v_mov uuid;
  v_after numeric;
  v_amount int;
begin
  if p_qty is null or p_qty <= 0 then raise exception 'invalid_quantity'; end if;
  if p_unit_cost is null or p_unit_cost < 0 then raise exception 'invalid_amount'; end if;
  select * into i from public.ingredients where id = p_ingredient for update;
  if not found then raise exception 'ingredient_not_found'; end if;

  v_after := i.stock + p_qty;
  insert into public.ingredient_movements
    (ingredient_id, type, quantity, unit_cost, supplier, note, stock_after, created_by)
  values
    (i.id, 'APPROVISIONNEMENT', p_qty, p_unit_cost, nullif(btrim(p_supplier), ''),
     nullif(btrim(p_note), ''), v_after, p_user)
  returning id into v_mov;

  update public.ingredients
    set stock = v_after, last_unit_cost = p_unit_cost,
        supplier = coalesce(nullif(btrim(p_supplier), ''), supplier)
    where id = i.id;

  if p_record_expense then
    v_amount := round(p_qty * p_unit_cost)::int;
    if v_amount > 0 then
      insert into public.depenses (category, description, amount, date, ingredient_movement_id, created_by)
      values ('Provisions',
              left('Approvisionnement : ' || i.name || ' × ' || p_qty::text || ' ' || i.unit, 200),
              v_amount, current_date, v_mov, p_user);
    end if;
  end if;
  return v_mov;
end $$;

-- Ajustement (perte, casse, inventaire) : delta signé, motif obligatoire
create or replace function public.adjust_ingredient(
  p_ingredient uuid, p_delta numeric, p_note text, p_user uuid
) returns uuid
language plpgsql as $$
declare
  i public.ingredients%rowtype;
  v_mov uuid;
  v_after numeric;
begin
  if p_delta is null or p_delta = 0 then raise exception 'invalid_quantity'; end if;
  if p_note is null or btrim(p_note) = '' then raise exception 'note_required'; end if;
  select * into i from public.ingredients where id = p_ingredient for update;
  if not found then raise exception 'ingredient_not_found'; end if;
  v_after := i.stock + p_delta;
  if v_after < 0 then raise exception 'stock_negative'; end if;
  insert into public.ingredient_movements
    (ingredient_id, type, quantity, note, stock_after, created_by)
  values (i.id, 'AJUSTEMENT', p_delta, left(btrim(p_note), 300), v_after, p_user)
  returning id into v_mov;
  update public.ingredients set stock = v_after where id = i.id;
  return v_mov;
end $$;

-- ── Droits : fonctions et tables réservées au rôle service_role ──
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    revoke all on all tables in schema public from anon, authenticated;
    revoke all on all sequences in schema public from anon, authenticated;
    revoke execute on all functions in schema public from public, anon, authenticated;
    alter default privileges in schema public revoke all on tables from anon, authenticated;
    alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
    grant execute on all functions in schema public to service_role;
  end if;
end $$;
