-- ============================================================
-- YIKÉLI — Bucket d'images produits
-- Lecture publique (les images s'affichent dans le menu client).
-- Écriture : uniquement via la fonction serveur (service_role) qui contrôle
-- le type, la taille et les premiers octets du fichier.
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 1572864, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;
