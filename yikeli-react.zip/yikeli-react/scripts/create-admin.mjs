// Crée (ou met à jour) le compte administrateur initial.
// Usage : renseigner ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD dans .env puis
//         npm run create-admin
// Le mot de passe n'est jamais stocké en clair : seul son hash bcrypt part en base.
import bcrypt from 'bcryptjs';
import { createClient } from '@supabase/supabase-js';

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) throw new Error('SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY requis');
if (!ADMIN_NAME || !ADMIN_EMAIL || !ADMIN_PASSWORD) throw new Error('ADMIN_NAME, ADMIN_EMAIL et ADMIN_PASSWORD requis');
if (ADMIN_PASSWORD.length < 10) throw new Error('Le mot de passe doit contenir au moins 10 caractères');

const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
const email = ADMIN_EMAIL.trim().toLowerCase();
const password_hash = await bcrypt.hash(ADMIN_PASSWORD, 12);

const { error } = await db.from('users').upsert(
  { name: ADMIN_NAME.trim(), email, role: 'ADMIN', is_active: true, password_hash },
  { onConflict: 'email' }
);
if (error) { console.error('Échec :', error.message); process.exit(1); }
console.log(`Administrateur « ${email} » créé/mis à jour. Supprimez ADMIN_PASSWORD de votre .env.`);
