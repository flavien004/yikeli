// Crée (ou met à jour) le compte administrateur initial.
// Usage : renseigner ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD dans .env puis  npm run create-admin
// Le mot de passe n'est jamais stocké en clair : seul son hash bcrypt part en base.
import bcrypt from 'bcryptjs';
import { createClient } from '@supabase/supabase-js';

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY: KEY, ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
const fail = (msg) => { console.error('\n' + msg + '\n'); process.exit(1); };

if (!SUPABASE_URL || !KEY) fail('SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont requis dans .env');
if (!ADMIN_NAME || !ADMIN_EMAIL || !ADMIN_PASSWORD) fail('ADMIN_NAME, ADMIN_EMAIL et ADMIN_PASSWORD sont requis dans .env');
if (ADMIN_PASSWORD.length < 10) fail('Le mot de passe doit contenir au moins 10 caractères.');

// Mauvaise clé = cause n°1 de « permission denied » : on la détecte avant d'appeler la base.
function keyProblem(key) {
  if (key.startsWith('sb_publishable_')) return 'une clé « publishable » (publique)';
  if (key.split('.').length === 3) {
    try {
      const role = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString()).role;
      if (role !== 'service_role') return `une clé de rôle « ${role} » (clé publique anon)`;
    } catch { /* format inattendu : on laisse Supabase trancher */ }
  }
  return null;
}
const wrong = keyProblem(KEY);
if (wrong) fail(`SUPABASE_SERVICE_ROLE_KEY contient ${wrong}.\n` +
  'Utilisez la clé secrète : Supabase → Project Settings → API Keys → « service_role » (ou « secret »).');

const db = createClient(SUPABASE_URL, KEY, { auth: { persistSession: false } });
const email = ADMIN_EMAIL.trim().toLowerCase();
const password_hash = await bcrypt.hash(ADMIN_PASSWORD, 12);

const { error } = await db.from('users').upsert(
  { name: ADMIN_NAME.trim(), email, role: 'ADMIN', is_active: true, password_hash },
  { onConflict: 'email' }
);

if (error) {
  if (error.code === '42501' || /permission denied/i.test(error.message)) {
    fail('Permission refusée sur la table « users » (42501).\n' +
      'Depuis mai 2026, Supabase n\u2019accorde plus de droits automatiquement aux nouvelles tables.\n' +
      '→ Exécutez supabase/migrations/003_grants_service_role.sql dans le SQL Editor, puis relancez cette commande.');
  }
  if (error.code === 'PGRST205' || /does not exist|schema cache/i.test(error.message)) {
    fail('La table « users » est introuvable : exécutez d\u2019abord supabase/migrations/001_init.sql.');
  }
  fail('Échec : ' + error.message);
}
console.log(`Administrateur « ${email} » créé/mis à jour. Supprimez ADMIN_PASSWORD de votre .env.`);
