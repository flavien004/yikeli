// Redimensionne une image côté navigateur avant envoi (800 px max, WebP/JPEG ~100 Ko).
export interface PreparedImage { contentType: 'image/webp' | 'image/jpeg'; dataBase64: string; previewUrl: string; }

export async function prepareImage(file: File, maxSide = 800): Promise<PreparedImage> {
  if (!file.type.startsWith('image/')) throw new Error('Le fichier doit être une image.');
  if (file.size > 12_000_000) throw new Error('Image trop volumineuse (12 Mo maximum avant compression).');
  const bitmap = await createImageBitmap(file);
  const ratio = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * ratio);
  canvas.height = Math.round(bitmap.height * ratio);
  canvas.getContext('2d')!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);

  const toBlob = (type: string, q: number) => new Promise<Blob | null>(r => canvas.toBlob(r, type, q));
  let blob = await toBlob('image/webp', 0.82);
  let contentType: PreparedImage['contentType'] = 'image/webp';
  if (!blob || blob.type !== 'image/webp') { blob = await toBlob('image/jpeg', 0.85); contentType = 'image/jpeg'; }
  if (!blob) throw new Error('Impossible de traiter cette image.');

  const dataBase64 = await new Promise<string>((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result).split(',')[1]);
    fr.onerror = () => reject(new Error('Lecture de l’image impossible.'));
    fr.readAsDataURL(blob!);
  });
  return { contentType, dataBase64, previewUrl: URL.createObjectURL(blob) };
}
