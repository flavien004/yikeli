import { errorMessage } from './api';
import { showToast } from '../components/shared';

/** Exécute une action, affiche le message de succès ou l'erreur serveur. */
export async function act<T>(fn: () => Promise<T>, success?: string):
  Promise<{ ok: true; value: T } | { ok: false }> {
  try {
    const value = await fn();
    if (success) showToast(success);
    return { ok: true, value };
  } catch (e) {
    showToast(errorMessage(e));
    return { ok: false };
  }
}
