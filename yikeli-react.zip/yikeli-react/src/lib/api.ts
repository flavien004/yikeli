// ============================================================
// Client HTTP : le JWT d'accès vit UNIQUEMENT en mémoire (jamais dans
// localStorage). Le refresh token est un cookie HttpOnly inaccessible au JS.
// Sur 401, on renouvelle la session une fois (appel unique partagé) puis on rejoue.
// ============================================================
import type { SessionUser } from '../types';

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

export interface SessionPayload { accessToken: string; expiresIn: number; user: SessionUser; }

let accessToken: string | null = null;
let inFlight: Promise<SessionPayload | null> | null = null;

export const setAccessToken = (t: string | null) => { accessToken = t; };
export const SESSION_EXPIRED_EVENT = 'yikeli:session-expired';

export function refreshSession(): Promise<SessionPayload | null> {
  inFlight ??= (async () => {
    try {
      const res = await fetch('/api/auth/refresh', { method: 'POST', credentials: 'same-origin' });
      if (!res.ok) { accessToken = null; return null; }
      const s = (await res.json()) as SessionPayload;
      accessToken = s.accessToken;
      return s;
    } catch {
      return null;
    }
  })().finally(() => { inFlight = null; });
  return inFlight;
}

interface Options { method?: string; body?: unknown; auth?: boolean; }

export async function api<T = unknown>(path: string, { method = 'GET', body, auth = true }: Options = {}): Promise<T> {
  const send = () => fetch(path, {
    method,
    credentials: 'same-origin',
    headers: {
      ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
      ...(auth && accessToken ? { authorization: `Bearer ${accessToken}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let res = await send();
  if (res.status === 401 && auth) {
    const session = await refreshSession();
    if (session) res = await send();
    else window.dispatchEvent(new Event(SESSION_EXPIRED_EVENT));
  }

  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const e = data?.error;
    throw new ApiError(res.status, e?.code ?? 'error', e?.message ?? 'Une erreur est survenue.');
  }
  return data as T;
}

export const errorMessage = (e: unknown): string =>
  e instanceof ApiError ? e.message : 'Connexion au serveur impossible. Réessayez.';
