// ============================================================
// YIKÉLI — Racine de l'application
// • Espace client : public, sans compte.
// • Espace équipe : connexion JWT. ADMIN → tout ; CAISSIER/CHEF → espace restreint.
// Les droits sont appliqués par l'API : masquer un écran ici n'est qu'un confort.
// ============================================================
import React, { useState } from 'react';
import { AuthProvider, useAuth } from './hooks/AuthContext';
import { AppProvider, useApp } from './hooks/AppContext';
import { AdminPage } from './components/admin/AdminPage';
import { EmployeePage } from './components/pos/EmployeePage';
import { ClientPage } from './components/client/ClientPage';
import { LoginPage } from './components/auth/LoginPage';
import { IframeBanner, ToastContainer, BtnSecondary } from './components/shared';

type Space = 'client' | 'staff';

const StaffArea: React.FC = () => {
  const { user } = useAuth();
  const { loading } = useApp();
  if (loading) return <div className="h-full flex items-center justify-center text-xs text-zinc-400">Chargement des données…</div>;
  return user?.role === 'ADMIN' ? <AdminPage /> : <EmployeePage />;
};

const Shell: React.FC = () => {
  const { status, user, logout } = useAuth();
  const [space, setSpace] = useState<Space>('client');

  return (
    <div className="h-screen flex flex-col bg-zinc-50 text-zinc-900">
      <IframeBanner />
      <header className="bg-white border-b border-zinc-200 px-4 py-2 flex items-center gap-3">
        <div className="w-7 h-7 rounded-lg bg-orange-500 text-white flex items-center justify-center text-sm font-medium">Y</div>
        <span className="text-sm font-medium">Yikéli</span>
        <div className="flex gap-1 bg-orange-50 rounded-lg p-1 ml-4">
          {(['client', 'staff'] as const).map(s => (
            <button key={s} onClick={() => setSpace(s)}
              className={`px-3 py-1 rounded-md text-xs border-none cursor-pointer ${space === s ? 'bg-orange-500 text-white font-medium' : 'bg-transparent text-orange-700'}`}>
              {s === 'client' ? 'Espace client' : 'Espace équipe'}
            </button>
          ))}
        </div>
        {space === 'staff' && status === 'authed' && (
          <div className="ml-auto flex items-center gap-3 text-xs">
            <span className="text-zinc-500">{user?.name} · {user?.role === 'ADMIN' ? 'Admin' : user?.role === 'CHEF' ? 'Chef' : 'Caissier'}</span>
            <BtnSecondary onClick={() => void logout()}>Déconnexion</BtnSecondary>
          </div>
        )}
      </header>
      <main className="flex-1 overflow-hidden">
        {space === 'client' && <div className="h-full overflow-y-auto"><ClientPage /></div>}
        {space === 'staff' && (
          status === 'loading' ? <div className="h-full flex items-center justify-center text-xs text-zinc-400">Vérification de la session…</div>
          : status === 'anon' ? <LoginPage />
          : <AppProvider><StaffArea /></AppProvider>
        )}
      </main>
      <ToastContainer />
    </div>
  );
};

const App: React.FC = () => (
  <AuthProvider>
    <Shell />
  </AuthProvider>
);

export default App;
