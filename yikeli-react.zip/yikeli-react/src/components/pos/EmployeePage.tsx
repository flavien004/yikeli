// ============================================================
// YIKÉLI — Espace employé (accès restreint, appliqué AUSSI côté serveur) :
// caisse, commandes/encaissements, dépenses de catégorie « Provisions ».
// Le statut « Payée » n'est posé que par un paiement (jamais à la main).
// ============================================================
import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { Commande, PaymentMethod } from '../../types';
import { fmtFCFA, METHOD_LABELS, getPaidAmount, getRemaining } from '../../utils';
import { act } from '../../lib/act';
import { BtnPrimary, BtnSecondary, Field, Input, Select, KpiCard, StatusBadge, showToast } from '../shared';
import { POSPage } from './POSPage';

type EmpTab = 'pos' | 'commandes' | 'provisions';

export const EmployeePage: React.FC = () => {
  const [tab, setTab] = useState<EmpTab>('pos');
  const TABS: { id: EmpTab; label: string }[] = [
    { id: 'pos', label: '🧾 Caisse' },
    { id: 'commandes', label: '📋 Commandes & paiements' },
    { id: 'provisions', label: '🛒 Dépenses provisions' },
  ];
  return (
    <div className="flex flex-col h-full">
      <div className="bg-white border-b border-zinc-200 px-4 flex gap-1 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-3 py-3 text-xs font-medium border-b-2 cursor-pointer whitespace-nowrap ${tab === t.id ? 'border-orange-500 text-orange-600' : 'border-transparent text-zinc-500'}`}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto">
        {tab === 'pos' && <POSPage onViewOrders={() => setTab('commandes')} />}
        {tab === 'commandes' && <div className="p-5"><CommandesPaiements /></div>}
        {tab === 'provisions' && <div className="p-5"><Provisions /></div>}
      </div>
    </div>
  );
};

const CommandesPaiements: React.FC = () => {
  const { state, addPaiement, setOrderStatus } = useApp();
  const [cmdId, setCmdId] = useState('');
  const [mode, setMode] = useState<PaymentMethod>('ESPECE');
  const [montant, setMontant] = useState('');

  const actives = useMemo(
    () => state.commandes.filter(c => c.status !== 'PAYEE' && c.status !== 'ANNULEE'),
    [state.commandes]
  );
  const selected = actives.find(c => c.id === cmdId);
  const rem = selected ? getRemaining(selected, state.paiements) : 0;
  const mnt = parseFloat(montant) || 0;

  const encaisser = async () => {
    if (!selected) { showToast('Sélectionner une commande'); return; }
    if (!mnt) { showToast('Saisir un montant'); return; }
    const r = await act(() => addPaiement(selected.id, mode, mnt),
      mnt >= rem ? 'Commande soldée — statut : Payée' : `Paiement partiel — reste ${fmtFCFA(rem - mnt)}`);
    if (r.ok) { setMontant(''); if (mnt >= rem) setCmdId(''); }
  };

  const advance = (c: Commande) => {
    const next = c.status === 'EN_COURS' ? 'ACCEPTEE' : 'SERVIE';
    void act(() => setOrderStatus(c.id, next), next === 'ACCEPTEE' ? 'Commande acceptée' : 'Commande servie');
  };

  return (
    <>
      <div className="grid grid-cols-3 gap-3 mb-4">
        <KpiCard label="Commandes actives" value={String(actives.length)} color="text-amber-600" />
        <KpiCard label="Reste à encaisser" value={fmtFCFA(actives.reduce((s, c) => s + getRemaining(c, state.paiements), 0))} />
        <KpiCard label="Commandes payées" value={String(state.commandes.filter(c => c.status === 'PAYEE').length)} color="text-green-600" />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white border border-zinc-200 rounded-xl p-4">
          <div className="text-sm font-medium mb-3">Commandes</div>
          {state.commandes.length === 0 && <div className="text-xs text-zinc-400 py-6 text-center">Aucune commande</div>}
          {state.commandes.map(c => (
            <div key={c.id} className="flex items-center gap-3 py-2.5 border-b border-zinc-100 last:border-0 text-xs">
              <div className="flex-1 min-w-0">
                <div className="font-medium">{c.clientName}
                  {c.type === 'EN_LIGNE' && <span className="ml-2 text-[9px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-600">En ligne</span>}
                </div>
                <div className="text-[10px] text-zinc-400 truncate">{c.items.map(i => `${i.platName} x${i.quantity}`).join(', ')}</div>
                {c.clientPhone && <div className="text-[10px] text-zinc-500">📞 {c.clientPhone}{c.clientAddress ? ` · ${c.clientAddress}` : ''}</div>}
                {c.specs && <div className="text-[10px] text-amber-600">📝 {c.specs}</div>}
                {c.paymentPref && <div className="text-[10px] text-zinc-500">Paiement souhaité : {METHOD_LABELS[c.paymentPref]}</div>}
              </div>
              <div className="text-right">
                <div className="font-medium">{fmtFCFA(c.total)}</div>
                <div className="text-[10px] text-zinc-400">Payé : {fmtFCFA(getPaidAmount(c.id, state.paiements))}</div>
              </div>
              <StatusBadge status={c.status} />
              {(c.status === 'EN_COURS' || c.status === 'ACCEPTEE') && (
                <BtnSecondary onClick={() => advance(c)} className="!py-1 !px-2 !text-[10px]">
                  {c.status === 'EN_COURS' ? 'Accepter' : 'Servir'}
                </BtnSecondary>
              )}
            </div>
          ))}
        </div>
        <div className="bg-white border border-zinc-200 rounded-xl p-4 h-fit">
          <div className="text-sm font-medium mb-3">Encaisser</div>
          <div className="flex flex-col gap-3">
            <Field label="Commande">
              <Select value={cmdId} onChange={e => setCmdId(e.target.value)}>
                <option value="">— Sélectionner —</option>
                {actives.map(c => <option key={c.id} value={c.id}>{c.clientName} · reste {fmtFCFA(getRemaining(c, state.paiements))}</option>)}
              </Select>
            </Field>
            <Field label="Mode">
              <Select value={mode} onChange={e => setMode(e.target.value as PaymentMethod)}>
                {(Object.keys(METHOD_LABELS) as PaymentMethod[]).map(m => <option key={m} value={m}>{METHOD_LABELS[m]}</option>)}
              </Select>
            </Field>
            <Field label="Montant (FCFA)" hint={selected ? `Reste à payer : ${fmtFCFA(rem)}` : undefined}>
              <Input type="number" value={montant} onChange={e => setMontant(e.target.value)} />
            </Field>
            <BtnPrimary onClick={encaisser} className="w-full justify-center">✓ Valider le paiement</BtnPrimary>
          </div>
        </div>
      </div>
    </>
  );
};

const Provisions: React.FC = () => {
  const { state, addDepense } = useApp();
  const [desc, setDesc] = useState('');
  const [montant, setMontant] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const provisions = state.depenses.filter(d => d.category === 'Provisions');

  const save = async () => {
    if (!desc.trim()) { showToast('Saisir une description'); return; }
    if (!(+montant > 0)) { showToast('Saisir un montant'); return; }
    const r = await act(() => addDepense({ category: 'Provisions', description: desc.trim(), amount: Math.round(+montant), date }),
      'Dépense de provisions enregistrée');
    if (r.ok) { setDesc(''); setMontant(''); }
  };

  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="col-span-2 bg-white border border-zinc-200 rounded-xl p-4">
        <div className="text-sm font-medium mb-3">Historique des provisions</div>
        {provisions.length === 0 && <div className="text-xs text-zinc-400 py-6 text-center">Aucune dépense</div>}
        {provisions.map(d => (
          <div key={d.id} className="flex justify-between py-2 border-b border-zinc-100 last:border-0 text-xs">
            <span className="text-zinc-400 w-14">{d.date.slice(5).split('-').reverse().join('/')}</span>
            <span className="flex-1">{d.description}</span>
            <span className="font-medium">{fmtFCFA(d.amount)}</span>
          </div>
        ))}
      </div>
      <div className="bg-white border border-zinc-200 rounded-xl p-4 h-fit">
        <div className="text-sm font-medium mb-1">Ajouter une dépense</div>
        <div className="text-[10px] text-zinc-400 mb-3">Catégorie limitée aux provisions</div>
        <div className="flex flex-col gap-3">
          <Field label="Catégorie"><Input value="Provisions" disabled /></Field>
          <Field label="Description"><Input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Ex : achat légumes marché" /></Field>
          <Field label="Montant (FCFA)"><Input type="number" value={montant} onChange={e => setMontant(e.target.value)} /></Field>
          <Field label="Date"><Input type="date" value={date} onChange={e => setDate(e.target.value)} /></Field>
          <BtnPrimary onClick={save} className="w-full justify-center">+ Enregistrer</BtnPrimary>
        </div>
      </div>
    </div>
  );
};
