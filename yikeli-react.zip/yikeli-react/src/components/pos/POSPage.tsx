// ============================================================
// YIKÉLI — Caisse (POS) : commandes sur place / livraison, paiements fractionnés,
// ticket 72 mm, reçu WhatsApp. Les prix et le stock sont revalidés par le serveur.
// ============================================================
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import { useAuth } from '../../hooks/AuthContext';
import type { PaymentMethod } from '../../types';
import { fmtFCFA, METHOD_LABELS, sendWhatsApp, printByClass } from '../../utils';
import { act } from '../../lib/act';
import { BtnPrimary, BtnSecondary, Input, Modal, ProductImage, showToast } from '../shared';

interface CartItem { platId: string; name: string; price: number; qty: number; }
interface SplitEntry { method: PaymentMethod; applique: number; }

function beep() {
  try {
    const ctx = new AudioContext();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = 880; g.gain.value = 0.08;
    o.start(); o.stop(ctx.currentTime + 0.18);
  } catch { /* son bloqué tant que l'utilisateur n'a pas interagi */ }
}

export const POSPage: React.FC<{ onViewOrders?: () => void }> = ({ onViewOrders }) => {
  const { state, createStaffOrder } = useApp();
  const { user } = useAuth();
  const { plats, commandes } = state;

  const [cat, setCat] = useState<'all' | 'PLATS_IVOIRIENS' | 'BOISSONS'>('all');
  const [orderType, setOrderType] = useState<'SUR_PLACE' | 'LIVRAISON'>('SUR_PLACE');
  const [clientNom, setClientNom] = useState('');
  const [clientTel, setClientTel] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [splits, setSplits] = useState<SplitEntry[]>([]);
  const [mode, setMode] = useState<PaymentMethod | ''>('');
  const [montantSaisi, setMontantSaisi] = useState('');
  const [ticketOpen, setTicketOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // Alerte réelle : commandes en ligne en attente (+ bip à chaque nouvelle commande)
  const pendingOnline = useMemo(
    () => commandes.filter(c => c.type === 'EN_LIGNE' && c.status === 'EN_COURS'),
    [commandes]
  );
  const prevCount = useRef<number | null>(null);
  useEffect(() => {
    if (prevCount.current !== null && pendingOnline.length > prevCount.current) beep();
    prevCount.current = pendingOnline.length;
  }, [pendingOnline.length]);

  const filteredPlats = useMemo(
    () => plats.filter(p => p.isActive && (cat === 'all' || p.category === cat)),
    [plats, cat]
  );

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const paid = splits.reduce((s, sp) => s + sp.applique, 0);
  const reste = Math.max(0, total - paid);
  const canClose = cart.length > 0 && reste <= 0 && !busy;

  const montantNum = parseFloat(montantSaisi) || 0;
  const rendu = mode === 'ESPECE' && montantNum > reste && reste > 0 ? montantNum - reste : 0;

  const addToCart = (platId: string) => {
    const p = plats.find(x => x.id === platId);
    if (!p) return;
    const inCart = cart.find(i => i.platId === platId)?.qty ?? 0;
    if (p.isStocked && inCart + 1 > p.stock) { showToast(`${p.name} : stock insuffisant`); return; }
    setCart(prev => prev.some(i => i.platId === platId)
      ? prev.map(i => i.platId === platId ? { ...i, qty: i.qty + 1 } : i)
      : [...prev, { platId, name: p.name, price: p.price, qty: 1 }]);
  };

  const changeQty = (platId: string, delta: number) => {
    if (delta > 0) { addToCart(platId); return; }
    setCart(prev => prev.map(i => i.platId === platId ? { ...i, qty: i.qty - 1 } : i).filter(i => i.qty > 0));
  };

  const addSplit = () => {
    if (!mode) { showToast('Choisir un mode de paiement'); return; }
    if (!montantNum) { showToast('Saisir un montant'); return; }
    setSplits(prev => [...prev, { method: mode, applique: Math.min(montantNum, reste) }]);
    setMontantSaisi(''); setMode('');
  };

  const resetOrder = () => {
    setCart([]); setSplits([]); setClientNom(''); setClientTel(''); setMontantSaisi(''); setMode('');
  };

  const validerCommande = async () => {
    if (!canClose) return;
    setBusy(true);
    const r = await act(() => createStaffOrder({
      clientName: clientNom.trim() || undefined,
      type: orderType,
      items: cart.map(i => ({ platId: i.platId, quantity: i.qty })),
      payments: splits.map(sp => ({ method: sp.method, amount: sp.applique })),
    }), 'Commande clôturée — statut : Payée');
    setBusy(false);
    if (r.ok) resetOrder();
  };

  const ticketText = (): string => [
    'RESTAURANT YIKÉLI', 'Djorogobité 1, 206 — Abidjan', '+225 05 01 14 92 44',
    '----------------------------',
    `Client : ${clientNom || 'Comptoir'}`,
    `Type   : ${orderType === 'SUR_PLACE' ? 'Sur place' : 'Livraison'}`,
    `Date   : ${new Date().toLocaleDateString('fr-FR')} ${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`,
    '----------------------------',
    ...cart.map(i => `${i.name} x${i.qty} — ${fmtFCFA(i.price * i.qty)}`),
    '----------------------------',
    `TOTAL : ${fmtFCFA(total)}`,
    ...splits.map(sp => `${METHOD_LABELS[sp.method]} : ${fmtFCFA(sp.applique)}`),
    '----------------------------', 'Merci de votre visite !',
  ].join('\n');

  const printTicket = () => {
    if (cart.length === 0) { showToast('Aucun article à imprimer'); return; }
    setTicketOpen(true);
    setTimeout(() => printByClass('print-ticket-only'), 300);
  };

  const sendReceipt = () => {
    if (cart.length === 0) { showToast('Aucun article'); return; }
    if (clientTel.replace(/\D/g, '').length < 8) { showToast('Saisir le téléphone du client'); return; }
    sendWhatsApp(clientTel, ticketText());
  };

  return (
    <div className="flex h-full min-h-[600px]">
      {/* Catalogue */}
      <div className="flex-1 flex flex-col border-r border-zinc-200 min-w-0">
        <div className="bg-white border-b border-zinc-200 px-4 py-3 flex items-center justify-between">
          <div>
            <div className="text-sm font-medium">Caisse — Yikéli</div>
            <div className="text-[11px] text-zinc-500">{user?.name}</div>
          </div>
          <div className="text-xs text-zinc-500">{new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</div>
        </div>

        {pendingOnline.length > 0 && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center gap-2 text-xs text-amber-800">
            <span>🔔</span>
            <span className="flex-1">
              {pendingOnline.length} commande{pendingOnline.length > 1 ? 's' : ''} en ligne en attente — dernière : {pendingOnline[0].clientName} · {fmtFCFA(pendingOnline[0].total)}
            </span>
            {onViewOrders && <BtnPrimary onClick={onViewOrders} className="!py-1 !px-2 !text-[10px]">Voir</BtnPrimary>}
          </div>
        )}

        <div className="px-4 pt-3 flex gap-2">
          {(['SUR_PLACE', 'LIVRAISON'] as const).map(t => (
            <button key={t} onClick={() => setOrderType(t)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium border cursor-pointer ${orderType === t ? 'border-orange-400 bg-orange-50 text-orange-600' : 'border-zinc-300 bg-white text-zinc-500'}`}>
              {t === 'SUR_PLACE' ? '🍽 Sur place' : '🛵 Livraison'}
            </button>
          ))}
        </div>

        <div className="px-4 py-3 flex gap-2 flex-wrap">
          {(['all', 'PLATS_IVOIRIENS', 'BOISSONS'] as const).map(c => (
            <button key={c} onClick={() => setCat(c)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border cursor-pointer ${cat === c ? 'bg-orange-500 text-white border-orange-500' : 'border-zinc-300 bg-white text-zinc-500 hover:border-orange-400'}`}>
              {c === 'all' ? 'Tout' : c === 'PLATS_IVOIRIENS' ? 'Plats' : 'Boissons'}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredPlats.map(p => {
              const out = p.isStocked && p.stock <= 0;
              const low = p.isStocked && !out && p.stock <= p.lowStockAlert;
              return (
                <button key={p.id} disabled={out} onClick={() => addToCart(p.id)}
                  className={`relative text-left bg-white border rounded-xl overflow-hidden ${out ? 'opacity-40 cursor-not-allowed border-zinc-200' : 'cursor-pointer border-zinc-200 hover:border-orange-400'}`}>
                  <ProductImage src={p.imageUrl} name={p.name} category={p.category} className="w-full h-24" />
                  <div className="p-3">
                    <div className="text-xs font-medium leading-tight mb-1">{p.name}</div>
                    <div className="text-sm font-medium text-orange-500">{fmtFCFA(p.price)}</div>
                    {p.isStocked && (
                      <div className={`text-[10px] mt-1 ${out ? 'text-red-500' : low ? 'text-amber-600' : 'text-zinc-400'}`}>
                        {out ? 'Rupture' : `Stock : ${p.stock}`}
                      </div>
                    )}
                  </div>
                  {!out && <span className="absolute top-2 right-2 w-6 h-6 rounded-full bg-orange-500 text-white flex items-center justify-center text-base leading-none shadow">+</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Panier + paiement */}
      <div className="w-[340px] flex-shrink-0 bg-white flex flex-col">
        <div className="px-4 py-3 border-b border-zinc-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Commande</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-100 text-zinc-500">{orderType === 'SUR_PLACE' ? 'Sur place' : 'Livraison'}</span>
          </div>
          <div className="flex flex-col gap-2">
            <Input placeholder="Nom du client (optionnel)" value={clientNom} onChange={e => setClientNom(e.target.value)} />
            <Input type="tel" placeholder="Téléphone (reçu WhatsApp, fidélité)" value={clientTel} onChange={e => setClientTel(e.target.value)} />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-2">
          {cart.length === 0 ? (
            <div className="text-center py-10 text-xs text-zinc-400">Aucun plat sélectionné</div>
          ) : cart.map(item => (
            <div key={item.platId} className="flex items-center gap-2 py-2 border-b border-zinc-100 last:border-0">
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium truncate">{item.name}</div>
                <div className="text-[10px] text-zinc-400">{fmtFCFA(item.price)} / u</div>
              </div>
              <div className="flex items-center gap-1.5">
                <button onClick={() => changeQty(item.platId, -1)} className="w-6 h-6 rounded-full border border-orange-300 bg-orange-50 text-orange-700 cursor-pointer">−</button>
                <span className="text-xs font-medium w-4 text-center">{item.qty}</span>
                <button onClick={() => changeQty(item.platId, 1)} className="w-6 h-6 rounded-full border border-orange-300 bg-orange-50 text-orange-700 cursor-pointer">+</button>
              </div>
              <div className="text-xs font-medium w-16 text-right">{fmtFCFA(item.price * item.qty)}</div>
            </div>
          ))}
        </div>

        <div className="border-t border-zinc-200 px-4 py-3">
          <div className="bg-zinc-100 rounded-lg p-3 mb-3 text-xs">
            <div className="flex justify-between mb-1"><span className="text-zinc-500">Total</span><span className="font-medium">{fmtFCFA(total)}</span></div>
            <div className="flex justify-between mb-1"><span className="text-zinc-500">Déjà réglé</span><span>{fmtFCFA(paid)}</span></div>
            <div className="flex justify-between font-medium text-amber-600"><span>Reste à payer</span><span>{fmtFCFA(reste)}</span></div>
          </div>

          {splits.map((sp, i) => (
            <div key={i} className="flex items-center gap-2 text-xs bg-zinc-100 rounded-lg px-2 py-1.5 mb-1">
              <span className="flex-1">{METHOD_LABELS[sp.method]}</span>
              <span className="font-medium">{fmtFCFA(sp.applique)}</span>
              <button onClick={() => setSplits(s => s.filter((_, j) => j !== i))} aria-label="Retirer ce règlement" className="text-red-400 hover:text-red-600 cursor-pointer border-none bg-transparent">✕</button>
            </div>
          ))}

          {reste > 0 && cart.length > 0 && (
            <>
              <div className="text-[10px] font-medium text-zinc-500 uppercase tracking-wide my-2">Mode de paiement</div>
              <div className="grid grid-cols-2 gap-1.5 mb-2">
                {(Object.keys(METHOD_LABELS) as PaymentMethod[]).map(m => (
                  <button key={m} onClick={() => setMode(m)}
                    className={`py-2 rounded-lg text-[10px] font-medium border cursor-pointer ${mode === m ? 'border-orange-400 bg-orange-100 text-orange-700' : 'border-zinc-200 bg-zinc-50 text-zinc-500 hover:border-orange-300'}`}>
                    {METHOD_LABELS[m]}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 mb-2">
                <Input type="number" placeholder="Montant reçu (FCFA)" value={montantSaisi} onChange={e => setMontantSaisi(e.target.value)} />
                {rendu > 0 && <div className="text-[10px] bg-blue-50 text-blue-600 rounded-lg px-2 flex items-center whitespace-nowrap">Rendu : {fmtFCFA(rendu)}</div>}
              </div>
              <BtnSecondary onClick={addSplit} className="w-full justify-center mb-2">+ Ajouter ce règlement</BtnSecondary>
            </>
          )}

          <div className="grid grid-cols-2 gap-2">
            <BtnSecondary onClick={printTicket} className="justify-center">🖨 Ticket</BtnSecondary>
            <BtnPrimary onClick={validerCommande} disabled={!canClose} className="justify-center">{busy ? 'Envoi…' : 'Clôturer ✓'}</BtnPrimary>
          </div>
          <BtnSecondary onClick={sendReceipt} className="w-full justify-center mt-2">📲 Envoyer le reçu par WhatsApp</BtnSecondary>
        </div>
      </div>

      <Modal open={ticketOpen} title="Aperçu ticket thermique (72 mm)" onClose={() => setTicketOpen(false)}>
        <div className="printable-ticket-element bg-white text-black font-mono text-xs p-4 rounded border border-zinc-300 w-[260px] mx-auto">
          <div className="text-center font-bold">RESTAURANT YIKÉLI</div>
          <div className="text-center text-[10px]">Djorogobité 1, 206 — Abidjan</div>
          <div className="text-center text-[10px]">+225 05 01 14 92 44</div>
          <div className="border-t border-dashed border-zinc-400 my-2" />
          <div className="flex justify-between"><span>Client</span><span>{clientNom || 'Comptoir'}</span></div>
          <div className="flex justify-between"><span>Type</span><span>{orderType === 'SUR_PLACE' ? 'Sur place' : 'Livraison'}</span></div>
          <div className="flex justify-between"><span>Date</span><span>{new Date().toLocaleDateString('fr-FR')}</span></div>
          <div className="border-t border-dashed border-zinc-400 my-2" />
          {cart.map(i => (
            <div key={i.platId} className="flex justify-between text-[10px]"><span>{i.name} x{i.qty}</span><span>{fmtFCFA(i.price * i.qty)}</span></div>
          ))}
          <div className="border-t border-dashed border-zinc-400 my-2" />
          <div className="flex justify-between font-bold"><span>TOTAL</span><span>{fmtFCFA(total)}</span></div>
          {splits.map((sp, i) => (
            <div key={i} className="flex justify-between text-[10px]"><span>{METHOD_LABELS[sp.method]}</span><span>{fmtFCFA(sp.applique)}</span></div>
          ))}
          <div className="border-t border-dashed border-zinc-400 my-2" />
          <div className="text-center text-[10px]">Merci pour votre visite !</div>
        </div>
      </Modal>
    </div>
  );
};
