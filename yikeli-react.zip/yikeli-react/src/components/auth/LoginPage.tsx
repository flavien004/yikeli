import React, { useState } from 'react';
import { useAuth } from '../../hooks/AuthContext';
import { errorMessage } from '../../lib/api';
import { BtnPrimary, Field, Input, PasswordInput } from '../shared';

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await login(email.trim(), password);
    } catch (err) {
      setError(errorMessage(err));
      setPassword('');           // le mot de passe ne reste jamais en mémoire d'interface après un échec
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="h-full flex items-center justify-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm bg-white border border-zinc-200 rounded-2xl p-6 shadow-sm flex flex-col gap-4">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-orange-500 text-white flex items-center justify-center text-xl font-medium mx-auto mb-3">Y</div>
          <h1 className="text-base font-medium">Espace équipe Yikéli</h1>
          <p className="text-xs text-zinc-500 mt-1">Connectez-vous avec votre compte</p>
        </div>
        <Field label="Email">
          <Input type="email" autoComplete="username" required value={email} onChange={e => setEmail(e.target.value)} placeholder="vous@yikeli.ci" />
        </Field>
        <Field label="Mot de passe">
          <PasswordInput autoComplete="current-password" required value={password} onChange={e => setPassword(e.target.value)} />
        </Field>
        {error && <div role="alert" className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</div>}
        <BtnPrimary type="submit" disabled={busy || !email || !password} className="w-full justify-center py-2.5">
          {busy ? 'Connexion…' : 'Se connecter'}
        </BtnPrimary>
      </form>
    </div>
  );
};
