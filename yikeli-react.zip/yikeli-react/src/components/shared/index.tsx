// ============================================================
// YIKÉLI — Composants partagés (src/components/shared/index.tsx)
// ============================================================
import React, { useEffect, useState, useCallback } from 'react';

// ── MODAL ────────────────────────────────────────────────────
interface ModalProps {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
  wide?: boolean;
}
export const Modal: React.FC<ModalProps> = ({ open, title, onClose, children, footer, wide }) => {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 bg-black/40 flex items-start justify-center z-50 pt-14"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className={`bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-700 overflow-hidden shadow-xl ${wide ? 'w-[460px]' : 'w-[380px]'}`}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-200 dark:border-zinc-700">
          <span className="text-sm font-medium text-zinc-900 dark:text-zinc-100">{title}</span>
          <button onClick={onClose} className="w-6 h-6 rounded-full border border-zinc-300 dark:border-zinc-600 flex items-center justify-center text-zinc-500 hover:text-zinc-800 text-xs">✕</button>
        </div>
        <div className="p-4 flex flex-col gap-3 max-h-[70vh] overflow-y-auto">{children}</div>
        {footer && (
          <div className="px-4 py-3 border-t border-zinc-200 dark:border-zinc-700 flex gap-2 justify-end">{footer}</div>
        )}
      </div>
    </div>
  );
};

// ── CONFIRM ──────────────────────────────────────────────────
interface ConfirmProps {
  open: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
  confirmLabel?: string;
}
export const Confirm: React.FC<ConfirmProps> = ({ open, title, message, onConfirm, onCancel, confirmLabel = 'Supprimer' }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex items-start justify-center z-50 pt-14"
      onClick={(e) => e.target === e.currentTarget && onCancel()}>
      <div className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-700 w-80 p-5 shadow-xl">
        <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center mb-3">
          <span className="text-red-500 text-lg">⚠</span>
        </div>
        <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100 mb-2">{title}</p>
        <p className="text-xs text-zinc-500 mb-4 leading-relaxed">{message}</p>
        <div className="flex gap-2 justify-end">
          <BtnSecondary onClick={onCancel}>Annuler</BtnSecondary>
          <button onClick={onConfirm} className="px-3 py-2 rounded-lg border-none bg-red-500 text-white text-xs font-medium cursor-pointer hover:bg-red-600">{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
};

// ── TOAST ────────────────────────────────────────────────────
interface ToastMsg { id: string; msg: string; }
let toastListeners: Array<(msg: string) => void> = [];
export const showToast = (msg: string) => toastListeners.forEach(fn => fn(msg));

export const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  useEffect(() => {
    const fn = (msg: string) => {
      const id = Math.random().toString(36).slice(2);
      setToasts(t => [...t, { id, msg }]);
      setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2400);
    };
    toastListeners.push(fn);
    return () => { toastListeners = toastListeners.filter(x => x !== fn); };
  }, []);
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 flex flex-col gap-2 z-[100] pointer-events-none">
      {toasts.map(t => (
        <div key={t.id} className="bg-green-900 text-green-200 text-xs px-4 py-2 rounded-lg shadow-lg whitespace-nowrap animate-fade-in">
          {t.msg}
        </div>
      ))}
    </div>
  );
};

// ── TOGGLE ───────────────────────────────────────────────────
interface ToggleProps { checked: boolean; onChange: (v: boolean) => void; }
export const Toggle: React.FC<ToggleProps> = ({ checked, onChange }) => (
  <button
    role="switch"
    aria-checked={checked}
    onClick={() => onChange(!checked)}
    className={`relative w-9 h-5 rounded-full border-none cursor-pointer transition-colors duration-200 ${checked ? 'bg-orange-500' : 'bg-zinc-300 dark:bg-zinc-600'}`}
  >
    <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all duration-200 ${checked ? 'left-[18px]' : 'left-0.5'}`} />
  </button>
);

// ── BADGE STATUT ─────────────────────────────────────────────
type StatusType = 'EN_COURS' | 'ACCEPTEE' | 'SERVIE' | 'PAYEE' | 'ANNULEE';
const STATUS_STYLES: Record<StatusType, string> = {
  EN_COURS: 'bg-amber-100 text-amber-700',
  ACCEPTEE: 'bg-blue-100 text-blue-700',
  SERVIE:   'bg-sky-100 text-sky-700',
  PAYEE:    'bg-green-100 text-green-700',
  ANNULEE:  'bg-red-100 text-red-700',
};
const STATUS_LABELS: Record<StatusType, string> = {
  EN_COURS: 'En cours', ACCEPTEE: 'Acceptée', SERVIE: 'Servie', PAYEE: 'Payée', ANNULEE: 'Annulée',
};
export const StatusBadge: React.FC<{ status: StatusType }> = ({ status }) => (
  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${STATUS_STYLES[status]}`}>
    {STATUS_LABELS[status]}
  </span>
);

// ── BOUTONS ──────────────────────────────────────────────────
interface BtnProps extends React.ButtonHTMLAttributes<HTMLButtonElement> { children: React.ReactNode; }
export const BtnPrimary: React.FC<BtnProps> = ({ children, className = '', ...props }) => (
  <button className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border-none bg-orange-500 text-white text-xs font-medium cursor-pointer hover:bg-orange-600 disabled:opacity-40 disabled:cursor-not-allowed ${className}`} {...props}>{children}</button>
);
export const BtnSecondary: React.FC<BtnProps> = ({ children, className = '', ...props }) => (
  <button className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-orange-300 bg-orange-50 text-orange-700 text-xs font-medium cursor-pointer hover:bg-orange-100 disabled:opacity-40 disabled:cursor-not-allowed ${className}`} {...props}>{children}</button>
);

// ── FORM FIELDS ──────────────────────────────────────────────
interface FieldProps { label: string; children: React.ReactNode; hint?: string; }
export const Field: React.FC<FieldProps> = ({ label, children, hint }) => (
  <div className="flex flex-col gap-1">
    <label className="text-[10px] font-medium text-zinc-500 uppercase tracking-wide">{label}</label>
    {children}
    {hint && <span className="text-[10px] text-zinc-400">{hint}</span>}
  </div>
);

export const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = ({ className = '', ...props }) => (
  <input className={`text-xs px-2.5 py-2 rounded-lg border border-zinc-300 bg-white text-zinc-900 focus:outline-none focus:border-orange-400 focus:ring-1 focus:ring-orange-200 w-full disabled:bg-zinc-100 disabled:text-zinc-400 ${className}`} {...props} />
);

export const Select: React.FC<React.SelectHTMLAttributes<HTMLSelectElement>> = ({ children, ...props }) => (
  <select className="text-xs px-2.5 py-2 rounded-lg border border-zinc-300 dark:border-zinc-600 bg-zinc-50 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 focus:outline-none focus:border-orange-400 w-full" {...props}>{children}</select>
);

export const Textarea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => (
  <textarea className="text-xs px-2.5 py-2 rounded-lg border border-zinc-300 dark:border-zinc-600 bg-zinc-50 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 focus:outline-none focus:border-orange-400 w-full resize-none leading-relaxed" {...props} />
);

// ── IFRAME BANNER ────────────────────────────────────────────
export const IframeBanner: React.FC = () => {
  const [show, setShow] = useState(false);
  useEffect(() => { setShow(window.self !== window.top); }, []);
  if (!show) return null;
  return (
    <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center gap-3 text-xs text-amber-800">
      <span>⚠️ L'impression et certaines fonctionnalités nécessitent un onglet autonome.</span>
      <button onClick={() => window.open(window.location.href, '_blank')} className="underline font-medium">Ouvrir dans un nouvel onglet ↗</button>
      <button onClick={() => setShow(false)} className="ml-auto text-amber-500">✕</button>
    </div>
  );
};

// ── KPI CARD ─────────────────────────────────────────────────
interface KpiProps { label: string; value: string; color?: string; }
export const KpiCard: React.FC<KpiProps> = ({ label, value, color = 'text-zinc-900 dark:text-zinc-100' }) => (
  <div className="bg-zinc-100 dark:bg-zinc-800 rounded-xl p-3">
    <div className="text-[11px] text-zinc-500 mb-1">{label}</div>
    <div className={`text-lg font-medium ${color}`}>{value}</div>
  </div>
);


// ── IMAGE PRODUIT (avec repli coloré si pas d'image) ─────────
const FALLBACK_BG = ['#FFE8D1', '#FFF0C9', '#E3F3DC', '#E0EEFA', '#F5E3F2'];
export const ProductImage: React.FC<{ src?: string | null; name: string; category?: string; className?: string }> = ({ src, name, category, className = '' }) => {
  const [failed, setFailed] = useState(false);
  if (src && !failed) {
    return <img src={src} alt={name} loading="lazy" onError={() => setFailed(true)} className={`object-cover ${className}`} />;
  }
  const bg = FALLBACK_BG[(name.charCodeAt(0) || 0) % FALLBACK_BG.length];
  return (
    <div className={`flex items-center justify-center text-orange-600 ${className}`} style={{ background: bg }} aria-label={name} role="img">
      <span className="text-xl">{category === 'BOISSONS' ? '🥤' : '🍲'}</span>
    </div>
  );
};

// ── MOT DE PASSE (affichage masqué par défaut, jamais persisté) ──
export const PasswordInput: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => {
  const [visible, setVisible] = useState(false);
  return (
    <div className="relative">
      <Input {...props} type={visible ? 'text' : 'password'} className="pr-16" />
      <button type="button" onClick={() => setVisible(v => !v)}
        className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-orange-600 cursor-pointer bg-transparent border-none">
        {visible ? 'Masquer' : 'Afficher'}
      </button>
    </div>
  );
};
