// Configuration : types de dépense (ajout / renommage / suppression) et solde initial de trésorerie.
import React, { useEffect, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { ExpCategory } from '../../types';
import { fmtFCFA } from '../../utils';
import { act } from '../../lib/act';
import { Confirm, BtnPrimary, BtnSecondary, Field, Input, Modal, showToast } from '../shared';

export const ConfigTab: React.FC = () => {
  const { state, saveCategory, deleteCategory, saveSoldeInitial } = useApp();
  const [newName, setNewName] = useState('');
  const [rename, setRename] = useState<{ cat: ExpCategory; name: string } | null>(null);
  const [confirm, setConfirm] = useState<{ open: boolean; cat?: ExpCategory }>({ open: false });
  const [solde, setSolde] = useState(String(state.soldeInitial));
  useEffect(() => setSolde(String(state.soldeInitial)), [state.soldeInitial]);

  const usage = (name: string) => state.depenses.filter(d => d.category === name).length;

  const add = async () => {
    const name = newName.trim();
    if (!name) { showToast('Saisir un nom'); return; }
    const r = await act(() => saveCategory(null, name), `Type « ${name} » ajouté`);
    if (r.ok) setNewName('');
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-white border border-zinc-200 rounded-xl p-4">
        <div className="text-sm font-medium mb-1">Types de dépense</div>
        <div className="text-[11px] text-zinc-400 mb-3">Ces types alimentent les formulaires de dépenses et la comptabilité.</div>
        <div className="flex gap-2 mb-4">
          <Input value={newName} maxLength={60} onChange={e => setNewName(e.target.value)} placeholder="Ex : Gaz, Emballages, Publicité…" onKeyDown={e => e.key === 'Enter' && void add()} />
          <BtnPrimary onClick={add} className="whitespace-nowrap">+ Ajouter</BtnPrimary>
        </div>
        {state.expCategories.map(c => (
          <div key={c.id} className="flex items-center gap-2 py-2 border-b border-zinc-100 last:border-0 text-xs">
            <span className="flex-1 font-medium">{c.name}
              {c.isSystem && <span className="ml-2 text-[9px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-500">🔒 Protégé</span>}
            </span>
            <span className="text-[10px] text-zinc-400">{usage(c.name)} dépense{usage(c.name) > 1 ? 's' : ''}</span>
            {!c.isSystem && (
              <>
                <button onClick={() => setRename({ cat: c, name: c.name })} aria-label={`Renommer ${c.name}`} className="w-7 h-7 rounded border border-orange-200 bg-orange-50 text-xs cursor-pointer hover:bg-orange-100">✏</button>
                <button onClick={() => setConfirm({ open: true, cat: c })} aria-label={`Supprimer ${c.name}`} className="w-7 h-7 rounded border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>
              </>
            )}
          </div>
        ))}
      </div>

      <div className="bg-white border border-zinc-200 rounded-xl p-4 h-fit">
        <div className="text-sm font-medium mb-1">Trésorerie</div>
        <div className="text-[11px] text-zinc-400 mb-3">Solde de départ du journal des opérations.</div>
        <Field label="Solde initial (FCFA)" hint={`Actuel : ${fmtFCFA(state.soldeInitial)}`}>
          <Input type="number" value={solde} onChange={e => setSolde(e.target.value)} />
        </Field>
        <BtnPrimary className="mt-3" onClick={() => {
          if (solde === '' || !Number.isFinite(+solde)) { showToast('Montant invalide'); return; }
          void act(() => saveSoldeInitial(Math.round(+solde)), 'Solde initial enregistré');
        }}>Enregistrer</BtnPrimary>
      </div>

      <Modal open={!!rename} title="Renommer le type" onClose={() => setRename(null)}
        footer={<><BtnSecondary onClick={() => setRename(null)}>Annuler</BtnSecondary>
          <BtnPrimary onClick={async () => { if (!rename) return; const r = await act(() => saveCategory(rename.cat.id, rename.name.trim()), 'Type renommé'); if (r.ok) setRename(null); }}>Enregistrer</BtnPrimary></>}>
        {rename && <Field label="Nom" hint="Les dépenses existantes suivent automatiquement."><Input value={rename.name} maxLength={60} onChange={e => setRename({ ...rename, name: e.target.value })} /></Field>}
      </Modal>

      <Confirm open={confirm.open} title="Supprimer ce type ?" message={`« ${confirm.cat?.name ?? ''} » sera supprimé. Impossible s’il est utilisé par des dépenses.`}
        onConfirm={async () => { if (confirm.cat) await act(() => deleteCategory(confirm.cat!.id), 'Type supprimé'); setConfirm({ open: false }); }}
        onCancel={() => setConfirm({ open: false })} />
    </div>
  );
};
