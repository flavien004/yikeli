import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { PaymentMethod } from '../../types';
import { fmtFCFA, METHOD_LABELS, getRemaining } from '../../utils';
import { act } from '../../lib/act';
import { Confirm, BtnPrimary, Field, Input, KpiCard, Select, showToast } from '../shared';

export const PaiementsTab: React.FC = () => {
  const { state, addPaiement, deletePaiement } = useApp();
  const [cmd, setCmd] = useState('');
  const [mode, setMode] = useState<PaymentMethod>('ESPECE');
  const [mnt, setMnt] = useState('');
  const [confirm, setConfirm] = useState<{ open: boolean; id: string }>({ open: false, id: '' });

  const open = useMemo(() => state.commandes.filter(c => c.status !== 'PAYEE' && c.status !== 'ANNULEE'), [state.commandes]);
  const total = state.paiements.reduce((s, p) => s + p.amount, 0);
  const pending = open.reduce((s, c) => s + getRemaining(c, state.paiements), 0);
  const selected = open.find(c => c.id === cmd);
  const sorted = useMemo(() => [...state.paiements].sort((a, b) => b.createdAt.localeCompare(a.createdAt)), [state.paiements]);

  const submit = async () => {
    if (!selected) { showToast('Sélectionner une commande'); return; }
    const amount = Math.round(+mnt);
    if (!(amount > 0)) { showToast('Saisir un montant'); return; }
    const r = await act(() => addPaiement(selected.id, mode, amount), 'Paiement enregistré');
    if (r.ok) { setMnt(''); setCmd(''); }
  };

  return (
    <>
      <div className="grid grid-cols-3 gap-3 mb-4">
        <KpiCard label="Total encaissé" value={fmtFCFA(total)} color="text-green-600" />
        <KpiCard label="Transactions" value={String(state.paiements.length)} />
        <KpiCard label="Soldes en attente" value={fmtFCFA(pending)} color={pending > 0 ? 'text-amber-600' : undefined} />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white border border-zinc-200 rounded-xl p-4">
          <div className="text-sm font-medium mb-3">Historique des paiements</div>
          {sorted.length === 0 && <div className="text-xs text-zinc-400 py-8 text-center">Aucun paiement</div>}
          {sorted.map(p => {
            const c = state.commandes.find(x => x.id === p.commandeId);
            const who = state.users.find(u => u.id === p.userId)?.name;
            return (
              <div key={p.id} className="flex items-center gap-3 py-2.5 border-b border-zinc-100 last:border-0 text-xs">
                <div className="flex-1">
                  <div className="font-medium">{c?.clientName ?? '—'}</div>
                  <div className="text-[10px] text-zinc-400">{new Date(p.createdAt).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}{who ? ` · ${who}` : ''}</div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-100 text-orange-700">{METHOD_LABELS[p.method]}</span>
                <span className="font-medium w-20 text-right">{fmtFCFA(p.amount)}</span>
                <button onClick={() => setConfirm({ open: true, id: p.id })} aria-label="Supprimer le paiement" className="w-7 h-7 rounded border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>
              </div>
            );
          })}
        </div>
        <div className="bg-white border border-zinc-200 rounded-xl p-4 h-fit">
          <div className="text-sm font-medium mb-3">Enregistrer un paiement</div>
          <div className="flex flex-col gap-3">
            <Field label="Commande non soldée">
              <Select value={cmd} onChange={e => setCmd(e.target.value)}>
                <option value="">— Sélectionner —</option>
                {open.map(c => <option key={c.id} value={c.id}>{c.clientName} · reste {fmtFCFA(getRemaining(c, state.paiements))}</option>)}
              </Select>
            </Field>
            <Field label="Mode"><Select value={mode} onChange={e => setMode(e.target.value as PaymentMethod)}>{(Object.keys(METHOD_LABELS) as PaymentMethod[]).map(m => <option key={m} value={m}>{METHOD_LABELS[m]}</option>)}</Select></Field>
            <Field label="Montant (FCFA)" hint={selected ? `Reste à payer : ${fmtFCFA(getRemaining(selected, state.paiements))}` : undefined}>
              <Input type="number" min={1} value={mnt} onChange={e => setMnt(e.target.value)} />
            </Field>
            <BtnPrimary onClick={submit} className="w-full justify-center">✓ Valider le paiement</BtnPrimary>
          </div>
        </div>
      </div>
      <Confirm open={confirm.open} title="Supprimer ce paiement ?" message="Le paiement sera retiré ; si la commande était « Payée », elle repasse « En cours »."
        onConfirm={async () => { await act(() => deletePaiement(confirm.id), 'Paiement supprimé'); setConfirm({ open: false, id: '' }); }}
        onCancel={() => setConfirm({ open: false, id: '' })} />
    </>
  );
};
