// Menu & stock des plats/boissons, avec image produit (envoyée vers Supabase Storage via l'API).
import React, { useMemo, useRef, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { Plat } from '../../types';
import { fmtFCFA } from '../../utils';
import { act } from '../../lib/act';
import { prepareImage, type PreparedImage } from '../../lib/image';
import {
  Modal, Confirm, BtnPrimary, BtnSecondary, Toggle, Field, Input, Select, KpiCard, ProductImage, showToast,
} from '../shared';

interface Form {
  name: string; price: string; category: Plat['category']; isActive: boolean; isStocked: boolean;
  stock: string; lowStockAlert: string; expirationDelay: string; imageUrl?: string;
}
const emptyForm: Form = {
  name: '', price: '', category: 'PLATS_IVOIRIENS', isActive: true, isStocked: false,
  stock: '', lowStockAlert: '', expirationDelay: '',
};

export const MenuTab: React.FC = () => {
  const { state, savePlat, deletePlat, uploadImage } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<Form>(emptyForm);
  const [newImage, setNewImage] = useState<PreparedImage | null>(null);
  const [removeImage, setRemoveImage] = useState(false);
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState<{ open: boolean; id: string; name: string }>({ open: false, id: '', name: '' });
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const low = state.plats.filter(p => p.isStocked && p.stock <= p.lowStockAlert);
  const filtered = useMemo(() => state.plats.filter(p =>
    (filter === 'all' || p.category === filter) &&
    (!search || p.name.toLowerCase().includes(search.toLowerCase()))
  ), [state.plats, filter, search]);

  const openModal = (p?: Plat) => {
    setEditId(p?.id ?? null);
    setNewImage(null); setRemoveImage(false);
    setForm(p ? {
      name: p.name, price: String(p.price), category: p.category, isActive: p.isActive, isStocked: p.isStocked,
      stock: String(p.stock), lowStockAlert: String(p.lowStockAlert), expirationDelay: p.expirationDelay ?? '', imageUrl: p.imageUrl,
    } : emptyForm);
    setModalOpen(true);
  };

  const pickImage = async (file?: File) => {
    if (!file) return;
    try { setNewImage(await prepareImage(file)); setRemoveImage(false); }
    catch (e) { showToast(e instanceof Error ? e.message : 'Image invalide'); }
  };

  const save = async () => {
    if (!form.name.trim()) { showToast('Saisir un nom'); return; }
    const price = Math.round(+form.price);
    if (!(price >= 0) || form.price === '') { showToast('Saisir un prix'); return; }
    setBusy(true);
    let imageUrl: string | null | undefined = form.imageUrl;
    if (newImage) {
      const up = await act(() => uploadImage(newImage));
      if (!up.ok) { setBusy(false); return; }
      imageUrl = up.value;
    } else if (removeImage) imageUrl = null;

    const payload = {
      name: form.name.trim(), price, category: form.category, isActive: form.isActive, isStocked: form.isStocked,
      stock: form.isStocked ? Math.max(0, Math.round(+form.stock || 0)) : 0,
      lowStockAlert: form.isStocked ? Math.max(0, Math.round(+form.lowStockAlert || 0)) : 0,
      expirationDelay: form.expirationDelay.trim() || undefined,
      imageUrl: imageUrl ?? null,
    };
    const r = await act(() => savePlat(editId, payload), editId ? 'Plat modifié' : 'Plat ajouté');
    setBusy(false);
    if (r.ok) setModalOpen(false);
  };

  const preview = newImage?.previewUrl ?? (removeImage ? undefined : form.imageUrl);

  return (
    <>
      {low.length > 0 && (
        <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4 text-xs text-amber-700">
          <span className="text-base">⚠️</span>
          <div><div className="font-medium mb-1">Alertes réapprovisionnement</div>
            <div>{low.map(p => `${p.name} (${p.stock} restant${p.stock > 1 ? 's' : ''})`).join(' · ')}</div></div>
        </div>
      )}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <KpiCard label="Plats au catalogue" value={String(state.plats.length)} />
        <KpiCard label="Stock surveillé" value={String(state.plats.filter(p => p.isStocked).length)} />
        <KpiCard label="Sous le seuil" value={String(low.length)} color={low.length ? 'text-amber-600' : undefined} />
      </div>

      <div className="bg-white border border-zinc-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <span className="text-sm font-medium">Catalogue des plats</span>
          <div className="flex gap-2 flex-wrap">
            <Input placeholder="Rechercher…" value={search} onChange={e => setSearch(e.target.value)} style={{ width: 140 }} />
            <Select value={filter} onChange={e => setFilter(e.target.value)} style={{ width: 130 }}>
              <option value="all">Tous</option><option value="PLATS_IVOIRIENS">Plats</option><option value="BOISSONS">Boissons</option>
            </Select>
            <BtnPrimary onClick={() => openModal()}>+ Nouveau plat</BtnPrimary>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead><tr>
              {['', 'Plat', 'Prix', 'Actif', 'Surveillé', 'Stock', 'Conservation', ''].map((h, i) => (
                <th key={i} className="text-left text-[10px] font-medium text-zinc-400 uppercase tracking-wide pb-2 border-b border-zinc-100 pr-3">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {filtered.map(p => {
                const st = !p.isStocked ? 'none' : p.stock <= 0 ? 'rupture' : p.stock <= p.lowStockAlert ? 'low' : 'ok';
                return (
                  <tr key={p.id} className="border-b border-zinc-100 last:border-0">
                    <td className="py-2 pr-3"><ProductImage src={p.imageUrl} name={p.name} category={p.category} className="w-10 h-10 rounded-lg" /></td>
                    <td className="pr-3"><div className="font-medium">{p.name}</div><div className="text-[10px] text-zinc-400">{p.category === 'PLATS_IVOIRIENS' ? 'Plat' : 'Boisson'}</div></td>
                    <td className="pr-3 font-medium">{fmtFCFA(p.price)}</td>
                    <td className="pr-3"><Toggle checked={p.isActive} onChange={v => void act(() => savePlat(p.id, { isActive: v }))} /></td>
                    <td className="pr-3"><Toggle checked={p.isStocked} onChange={v => void act(() => savePlat(p.id, { isStocked: v }))} /></td>
                    <td className="pr-3">
                      {p.isStocked
                        ? <span className={`font-medium ${st === 'rupture' ? 'text-red-500' : st === 'low' ? 'text-amber-500' : 'text-green-600'}`}>{p.stock} {st === 'rupture' ? '🔴' : st === 'low' ? '🟡' : ''}</span>
                        : <span className="text-zinc-300">—</span>}
                    </td>
                    <td className="pr-3 text-zinc-500 text-[10px]">{p.expirationDelay || '—'}</td>
                    <td><div className="flex gap-1">
                      <button onClick={() => openModal(p)} aria-label={`Modifier ${p.name}`} className="w-7 h-7 rounded border border-orange-200 bg-orange-50 text-xs cursor-pointer hover:bg-orange-100">✏</button>
                      <button onClick={() => setConfirm({ open: true, id: p.id, name: p.name })} aria-label={`Supprimer ${p.name}`} className="w-7 h-7 rounded border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>
                    </div></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={modalOpen} title={editId ? 'Modifier le plat' : 'Nouveau plat'} onClose={() => setModalOpen(false)}
        footer={<><BtnSecondary onClick={() => setModalOpen(false)}>Annuler</BtnSecondary><BtnPrimary onClick={save} disabled={busy}>{busy ? 'Enregistrement…' : 'Enregistrer'}</BtnPrimary></>}>
        <Field label="Image du produit" hint="JPG, PNG ou WebP — réduite automatiquement (800 px).">
          <div className="flex items-center gap-3">
            <ProductImage src={preview} name={form.name || 'Produit'} category={form.category} className="w-20 h-20 rounded-xl flex-shrink-0" />
            <div className="flex flex-col gap-2">
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={e => { void pickImage(e.target.files?.[0]); e.target.value = ''; }} />
              <BtnSecondary type="button" onClick={() => fileRef.current?.click()}>{preview ? 'Changer l’image' : 'Choisir une image'}</BtnSecondary>
              {preview && <button type="button" onClick={() => { setNewImage(null); setRemoveImage(true); }} className="text-[10px] text-red-500 underline cursor-pointer bg-transparent border-none text-left">Retirer l’image</button>}
            </div>
          </div>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Nom du plat"><Input value={form.name} maxLength={100} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Ex : Attiéké poisson" /></Field>
          <Field label="Catégorie"><Select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as Plat['category'] }))}><option value="PLATS_IVOIRIENS">Plats ivoiriens</option><option value="BOISSONS">Boissons</option></Select></Field>
          <Field label="Prix (FCFA)"><Input type="number" min={0} value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="Ex : 3000" /></Field>
          <Field label="Statut"><Select value={String(form.isActive)} onChange={e => setForm(f => ({ ...f, isActive: e.target.value === 'true' }))}><option value="true">Actif</option><option value="false">Inactif</option></Select></Field>
        </div>
        <div className="flex items-center justify-between p-3 bg-zinc-100 rounded-lg">
          <div><div className="text-xs font-medium">Surveiller le stock</div><div className="text-[10px] text-zinc-400">Active le suivi de quantité et les alertes</div></div>
          <Toggle checked={form.isStocked} onChange={v => setForm(f => ({ ...f, isStocked: v }))} />
        </div>
        {form.isStocked && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Stock actuel"><Input type="number" min={0} value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} /></Field>
            <Field label="Seuil d’alerte"><Input type="number" min={0} value={form.lowStockAlert} onChange={e => setForm(f => ({ ...f, lowStockAlert: e.target.value }))} /></Field>
          </div>
        )}
        <Field label="Délai de conservation / péremption"><Input value={form.expirationDelay} maxLength={100} onChange={e => setForm(f => ({ ...f, expirationDelay: e.target.value }))} placeholder="Ex : 3 jours à +4°C" /></Field>
      </Modal>

      <Confirm open={confirm.open} title="Supprimer ce plat ?" message={`« ${confirm.name} » sera retiré du catalogue (l’historique des commandes est conservé).`}
        onConfirm={async () => { await act(() => deletePlat(confirm.id), 'Plat supprimé'); setConfirm(c => ({ ...c, open: false })); }}
        onCancel={() => setConfirm(c => ({ ...c, open: false }))} />
    </>
  );
};
