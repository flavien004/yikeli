// Ingrédients : approvisionnement ingrédient par ingrédient, ajustements (perte/inventaire),
// historique complet des mouvements avec stock après chaque opération.
import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { Ingredient } from '../../types';
import { fmtFCFA } from '../../utils';
import { act } from '../../lib/act';
import { Modal, Confirm, BtnPrimary, BtnSecondary, Toggle, Field, Input, Select, KpiCard, showToast } from '../shared';

const UNITS = ['kg', 'g', 'L', 'mL', 'unité', 'sachet', 'boîte', 'botte', 'tas'];
const nf = (n: number) => n.toLocaleString('fr-FR', { maximumFractionDigits: 3 });
const fmtDT = (iso: string) => new Date(iso).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

type Dialog = null | { kind: 'edit'; ing: Ingredient | null } | { kind: 'supply'; ing: Ingredient } | { kind: 'adjust'; ing: Ingredient };

export const IngredientsTab: React.FC = () => {
  const { state, saveIngredient, deleteIngredient, supplyIngredient, adjustIngredient } = useApp();
  const { ingredients, ingredientMovements } = state;
  const [dialog, setDialog] = useState<Dialog>(null);
  const [filterIng, setFilterIng] = useState('all');
  const [showArchived, setShowArchived] = useState(false);
  const [confirm, setConfirm] = useState<{ open: boolean; ing?: Ingredient }>({ open: false });

  // formulaires
  const [f, setF] = useState({ name: '', unit: 'kg', lowStockAlert: '', supplier: '' });
  const [s, setS] = useState({ quantity: '', unitCost: '', supplier: '', note: '', recordExpense: true });
  const [a, setA] = useState({ delta: '', note: '' });
  const [busy, setBusy] = useState(false);

  const list = ingredients.filter(i => showArchived || i.isActive);
  const lowList = ingredients.filter(i => i.isActive && i.stock <= i.lowStockAlert);
  const stockValue = ingredients.reduce((sum, i) => sum + i.stock * i.lastUnitCost, 0);
  const nameOf = (id: string) => ingredients.find(i => i.id === id);
  const movements = useMemo(
    () => ingredientMovements.filter(m => filterIng === 'all' || m.ingredientId === filterIng),
    [ingredientMovements, filterIng]
  );

  const open = (d: Dialog) => {
    if (d?.kind === 'edit') setF(d.ing
      ? { name: d.ing.name, unit: d.ing.unit, lowStockAlert: String(d.ing.lowStockAlert), supplier: d.ing.supplier ?? '' }
      : { name: '', unit: 'kg', lowStockAlert: '', supplier: '' });
    if (d?.kind === 'supply') setS({ quantity: '', unitCost: d.ing.lastUnitCost ? String(d.ing.lastUnitCost) : '', supplier: d.ing.supplier ?? '', note: '', recordExpense: true });
    if (d?.kind === 'adjust') setA({ delta: '', note: '' });
    setDialog(d);
  };

  const saveFiche = async () => {
    if (!f.name.trim()) { showToast('Saisir un nom'); return; }
    const payload = { name: f.name.trim(), unit: f.unit, lowStockAlert: Math.max(0, +f.lowStockAlert || 0), supplier: f.supplier.trim() || undefined };
    const ing = dialog?.kind === 'edit' ? dialog.ing : null;
    setBusy(true);
    const r = await act(() => saveIngredient(ing?.id ?? null, payload), ing ? 'Ingrédient modifié' : 'Ingrédient ajouté');
    setBusy(false);
    if (r.ok) setDialog(null);
  };

  const saveSupply = async () => {
    if (dialog?.kind !== 'supply') return;
    const quantity = +s.quantity, unitCost = +s.unitCost || 0;
    if (!(quantity > 0)) { showToast('Saisir une quantité'); return; }
    setBusy(true);
    const r = await act(() => supplyIngredient(dialog.ing.id, {
      quantity, unitCost, supplier: s.supplier.trim() || undefined, note: s.note.trim() || undefined, recordExpense: s.recordExpense && unitCost > 0,
    }), `Approvisionnement enregistré : +${nf(quantity)} ${dialog.ing.unit}`);
    setBusy(false);
    if (r.ok) setDialog(null);
  };

  const saveAdjust = async () => {
    if (dialog?.kind !== 'adjust') return;
    const delta = +a.delta;
    if (!delta) { showToast('Saisir une variation (ex : -0,5)'); return; }
    if (a.note.trim().length < 3) { showToast('Indiquez le motif'); return; }
    setBusy(true);
    const r = await act(() => adjustIngredient(dialog.ing.id, { delta, note: a.note.trim() }), 'Stock ajusté');
    setBusy(false);
    if (r.ok) setDialog(null);
  };

  const supplyTotal = Math.round((+s.quantity || 0) * (+s.unitCost || 0));

  return (
    <>
      {lowList.length > 0 && (
        <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4 text-xs text-amber-700">
          <span className="text-base">⚠️</span>
          <div><div className="font-medium mb-1">À réapprovisionner</div>
            <div>{lowList.map(i => `${i.name} (${nf(i.stock)} ${i.unit})`).join(' · ')}</div></div>
        </div>
      )}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <KpiCard label="Ingrédients actifs" value={String(ingredients.filter(i => i.isActive).length)} />
        <KpiCard label="Sous le seuil" value={String(lowList.length)} color={lowList.length ? 'text-amber-600' : undefined} />
        <KpiCard label="Valeur du stock (dernier coût)" value={fmtFCFA(stockValue)} />
      </div>

      <div className="bg-white border border-zinc-200 rounded-xl p-4 mb-4">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <span className="text-sm font-medium">Stock par ingrédient</span>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-[11px] text-zinc-500">Archivés <Toggle checked={showArchived} onChange={setShowArchived} /></label>
            <BtnPrimary onClick={() => open({ kind: 'edit', ing: null })}>+ Nouvel ingrédient</BtnPrimary>
          </div>
        </div>
        {list.length === 0 && <div className="text-xs text-zinc-400 py-8 text-center">Aucun ingrédient. Ajoutez-en un pour suivre vos approvisionnements.</div>}
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            {list.length > 0 && <thead><tr>
              {['Ingrédient', 'Stock', 'Seuil', 'Dernier coût', 'Fournisseur', ''].map((h, i) => (
                <th key={i} className="text-left text-[10px] font-medium text-zinc-400 uppercase tracking-wide pb-2 border-b border-zinc-100 pr-3">{h}</th>
              ))}
            </tr></thead>}
            <tbody>
              {list.map(i => {
                const isLow = i.isActive && i.stock <= i.lowStockAlert;
                const pct = i.lowStockAlert > 0 ? Math.min(100, Math.round((i.stock / (i.lowStockAlert * 3)) * 100)) : 100;
                return (
                  <tr key={i.id} className={`border-b border-zinc-100 last:border-0 ${i.isActive ? '' : 'opacity-50'}`}>
                    <td className="py-2.5 pr-3 font-medium">{i.name}{!i.isActive && <span className="ml-2 text-[9px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-500">Archivé</span>}</td>
                    <td className="pr-3">
                      <div className="flex items-center gap-2">
                        <span className={`font-medium ${i.stock <= 0 ? 'text-red-500' : isLow ? 'text-amber-600' : ''}`}>{nf(i.stock)} {i.unit}</span>
                        <div className="w-14 h-1.5 rounded-full bg-zinc-100 overflow-hidden"><div className="h-full rounded-full" style={{ width: pct + '%', background: i.stock <= 0 ? '#E24B4A' : isLow ? '#EF9F27' : '#639922' }} /></div>
                      </div>
                    </td>
                    <td className="pr-3 text-zinc-500">{nf(i.lowStockAlert)} {i.unit}</td>
                    <td className="pr-3">{i.lastUnitCost ? `${fmtFCFA(i.lastUnitCost)} / ${i.unit}` : '—'}</td>
                    <td className="pr-3 text-zinc-500">{i.supplier || '—'}</td>
                    <td>
                      <div className="flex gap-1 justify-end">
                        {i.isActive && <BtnPrimary onClick={() => open({ kind: 'supply', ing: i })} className="!py-1 !px-2 !text-[10px]">+ Approvisionner</BtnPrimary>}
                        {i.isActive && <BtnSecondary onClick={() => open({ kind: 'adjust', ing: i })} className="!py-1 !px-2 !text-[10px]">Ajuster</BtnSecondary>}
                        <button onClick={() => open({ kind: 'edit', ing: i })} aria-label={`Modifier ${i.name}`} className="w-7 h-7 rounded border border-orange-200 bg-orange-50 text-xs cursor-pointer hover:bg-orange-100">✏</button>
                        <button onClick={() => setConfirm({ open: true, ing: i })} aria-label={`Supprimer ${i.name}`} className="w-7 h-7 rounded border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white border border-zinc-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
          <span className="text-sm font-medium">Historique des mouvements</span>
          <Select value={filterIng} onChange={e => setFilterIng(e.target.value)} style={{ width: 200 }}>
            <option value="all">Tous les ingrédients</option>
            {ingredients.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
          </Select>
        </div>
        {movements.length === 0 ? <div className="text-xs text-zinc-400 py-6 text-center">Aucun mouvement</div> : (
          <table className="w-full text-xs border-collapse">
            <thead><tr>{['Date', 'Ingrédient', 'Type', 'Quantité', 'Coût unit.', 'Stock après', 'Détail'].map(h => (
              <th key={h} className="text-left text-[10px] font-medium text-zinc-400 uppercase tracking-wide pb-2 border-b border-zinc-100 pr-3">{h}</th>))}</tr></thead>
            <tbody>
              {movements.map(m => {
                const ing = nameOf(m.ingredientId);
                const plus = m.quantity > 0;
                return (
                  <tr key={m.id} className="border-b border-zinc-100 last:border-0">
                    <td className="py-2 pr-3 text-zinc-400">{fmtDT(m.createdAt)}</td>
                    <td className="pr-3 font-medium">{ing?.name ?? '—'}</td>
                    <td className="pr-3"><span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.type === 'APPROVISIONNEMENT' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{m.type === 'APPROVISIONNEMENT' ? 'Approvisionnement' : 'Ajustement'}</span></td>
                    <td className={`pr-3 font-medium ${plus ? 'text-green-600' : 'text-red-500'}`}>{plus ? '+' : ''}{nf(m.quantity)} {ing?.unit}</td>
                    <td className="pr-3">{m.unitCost ? fmtFCFA(m.unitCost) : '—'}</td>
                    <td className="pr-3">{nf(m.stockAfter)} {ing?.unit}</td>
                    <td className="text-zinc-500">{[m.supplier, m.note].filter(Boolean).join(' · ') || '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Fiche ingrédient */}
      <Modal open={dialog?.kind === 'edit'} title={dialog?.kind === 'edit' && dialog.ing ? 'Modifier l’ingrédient' : 'Nouvel ingrédient'} onClose={() => setDialog(null)}
        footer={<><BtnSecondary onClick={() => setDialog(null)}>Annuler</BtnSecondary><BtnPrimary onClick={saveFiche} disabled={busy}>Enregistrer</BtnPrimary></>}>
        <Field label="Nom"><Input value={f.name} maxLength={100} onChange={e => setF(x => ({ ...x, name: e.target.value }))} placeholder="Ex : Poisson (carpe)" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Unité de mesure"><Select value={f.unit} onChange={e => setF(x => ({ ...x, unit: e.target.value }))}>{UNITS.map(u => <option key={u}>{u}</option>)}</Select></Field>
          <Field label="Seuil d’alerte"><Input type="number" min={0} step="any" value={f.lowStockAlert} onChange={e => setF(x => ({ ...x, lowStockAlert: e.target.value }))} placeholder="Ex : 3" /></Field>
        </div>
        <Field label="Fournisseur habituel"><Input value={f.supplier} maxLength={100} onChange={e => setF(x => ({ ...x, supplier: e.target.value }))} placeholder="Ex : Marché d’Abobo" /></Field>
        {dialog?.kind === 'edit' && dialog.ing && (
          <div className="flex items-center justify-between p-3 bg-zinc-100 rounded-lg">
            <div><div className="text-xs font-medium">Ingrédient actif</div><div className="text-[10px] text-zinc-400">Désactiver = archiver (l’historique est conservé)</div></div>
            <Toggle checked={dialog.ing.isActive} onChange={v => void act(() => saveIngredient(dialog.ing!.id, { isActive: v }), v ? 'Ingrédient réactivé' : 'Ingrédient archivé').then(r => r.ok && setDialog(null))} />
          </div>
        )}
      </Modal>

      {/* Approvisionnement */}
      <Modal open={dialog?.kind === 'supply'} title={dialog?.kind === 'supply' ? `Approvisionner : ${dialog.ing.name}` : ''} onClose={() => setDialog(null)}
        footer={<><BtnSecondary onClick={() => setDialog(null)}>Annuler</BtnSecondary><BtnPrimary onClick={saveSupply} disabled={busy}>{busy ? 'Enregistrement…' : 'Valider l’entrée en stock'}</BtnPrimary></>}>
        {dialog?.kind === 'supply' && (
          <>
            <div className="text-[11px] p-2.5 rounded-lg bg-zinc-100 text-zinc-600">Stock actuel : <strong>{nf(dialog.ing.stock)} {dialog.ing.unit}</strong></div>
            <div className="grid grid-cols-2 gap-3">
              <Field label={`Quantité reçue (${dialog.ing.unit})`}><Input type="number" min={0} step="any" value={s.quantity} onChange={e => setS(x => ({ ...x, quantity: e.target.value }))} /></Field>
              <Field label={`Coût unitaire (FCFA / ${dialog.ing.unit})`}><Input type="number" min={0} step="any" value={s.unitCost} onChange={e => setS(x => ({ ...x, unitCost: e.target.value }))} /></Field>
            </div>
            <Field label="Fournisseur"><Input value={s.supplier} maxLength={100} onChange={e => setS(x => ({ ...x, supplier: e.target.value }))} /></Field>
            <Field label="Note (optionnel)"><Input value={s.note} maxLength={300} onChange={e => setS(x => ({ ...x, note: e.target.value }))} placeholder="Ex : livraison du matin" /></Field>
            <div className="flex items-center justify-between p-3 bg-zinc-100 rounded-lg">
              <div><div className="text-xs font-medium">Enregistrer la dépense « Provisions »</div>
                <div className="text-[10px] text-zinc-400">{supplyTotal > 0 ? `Montant : ${fmtFCFA(supplyTotal)}` : 'Renseignez un coût unitaire'}</div></div>
              <Toggle checked={s.recordExpense} onChange={v => setS(x => ({ ...x, recordExpense: v }))} />
            </div>
            {+s.quantity > 0 && <div className="text-[11px] text-green-700 bg-green-50 rounded-lg p-2.5">Nouveau stock : <strong>{nf(dialog.ing.stock + +s.quantity)} {dialog.ing.unit}</strong></div>}
          </>
        )}
      </Modal>

      {/* Ajustement */}
      <Modal open={dialog?.kind === 'adjust'} title={dialog?.kind === 'adjust' ? `Ajuster : ${dialog.ing.name}` : ''} onClose={() => setDialog(null)}
        footer={<><BtnSecondary onClick={() => setDialog(null)}>Annuler</BtnSecondary><BtnPrimary onClick={saveAdjust} disabled={busy}>Enregistrer</BtnPrimary></>}>
        {dialog?.kind === 'adjust' && (
          <>
            <div className="text-[11px] p-2.5 rounded-lg bg-zinc-100 text-zinc-600">Stock actuel : <strong>{nf(dialog.ing.stock)} {dialog.ing.unit}</strong>. Utilisez une valeur négative pour une perte ou une casse.</div>
            <Field label={`Variation (${dialog.ing.unit})`}><Input type="number" step="any" value={a.delta} onChange={e => setA(x => ({ ...x, delta: e.target.value }))} placeholder="Ex : -0,5 ou +2" /></Field>
            <Field label="Motif (obligatoire)"><Input value={a.note} maxLength={300} onChange={e => setA(x => ({ ...x, note: e.target.value }))} placeholder="Ex : perte, inventaire du soir…" /></Field>
          </>
        )}
      </Modal>

      <Confirm open={confirm.open} title="Supprimer cet ingrédient ?" message={`« ${confirm.ing?.name ?? ''} » sera supprimé. S’il a un historique, archivez-le plutôt (bouton ✏).`}
        onConfirm={async () => { if (confirm.ing) await act(() => deleteIngredient(confirm.ing!.id), 'Ingrédient supprimé'); setConfirm({ open: false }); }}
        onCancel={() => setConfirm({ open: false })} />
    </>
  );
};
