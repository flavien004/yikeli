// Comptabilité : grand livre (ventes / charges), clôture de caisse par caissier, registre des annulations.
import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { PaymentMethod } from '../../types';
import { fmtFCFA, METHOD_LABELS, METHOD_COLORS, downloadCSV } from '../../utils';
import { BtnSecondary, Field, Input, Select, KpiCard, showToast } from '../shared';

// ── COMPTABILITÉ (Grand livre + Clôture) ─────────────────────
export const ComptaTab: React.FC = () => {
  const { state } = useApp();
  const [subTab, setSubTab] = useState<'grandlivre' | 'cloture' | 'annulations'>('grandlivre');
  const [dateDebut, setDateDebut] = useState(new Date().toISOString().slice(0, 8) + '01');
  const [dateFin, setDateFin]     = useState(new Date().toISOString().slice(0, 10));
  const [caissier, setCaissier]   = useState(state.users.find(u => u.role !== 'ADMIN')?.id ?? state.users[0]?.id ?? '');
  const [clotureDate, setClotureDate] = useState(new Date().toISOString().slice(0, 10));

  const inRange = (d: string) => d >= dateDebut && d <= dateFin;

  const ventesFiltered = useMemo(() => state.paiements.filter(p => inRange(p.createdAt.slice(0, 10))), [state.paiements, dateDebut, dateFin]);
  const depFiltered    = useMemo(() => state.depenses.filter(d => inRange(d.date)), [state.depenses, dateDebut, dateFin]);
  const ca   = ventesFiltered.reduce((s, p) => s + p.amount, 0);
  const dep  = depFiltered.reduce((s, d) => s + d.amount, 0);
  const res  = ca - dep;

  const clotTrans = useMemo(() => state.paiements.filter(p => p.userId === caissier && p.createdAt.slice(0, 10) === clotureDate), [state.paiements, caissier, clotureDate]);
  const clotTotal = clotTrans.reduce((s, p) => s + p.amount, 0);

  const annulations = state.commandes.filter(c => c.status === 'ANNULEE');

  const exportVentesCSV = () => {
    const rows = [['Date', 'Client', 'Mode', 'Montant']];
    ventesFiltered.forEach(p => {
      const cmd = state.commandes.find(c => c.id === p.commandeId);
      rows.push([p.createdAt.slice(0, 10), cmd?.clientName ?? '—', METHOD_LABELS[p.method], String(p.amount)]);
    });
    downloadCSV(rows, `grand_livre_ventes_${dateDebut}_${dateFin}.csv`);
    showToast('Export ventes téléchargé');
  };

  const exportDepCSV = () => {
    const rows = [['Date', 'Catégorie', 'Description', 'Montant']];
    depFiltered.forEach(d => rows.push([d.date, d.category, d.description, String(d.amount)]));
    downloadCSV(rows, `grand_livre_charges_${dateDebut}_${dateFin}.csv`);
    showToast('Export charges téléchargé');
  };

  const METHODS = Object.keys(METHOD_LABELS) as PaymentMethod[];
  const balanceMethods: Record<string, number> = {};
  clotTrans.forEach(t => { balanceMethods[t.method] = (balanceMethods[t.method] ?? 0) + t.amount; });

  return (
    <>
      <div className="flex gap-1 mb-4 bg-zinc-100 dark:bg-zinc-800 rounded-xl p-1 w-fit">
        {([['grandlivre', 'Grand livre'], ['cloture', 'Clôture caisse'], ['annulations', 'Annulations']] as const).map(([id, label]) => (
          <button key={id} onClick={() => setSubTab(id)} className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer border-none transition-colors ${subTab === id ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100' : 'bg-transparent text-zinc-500'}`}>{label}</button>
        ))}
      </div>

      {subTab === 'grandlivre' && (
        <>
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 mb-4">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-xs text-zinc-500">Période :</span>
              <Input type="date" value={dateDebut} onChange={e => setDateDebut(e.target.value)} style={{ width: 140 }}/>
              <span className="text-xs text-zinc-400">→</span>
              <Input type="date" value={dateFin} onChange={e => setDateFin(e.target.value)} style={{ width: 140 }}/>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-3 mb-4">
            <KpiCard label="Chiffre d'affaires" value={fmtFCFA(ca)} color="text-green-600" />
            <KpiCard label="Charges" value={fmtFCFA(dep)} color="text-red-500" />
            <KpiCard label="Résultat net" value={fmtFCFA(res)} color={res >= 0 ? 'text-green-600' : 'text-red-500'} />
            <KpiCard label="Transactions" value={String(ventesFiltered.length + depFiltered.length)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">Grand livre des ventes</span>
                <BtnSecondary onClick={exportVentesCSV}>⬇ CSV</BtnSecondary>
              </div>
              <table className="w-full text-xs border-collapse">
                <thead><tr>{['Date','Client','Mode','Montant'].map(h=><th key={h} className="text-left text-[10px] font-medium text-zinc-400 uppercase pb-2 border-b border-zinc-100 dark:border-zinc-800 pr-2">{h}</th>)}</tr></thead>
                <tbody>{ventesFiltered.map(p => { const cmd = state.commandes.find(c => c.id === p.commandeId); return (
                  <tr key={p.id} className="border-b border-zinc-100 dark:border-zinc-800 last:border-0">
                    <td className="py-2 pr-2 text-zinc-400">{p.createdAt.slice(5,10).split('-').reverse().join('/')}</td>
                    <td className="pr-2">{cmd?.clientName ?? '—'}</td>
                    <td className="pr-2"><span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-500">{METHOD_LABELS[p.method]}</span></td>
                    <td className="text-right font-medium text-green-600">{fmtFCFA(p.amount)}</td>
                  </tr>
                ); })}</tbody>
              </table>
            </div>
            <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">Grand livre des charges</span>
                <BtnSecondary onClick={exportDepCSV}>⬇ CSV</BtnSecondary>
              </div>
              <table className="w-full text-xs border-collapse">
                <thead><tr>{['Date','Catégorie','Description','Montant'].map(h=><th key={h} className="text-left text-[10px] font-medium text-zinc-400 uppercase pb-2 border-b border-zinc-100 dark:border-zinc-800 pr-2">{h}</th>)}</tr></thead>
                <tbody>{depFiltered.map(d=>(
                  <tr key={d.id} className="border-b border-zinc-100 dark:border-zinc-800 last:border-0">
                    <td className="py-2 pr-2 text-zinc-400">{d.date.slice(5).split('-').reverse().join('/')}</td>
                    <td className="pr-2 text-zinc-500">{d.category}</td>
                    <td className="pr-2 text-zinc-400">{d.description}</td>
                    <td className="text-right font-medium text-red-500">{fmtFCFA(d.amount)}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {subTab === 'cloture' && (
        <>
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4 mb-4 flex gap-3 items-center flex-wrap">
            <Field label="Caissier"><Select value={caissier} onChange={e => setCaissier(e.target.value)} style={{ width: 180 }}>{state.users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</Select></Field>
            <Field label="Date"><Input type="date" value={clotureDate} onChange={e => setClotureDate(e.target.value)} style={{ width: 150 }}/></Field>
          </div>
          <div className="grid grid-cols-4 gap-3 mb-4">
            <KpiCard label="Total encaissé" value={fmtFCFA(clotTotal)} color="text-green-600" />
            <KpiCard label="Transactions" value={String(clotTrans.length)} />
            <KpiCard label="Caissier" value={state.users.find(u => u.id === caissier)?.name ?? '—'} />
            <KpiCard label="Statut" value={clotTrans.length > 0 ? 'Journée active' : 'Aucune activité'} color={clotTrans.length > 0 ? 'text-green-600' : 'text-zinc-400'} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4">
              <div className="text-sm font-medium mb-3">Balance par mode</div>
              {METHODS.map(m => { const v = balanceMethods[m] ?? 0; const pct = clotTotal > 0 ? Math.round(v / clotTotal * 100) : 0; return (
                <div key={m} className="mb-3">
                  <div className="flex justify-between text-xs mb-1"><span className="text-zinc-500">{METHOD_LABELS[m]}</span><span className="font-medium">{pct}% · {fmtFCFA(v)}</span></div>
                  <div className="h-1.5 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden"><div className="h-full rounded-full" style={{ width: pct + '%', background: METHOD_COLORS[m] }}></div></div>
                </div>
              ); })}
            </div>
            <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">Transactions du shift</span>
                <BtnSecondary onClick={() => { downloadCSV([['Heure','Client','Mode','Montant'], ...clotTrans.map(t => { const cmd = state.commandes.find(c => c.id === t.commandeId); return [new Date(t.createdAt).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}), cmd?.clientName ?? '—', METHOD_LABELS[t.method], String(t.amount)]; })], `cloture_${caissier}_${clotureDate}.csv`); showToast('Rapport exporté'); }}>⬇ CSV</BtnSecondary>
              </div>
              {clotTrans.length === 0 ? <div className="text-center py-8 text-xs text-zinc-400">Aucune transaction</div> : clotTrans.map(t => { const cmd = state.commandes.find(c => c.id === t.commandeId); return (
                <div key={t.id} className="flex items-center gap-2 py-2 border-b border-zinc-100 dark:border-zinc-800 last:border-0 text-xs">
                  <span className="text-zinc-400 w-10">{new Date(t.createdAt).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}</span>
                  <span className="flex-1">{cmd?.clientName ?? '—'}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-500">{METHOD_LABELS[t.method]}</span>
                  <span className="font-medium w-16 text-right">{fmtFCFA(t.amount)}</span>
                </div>
              ); })}
            </div>
          </div>
        </>
      )}

      {subTab === 'annulations' && (
        <>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <KpiCard label="Commandes annulées" value={String(annulations.length)} color={annulations.length > 0 ? 'text-red-500' : undefined} />
            <KpiCard label="Montant total" value={fmtFCFA(annulations.reduce((s, c) => s + c.total, 0))} color="text-red-500" />
          </div>
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4">
            <div className="text-sm font-medium mb-3">Registre des annulations</div>
            {annulations.length === 0 ? (
              <div className="text-center py-8 text-xs text-zinc-400">Aucune annulation enregistrée</div>
            ) : annulations.map(c => (
              <div key={c.id} className="border border-zinc-200 dark:border-zinc-700 rounded-xl p-3 mb-2">
                <div className="flex justify-between items-start mb-1">
                  <div><div className="text-xs font-medium">{c.clientName}</div><div className="text-[10px] text-zinc-400">{new Date(c.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}</div></div>
                  <span className="text-sm font-medium text-red-500">-{fmtFCFA(c.total)}</span>
                </div>
                {c.cancelReason && <div className="text-[10px] text-zinc-500 mb-1">{c.cancelReason}</div>}
                <div className="flex items-center gap-1 text-[10px] text-green-600">✓ Stock des articles automatiquement restauré</div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
};
