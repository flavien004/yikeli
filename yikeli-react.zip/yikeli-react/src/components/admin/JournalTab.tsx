// Journal des opérations (trésorerie) : paiements et dépenses injectés automatiquement
// + mouvements manuels (apports, retraits…). Solde cumulé ligne par ligne.
import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import { fmtFCFA, METHOD_LABELS, downloadCSV } from '../../utils';
import { act } from '../../lib/act';
import { Modal, Confirm, BtnPrimary, BtnSecondary, Field, Input, Select, KpiCard, showToast } from '../shared';

// ── JOURNAL DES OPÉRATIONS ───────────────────────────────────
export const JournalTab: React.FC = () => {
  const { state, addMouvement, deleteMouvement } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [type, setType] = useState<'RECETTE' | 'DEPENSE' | ''>('');
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), libelle: '', montant: '' });
  const [filterType, setFilterType] = useState('all');
  const [filterSrc, setFilterSrc] = useState('all');
  const [confirm, setConfirm] = useState<{ open: boolean; id: string; name: string }>({ open: false, id: '', name: '' });

  const allMouvements = useMemo(() => {
    const auto = [
      ...state.paiements.map(p => ({ id: p.id, date: p.createdAt.slice(0, 10), type: 'RECETTE' as const, libelle: `Encaissement — ${state.commandes.find(c => c.id === p.commandeId)?.clientName ?? '?'} (${METHOD_LABELS[p.method]})`, montant: p.amount, source: 'auto' as const })),
      ...state.depenses.map(d => ({ id: d.id, date: d.date, type: 'DEPENSE' as const, libelle: `Charge · ${d.category} — ${d.description}`, montant: d.amount, source: 'auto' as const })),
    ];
    return [...auto, ...state.mouvementsManuel].sort((a, b) => a.date === b.date ? 0 : a.date.localeCompare(b.date));
  }, [state.paiements, state.depenses, state.mouvementsManuel, state.commandes]);

  const withSolde = useMemo(() => {
    let s = state.soldeInitial;
    return allMouvements.map(m => { s += m.type === 'RECETTE' ? m.montant : -m.montant; return { ...m, soldeApres: s }; });
  }, [allMouvements, state.soldeInitial]);

  const filtered = useMemo(() => withSolde.filter(m =>
    (filterType === 'all' || m.type === filterType) && (filterSrc === 'all' || m.source === filterSrc)
  ), [withSolde, filterType, filterSrc]);

  const totals = useMemo(() => ({
    rec: allMouvements.filter(m => m.type === 'RECETTE').reduce((s, m) => s + m.montant, 0),
    dep: allMouvements.filter(m => m.type === 'DEPENSE').reduce((s, m) => s + m.montant, 0),
    final: state.soldeInitial + allMouvements.filter(m => m.type === 'RECETTE').reduce((s, m) => s + m.montant, 0) - allMouvements.filter(m => m.type === 'DEPENSE').reduce((s, m) => s + m.montant, 0),
  }), [allMouvements, state.soldeInitial]);

  const saveOp = async () => {
    if (!type) { showToast('Choisir Recette ou Dépense'); return; }
    if (!form.libelle) { showToast('Saisir un libellé'); return; }
    if (!form.montant) { showToast('Saisir un montant'); return; }
    const r = await act(() => addMouvement({ date: form.date, type, libelle: form.libelle, montant: Math.round(+form.montant) }), 'Mouvement enregistré');
    if (!r.ok) return;
    setModalOpen(false); setType(''); setForm({ date: new Date().toISOString().slice(0, 10), libelle: '', montant: '' });
  };

  const handleExportCSV = () => {
    let s = state.soldeInitial;
    const rows: string[][] = [['Date', 'Type', 'Libellé', 'Source', 'Recette', 'Dépense', 'Solde']];
    rows.push(['', '', 'Solde initial', '', '', '', String(s)]);
    allMouvements.forEach(m => {
      s += m.type === 'RECETTE' ? m.montant : -m.montant;
      rows.push([m.date, m.type === 'RECETTE' ? 'Recette' : 'Dépense', m.libelle, m.source === 'auto' ? 'Auto' : 'Manuel', m.type === 'RECETTE' ? String(m.montant) : '', m.type === 'DEPENSE' ? String(m.montant) : '', String(s)]);
    });
    downloadCSV(rows, 'journal_tresorerie.csv');
    showToast('Export CSV téléchargé');
  };

  return (
    <>
      <div className="grid grid-cols-4 gap-3 mb-4">
        <KpiCard label="Solde initial" value={fmtFCFA(state.soldeInitial)} />
        <KpiCard label="Total recettes" value={'+' + fmtFCFA(totals.rec)} color="text-green-600" />
        <KpiCard label="Total dépenses" value={'-' + fmtFCFA(totals.dep)} color="text-red-500" />
        <KpiCard label="Solde final" value={fmtFCFA(totals.final)} color={totals.final >= 0 ? 'text-zinc-900 dark:text-zinc-100' : 'text-red-500'} />
      </div>
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <div className="flex gap-2">
            <Select value={filterType} onChange={e => setFilterType(e.target.value)} style={{ width: 160 }}>
              <option value="all">Tous les mouvements</option>
              <option value="RECETTE">Recettes</option>
              <option value="DEPENSE">Dépenses</option>
            </Select>
            <Select value={filterSrc} onChange={e => setFilterSrc(e.target.value)} style={{ width: 160 }}>
              <option value="all">Toutes sources</option>
              <option value="auto">Automatiques</option>
              <option value="manuel">Manuels</option>
            </Select>
          </div>
          <div className="flex gap-2">
            <BtnSecondary onClick={handleExportCSV}>⬇ CSV</BtnSecondary>
            <BtnPrimary onClick={() => { setType(''); setModalOpen(true); }}>+ Mouvement manuel</BtnPrimary>
          </div>
        </div>
        <table className="w-full text-xs border-collapse">
          <thead><tr>{['Date', 'Type', 'Libellé', 'Src', 'Recette', 'Dépense', 'Solde', ''].map(h => <th key={h} className="text-left text-[10px] font-medium text-zinc-400 uppercase pb-2 border-b border-zinc-100 dark:border-zinc-800 pr-2">{h}</th>)}</tr></thead>
          <tbody>
            <tr className="bg-zinc-50 dark:bg-zinc-800">
              <td colSpan={6} className="py-2 pr-2 text-zinc-500 font-medium">Solde initial (report)</td>
              <td className="py-2 text-right font-medium">{fmtFCFA(state.soldeInitial)}</td>
              <td></td>
            </tr>
            {filtered.map(m => (
              <tr key={m.id} className={`border-b border-zinc-100 dark:border-zinc-800 last:border-0 ${m.source === 'manuel' ? 'bg-purple-50/40 dark:bg-purple-900/10' : ''}`}>
                <td className="py-2 pr-2 text-zinc-400">{new Date(m.date + 'T00:00:00').toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}</td>
                <td className="pr-2"><span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${m.type === 'RECETTE' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>{m.type === 'RECETTE' ? 'Recette' : 'Dépense'}</span></td>
                <td className="pr-2 text-zinc-600 dark:text-zinc-300 max-w-[200px] overflow-hidden text-ellipsis whitespace-nowrap" title={m.libelle}>{m.libelle}</td>
                <td className="pr-2"><span className={`text-[9px] px-1.5 py-0.5 rounded ${m.source === 'auto' ? 'bg-zinc-100 text-zinc-400' : 'bg-purple-100 text-purple-600'}`}>{m.source === 'auto' ? 'Auto' : 'Manuel'}</span></td>
                <td className="pr-2 text-right text-green-600 font-medium">{m.type === 'RECETTE' ? fmtFCFA(m.montant) : ''}</td>
                <td className="pr-2 text-right text-red-500 font-medium">{m.type === 'DEPENSE' ? fmtFCFA(m.montant) : ''}</td>
                <td className={`pr-2 text-right font-medium ${m.soldeApres < 0 ? 'text-red-500' : ''}`}>{fmtFCFA(m.soldeApres)}</td>
                <td>{m.source === 'manuel' ? (
                  <button onClick={() => setConfirm({ open: true, id: m.id, name: m.libelle })} className="w-5 h-5 rounded border border-zinc-200 flex items-center justify-center text-[10px] cursor-pointer hover:border-red-400 hover:text-red-500">✕</button>
                ) : <div className="w-5 h-5 flex items-center justify-center text-zinc-300 text-[10px]">🔒</div>}</td>
              </tr>
            ))}
            <tr className="bg-zinc-50 dark:bg-zinc-800 font-medium">
              <td colSpan={4} className="py-2 pr-2">Totaux</td>
              <td className="py-2 text-right text-green-600">{fmtFCFA(filtered.filter(m => m.type === 'RECETTE').reduce((s, m) => s + m.montant, 0))}</td>
              <td className="py-2 text-right text-red-500">{fmtFCFA(filtered.filter(m => m.type === 'DEPENSE').reduce((s, m) => s + m.montant, 0))}</td>
              <td className={`py-2 text-right ${totals.final < 0 ? 'text-red-500' : ''}`}>{fmtFCFA(totals.final)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
      <Modal open={modalOpen} title="Mouvement manuel" onClose={() => setModalOpen(false)}
        footer={<><BtnSecondary onClick={() => setModalOpen(false)}>Annuler</BtnSecondary><BtnPrimary onClick={saveOp}>Enregistrer</BtnPrimary></>}>
        <div className="text-[11px] p-2.5 rounded-lg bg-zinc-50 dark:bg-zinc-800 text-zinc-500">Utilisez ceci pour les mouvements hors ventes/achats : apports, retraits, emprunts...</div>
        <div className="grid grid-cols-2 gap-2">
          {(['RECETTE', 'DEPENSE'] as const).map(t => (
            <button key={t} onClick={() => setType(t)} className={`py-2.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${type === t ? t === 'RECETTE' ? 'border-green-400 bg-green-50 text-green-700' : 'border-red-400 bg-red-50 text-red-600' : 'border-zinc-300 dark:border-zinc-600 bg-zinc-50 dark:bg-zinc-800 text-zinc-500'}`}>
              {t === 'RECETTE' ? '↑ Recette' : '↓ Dépense'}
            </button>
          ))}
        </div>
        <Field label="Date"><Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}/></Field>
        <Field label="Libellé"><Input value={form.libelle} onChange={e => setForm(f => ({ ...f, libelle: e.target.value }))} placeholder="Ex : Apport capital gérant"/></Field>
        <Field label="Montant (FCFA)"><Input type="number" value={form.montant} onChange={e => setForm(f => ({ ...f, montant: e.target.value }))} placeholder="Ex : 50000"/></Field>
      </Modal>
      <Confirm open={confirm.open} title="Supprimer ce mouvement ?" message={`"${confirm.name}" — le solde sera recalculé.`}
        onConfirm={async () => { await act(() => deleteMouvement(confirm.id), 'Mouvement supprimé, solde recalculé'); setConfirm(c => ({ ...c, open: false })); }}
        onCancel={() => setConfirm(c => ({ ...c, open: false }))} />
    </>
  );
};

