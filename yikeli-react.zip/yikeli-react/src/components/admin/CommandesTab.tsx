// Commandes : suivi, avancement (accepter / servir), annulation motivée (stock restauré), suppression.
// « Payée » n'est jamais modifiable à la main : seul un paiement complet pose ce statut.
import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { Commande } from '../../types';
import { fmtFCFA, METHOD_LABELS, getPaidAmount, getRemaining } from '../../utils';
import { act } from '../../lib/act';
import { Modal, Confirm, BtnPrimary, BtnSecondary, Field, Input, KpiCard, Select, StatusBadge, showToast } from '../shared';

export const CommandesTab: React.FC = () => {
  const { state, setOrderStatus, deleteCommande } = useApp();
  const [filter, setFilter] = useState('all');
  const [cancel, setCancel] = useState<{ cmd: Commande; reason: string } | null>(null);
  const [confirm, setConfirm] = useState<{ open: boolean; id: string }>({ open: false, id: '' });

  const list = useMemo(() => state.commandes.filter(c => filter === 'all' || c.status === filter), [state.commandes, filter]);
  const enCours = state.commandes.filter(c => c.status === 'EN_COURS' || c.status === 'ACCEPTEE').length;
  const ca = state.paiements.reduce((s, p) => s + p.amount, 0);

  const advance = (c: Commande) => {
    const next = c.status === 'EN_COURS' ? 'ACCEPTEE' : 'SERVIE';
    void act(() => setOrderStatus(c.id, next), next === 'ACCEPTEE' ? 'Commande acceptée' : 'Commande servie');
  };

  const doCancel = async () => {
    if (!cancel) return;
    if (cancel.reason.trim().length < 3) { showToast('Indiquez le motif de l’annulation'); return; }
    const r = await act(() => setOrderStatus(cancel.cmd.id, 'ANNULEE', cancel.reason.trim()), 'Commande annulée — stock restauré');
    if (r.ok) setCancel(null);
  };

  return (
    <>
      <div className="grid grid-cols-3 gap-3 mb-4">
        <KpiCard label="Commandes (période chargée)" value={String(state.commandes.length)} />
        <KpiCard label="À traiter" value={String(enCours)} color="text-amber-600" />
        <KpiCard label="Encaissé" value={fmtFCFA(ca)} color="text-green-600" />
      </div>
      <div className="bg-white border border-zinc-200 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
          <span className="text-sm font-medium">Commandes</span>
          <Select value={filter} onChange={e => setFilter(e.target.value)} style={{ width: 160 }}>
            <option value="all">Tous statuts</option><option value="EN_COURS">En cours</option><option value="ACCEPTEE">Acceptée</option>
            <option value="SERVIE">Servie</option><option value="PAYEE">Payée</option><option value="ANNULEE">Annulée</option>
          </Select>
        </div>
        {list.length === 0 && <div className="text-xs text-zinc-400 py-8 text-center">Aucune commande</div>}
        {list.map(c => {
          const paid = getPaidAmount(c.id, state.paiements);
          const rem = getRemaining(c, state.paiements);
          return (
            <div key={c.id} className="flex items-center gap-3 py-3 border-b border-zinc-100 last:border-0 text-xs">
              <div className="text-[10px] text-zinc-400 w-12">#{c.id.slice(0, 4).toUpperCase()}</div>
              <div className="flex-1 min-w-0">
                <div className="font-medium">{c.clientName}
                  {c.type === 'EN_LIGNE' && <span className="ml-2 text-[9px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-600">En ligne</span>}
                </div>
                <div className="text-[10px] text-zinc-400 truncate">{c.items.map(i => `${i.platName} x${i.quantity}`).join(', ')}</div>
                {c.clientPhone && <div className="text-[10px] text-zinc-500">📞 {c.clientPhone}{c.clientAddress ? ` · ${c.clientAddress}` : ''}</div>}
                {c.specs && <div className="text-[10px] text-amber-600">📝 {c.specs}</div>}
                {c.paymentPref && <div className="text-[10px] text-zinc-500">Paiement souhaité : {METHOD_LABELS[c.paymentPref]}</div>}
                {c.cancelReason && <div className="text-[10px] text-red-500">Motif : {c.cancelReason}</div>}
              </div>
              <div className="text-right">
                <div className="font-medium">{fmtFCFA(c.total)}</div>
                {rem > 0 && paid > 0 && c.status !== 'ANNULEE' && <div className="text-[10px] text-amber-600">Reste : {fmtFCFA(rem)}</div>}
              </div>
              <StatusBadge status={c.status} />
              <div className="flex gap-1 items-center">
                {(c.status === 'EN_COURS' || c.status === 'ACCEPTEE') && (
                  <BtnSecondary onClick={() => advance(c)} className="!py-1 !px-2 !text-[10px]">{c.status === 'EN_COURS' ? 'Accepter' : 'Servir'}</BtnSecondary>
                )}
                {c.status !== 'ANNULEE' && paid === 0 && (
                  <BtnSecondary onClick={() => setCancel({ cmd: c, reason: '' })} className="!py-1 !px-2 !text-[10px]">Annuler</BtnSecondary>
                )}
                <button onClick={() => setConfirm({ open: true, id: c.id })} aria-label="Supprimer la commande" className="w-7 h-7 rounded border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>
              </div>
            </div>
          );
        })}
      </div>

      <Modal open={!!cancel} title="Annuler la commande" onClose={() => setCancel(null)}
        footer={<><BtnSecondary onClick={() => setCancel(null)}>Retour</BtnSecondary><BtnPrimary onClick={doCancel}>Confirmer l’annulation</BtnPrimary></>}>
        {cancel && <>
          <div className="text-xs text-zinc-600">Commande de <strong>{cancel.cmd.clientName}</strong> · {fmtFCFA(cancel.cmd.total)}. Le stock des articles sera restauré.</div>
          <Field label="Motif (obligatoire)"><Input value={cancel.reason} maxLength={300} onChange={e => setCancel({ ...cancel, reason: e.target.value })} placeholder="Ex : client absent, erreur de saisie…" /></Field>
        </>}
      </Modal>

      <Confirm open={confirm.open} title="Supprimer la commande ?" message="Suppression définitive (stock restauré si la commande n’était pas annulée). Impossible si des paiements existent."
        onConfirm={async () => { await act(() => deleteCommande(confirm.id), 'Commande supprimée'); setConfirm({ open: false, id: '' }); }}
        onCancel={() => setConfirm({ open: false, id: '' })} />
    </>
  );
};
