// Employés : création / modification / désactivation. Le mot de passe est saisi dans un champ
// masqué, envoyé une seule fois à l'API (hash bcrypt côté serveur) et jamais conservé côté client.
import React, { useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import { useAuth } from '../../hooks/AuthContext';
import type { User, UserRole } from '../../types';
import { act } from '../../lib/act';
import { Modal, Confirm, BtnPrimary, BtnSecondary, Toggle, Field, Input, PasswordInput, Select, showToast } from '../shared';

const COLORS = ['#E87722', '#378ADD', '#1D9E75', '#D85A30', '#7F77DD'];
const initials = (n: string) => n.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
const ROLE_LABEL: Record<UserRole, string> = { ADMIN: 'Admin', CHEF: 'Chef', CAISSIER: 'Caissier' };

interface Form { name: string; email: string; phone: string; role: UserRole; isActive: boolean; password: string; }
const empty: Form = { name: '', email: '', phone: '', role: 'CAISSIER', isActive: true, password: '' };

export const EmployesTab: React.FC = () => {
  const { state, saveUser, deleteUser } = useApp();
  const { user: me } = useAuth();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<Form>(empty);
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState<{ open: boolean; id: string; name: string }>({ open: false, id: '', name: '' });

  const openModal = (u?: User) => {
    setEditId(u?.id ?? null);
    setForm(u ? { name: u.name, email: u.email ?? '', phone: u.phone ?? '', role: u.role, isActive: u.isActive, password: '' } : empty);
    setOpen(true);
  };
  const close = () => { setOpen(false); setForm(empty); };   // efface le mot de passe saisi

  const save = async () => {
    if (form.name.trim().length < 2) { showToast('Saisir un nom'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) { showToast('Email invalide'); return; }
    if (!editId && form.password.length < 10) { showToast('Mot de passe : 10 caractères minimum'); return; }
    if (editId && form.password && form.password.length < 10) { showToast('Mot de passe : 10 caractères minimum'); return; }
    const payload = {
      name: form.name.trim(), email: form.email.trim().toLowerCase(), phone: form.phone.trim() || undefined,
      role: form.role, isActive: form.isActive, ...(form.password ? { password: form.password } : {}),
    };
    setBusy(true);
    const r = await act(() => saveUser(editId, payload), editId ? 'Employé modifié' : 'Compte créé');
    setBusy(false);
    if (r.ok) close();
  };

  return (
    <>
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm font-medium">Équipe</span>
        <BtnPrimary onClick={() => openModal()}>+ Nouvel employé</BtnPrimary>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {state.users.map((u, i) => {
          const c = COLORS[i % COLORS.length];
          return (
            <div key={u.id} className="bg-white border border-zinc-200 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div style={{ background: c + '25', color: c }} className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-medium flex-shrink-0">{initials(u.name)}</div>
                <div className="min-w-0"><div className="text-xs font-medium truncate">{u.name}{u.id === me?.id && <span className="text-zinc-400"> (vous)</span>}</div><div className="text-[10px] text-zinc-400 truncate">{u.email}</div></div>
              </div>
              <div className="flex gap-2 mb-3">
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${u.isActive ? 'bg-green-100 text-green-700' : 'bg-zinc-100 text-zinc-400'}`}>{u.isActive ? 'Actif' : 'Inactif'}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${u.role === 'ADMIN' ? 'bg-purple-100 text-purple-700' : 'bg-orange-100 text-orange-700'}`}>{ROLE_LABEL[u.role]}</span>
              </div>
              <div className="flex gap-2">
                <BtnSecondary onClick={() => openModal(u)} className="flex-1 justify-center !py-1.5 !text-[10px]">✏ Modifier</BtnSecondary>
                {u.id !== me?.id && <button onClick={() => setConfirm({ open: true, id: u.id, name: u.name })} aria-label={`Supprimer ${u.name}`} className="w-8 rounded-lg border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>}
              </div>
            </div>
          );
        })}
      </div>

      <Modal open={open} title={editId ? 'Modifier l’employé' : 'Nouvel employé'} onClose={close}
        footer={<><BtnSecondary onClick={close}>Annuler</BtnSecondary><BtnPrimary onClick={save} disabled={busy}>{busy ? 'Enregistrement…' : 'Enregistrer'}</BtnPrimary></>}>
        <Field label="Nom complet"><Input value={form.name} maxLength={100} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></Field>
        <Field label="Email (identifiant de connexion)"><Input type="email" autoComplete="off" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></Field>
        <Field label="Téléphone"><Input type="tel" value={form.phone} maxLength={30} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></Field>
        <Field label="Rôle">
          <Select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value as UserRole }))} disabled={editId === me?.id}>
            <option value="CAISSIER">Caissier</option><option value="CHEF">Chef</option><option value="ADMIN">Administrateur</option>
          </Select>
        </Field>
        <Field label={editId ? 'Nouveau mot de passe' : 'Mot de passe'} hint={editId ? 'Laisser vide pour conserver l’actuel. Une réinitialisation déconnecte l’employé.' : '10 caractères minimum.'}>
          <PasswordInput autoComplete="new-password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
        </Field>
        <div className="flex items-center justify-between p-3 bg-zinc-100 rounded-lg">
          <span className="text-xs font-medium">Compte actif</span>
          <Toggle checked={form.isActive} onChange={v => editId !== me?.id && setForm(f => ({ ...f, isActive: v }))} />
        </div>
      </Modal>

      <Confirm open={confirm.open} title="Supprimer cet employé ?" message={`Le compte de « ${confirm.name} » sera définitivement supprimé.`}
        onConfirm={async () => { await act(() => deleteUser(confirm.id), 'Compte supprimé'); setConfirm(c => ({ ...c, open: false })); }}
        onCancel={() => setConfirm(c => ({ ...c, open: false }))} />
    </>
  );
};
