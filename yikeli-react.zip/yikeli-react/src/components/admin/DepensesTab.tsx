// Dépenses : types issus de la configuration (ExpCategory), ajout / modification / suppression.
import React, { useMemo, useState } from 'react';
import { useApp } from '../../hooks/AppContext';
import type { Depense } from '../../types';
import { fmtFCFA, CAT_COLORS } from '../../utils';
import { act } from '../../lib/act';
import { Modal, Confirm, BtnPrimary, BtnSecondary, Field, Input, Select, KpiCard, showToast } from '../shared';

const today = () => new Date().toISOString().slice(0, 10);
interface Form { category: string; description: string; amount: string; date: string; }

export const DepensesTab: React.FC<{ onManageTypes: () => void }> = ({ onManageTypes }) => {
  const { state, addDepense, updateDepense, deleteDepense } = useApp();
  const cats = state.expCategories;
  const [filter, setFilter] = useState('all');
  const [form, setForm] = useState<Form>({ category: 'Provisions', description: '', amount: '', date: today() });
  const [edit, setEdit] = useState<(Form & { id: string }) | null>(null);
  const [confirm, setConfirm] = useState<{ open: boolean; id: string; name: string }>({ open: false, id: '', name: '' });

  const filtered = useMemo(() => state.depenses
    .filter(d => filter === 'all' || d.category === filter)
    .sort((a, b) => b.date.localeCompare(a.date)), [state.depenses, filter]);
  const total = filtered.reduce((s, d) => s + d.amount, 0);
  const topCat = useMemo(() => {
    const t: Record<string, number> = {};
    state.depenses.forEach(d => { t[d.category] = (t[d.category] ?? 0) + d.amount; });
    return Object.entries(t).sort((a, b) => b[1] - a[1])[0]?.[0] ?? '—';
  }, [state.depenses]);

  const add = async () => {
    if (!form.description.trim()) { showToast('Saisir une description'); return; }
    if (!(+form.amount > 0)) { showToast('Saisir un montant'); return; }
    const r = await act(() => addDepense({ category: form.category, description: form.description.trim(), amount: Math.round(+form.amount), date: form.date }), 'Dépense enregistrée');
    if (r.ok) setForm(f => ({ ...f, description: '', amount: '' }));
  };

  const saveEdit = async () => {
    if (!edit) return;
    if (!edit.description.trim() || !(+edit.amount > 0)) { showToast('Description et montant requis'); return; }
    const patch: Partial<Depense> = { category: edit.category, description: edit.description.trim(), amount: Math.round(+edit.amount), date: edit.date };
    const r = await act(() => updateDepense(edit.id, patch), 'Dépense modifiée');
    if (r.ok) setEdit(null);
  };

  const CatSelect = ({ value, onChange }: { value: string; onChange: (v: string) => void }) => (
    <Select value={value} onChange={e => onChange(e.target.value)}>{cats.map(c => <option key={c.id}>{c.name}</option>)}</Select>
  );

  return (
    <>
      <div className="grid grid-cols-3 gap-3 mb-4">
        <KpiCard label="Total (filtre actif)" value={fmtFCFA(total)} color="text-red-500" />
        <KpiCard label="Entrées" value={String(filtered.length)} />
        <KpiCard label="Type principal" value={topCat} />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white border border-zinc-200 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
            <span className="text-sm font-medium">Historique</span>
            <Select value={filter} onChange={e => setFilter(e.target.value)} style={{ width: 170 }}>
              <option value="all">Tous les types</option>
              {cats.map(c => <option key={c.id}>{c.name}</option>)}
            </Select>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead><tr>{['Date', 'Type', 'Description', 'Montant', ''].map(h => <th key={h} className="text-left text-[10px] font-medium text-zinc-400 uppercase pb-2 border-b border-zinc-100 pr-3">{h}</th>)}</tr></thead>
              <tbody>
                {filtered.map(d => {
                  const cc = CAT_COLORS[d.category] ?? CAT_COLORS.Autres;
                  return (
                    <tr key={d.id} className="border-b border-zinc-100 last:border-0">
                      <td className="py-2 pr-3 text-zinc-400">{d.date.slice(5).split('-').reverse().join('/')}</td>
                      <td className="pr-3"><span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: cc.bg, color: cc.text }}>{d.category}</span></td>
                      <td className="pr-3 text-zinc-500">{d.description}</td>
                      <td className="pr-3 font-medium text-right">{fmtFCFA(d.amount)}</td>
                      <td><div className="flex gap-1">
                        <button onClick={() => setEdit({ id: d.id, category: d.category, description: d.description, amount: String(d.amount), date: d.date })} aria-label="Modifier" className="w-7 h-7 rounded border border-orange-200 bg-orange-50 text-xs cursor-pointer hover:bg-orange-100">✏</button>
                        <button onClick={() => setConfirm({ open: true, id: d.id, name: d.description })} aria-label="Supprimer" className="w-7 h-7 rounded border border-zinc-200 bg-white text-xs cursor-pointer hover:border-red-400 hover:text-red-500">🗑</button>
                      </div></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white border border-zinc-200 rounded-xl p-4 h-fit">
          <div className="text-sm font-medium mb-3">Ajouter une dépense</div>
          <div className="flex flex-col gap-3">
            <Field label="Type de dépense"><CatSelect value={form.category} onChange={v => setForm(f => ({ ...f, category: v }))} /></Field>
            <button onClick={onManageTypes} className="text-[10px] text-orange-600 underline text-left cursor-pointer bg-transparent border-none -mt-1">Gérer les types de dépense →</button>
            <Field label="Description"><Input value={form.description} maxLength={200} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Ex : bouteille de gaz" /></Field>
            <Field label="Montant (FCFA)"><Input type="number" min={1} value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} /></Field>
            <Field label="Date"><Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} /></Field>
            <BtnPrimary onClick={add} className="w-full justify-center">+ Enregistrer</BtnPrimary>
          </div>
        </div>
      </div>

      <Modal open={!!edit} title="Modifier la dépense" onClose={() => setEdit(null)}
        footer={<><BtnSecondary onClick={() => setEdit(null)}>Annuler</BtnSecondary><BtnPrimary onClick={saveEdit}>Enregistrer</BtnPrimary></>}>
        {edit && <>
          <Field label="Type"><CatSelect value={edit.category} onChange={v => setEdit({ ...edit, category: v })} /></Field>
          <Field label="Description"><Input value={edit.description} onChange={e => setEdit({ ...edit, description: e.target.value })} /></Field>
          <Field label="Montant (FCFA)"><Input type="number" value={edit.amount} onChange={e => setEdit({ ...edit, amount: e.target.value })} /></Field>
          <Field label="Date"><Input type="date" value={edit.date} onChange={e => setEdit({ ...edit, date: e.target.value })} /></Field>
        </>}
      </Modal>
      <Confirm open={confirm.open} title="Supprimer cette dépense ?" message={`« ${confirm.name} » sera définitivement supprimée.`}
        onConfirm={async () => { await act(() => deleteDepense(confirm.id), 'Dépense supprimée'); setConfirm(c => ({ ...c, open: false })); }}
        onCancel={() => setConfirm(c => ({ ...c, open: false }))} />
    </>
  );
};
