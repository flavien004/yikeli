// ============================================================
// YIKÉLI — Espace administrateur (src/components/admin/AdminPage.tsx)
// ============================================================
import React, { useState } from 'react';
import { CommandesTab } from './CommandesTab';
import { PaiementsTab } from './PaiementsTab';
import { MenuTab } from './MenuTab';
import { IngredientsTab } from './IngredientsTab';
import { DepensesTab } from './DepensesTab';
import { EmployesTab } from './EmployesTab';
import { JournalTab } from './JournalTab';
import { ComptaTab } from './ComptaTab';
import { ConfigTab } from './ConfigTab';

type Tab = 'commandes' | 'paiements' | 'menu' | 'ingredients' | 'depenses' | 'employes' | 'journal' | 'compta' | 'config';

const TABS: { id: Tab; label: string }[] = [
  { id: 'commandes', label: '📋 Commandes' },
  { id: 'paiements', label: '💰 Paiements' },
  { id: 'menu', label: '🍽 Menu & stock' },
  { id: 'ingredients', label: '🥬 Ingrédients' },
  { id: 'depenses', label: '📉 Dépenses' },
  { id: 'employes', label: '👥 Employés' },
  { id: 'journal', label: '📒 Journal' },
  { id: 'compta', label: '📊 Comptabilité' },
  { id: 'config', label: '⚙️ Configuration' },
];

export const AdminPage: React.FC = () => {
  const [tab, setTab] = useState<Tab>('commandes');
  return (
    <div className="flex flex-col h-full">
      <div className="bg-white border-b border-zinc-200 px-4 flex gap-1 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-3 py-3 text-xs font-medium border-b-2 cursor-pointer whitespace-nowrap transition-colors ${tab === t.id ? 'border-orange-500 text-orange-600' : 'border-transparent text-zinc-500 hover:text-orange-600'}`}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto p-5">
        {tab === 'commandes' && <CommandesTab />}
        {tab === 'paiements' && <PaiementsTab />}
        {tab === 'menu' && <MenuTab />}
        {tab === 'ingredients' && <IngredientsTab />}
        {tab === 'depenses' && <DepensesTab onManageTypes={() => setTab('config')} />}
        {tab === 'employes' && <EmployesTab />}
        {tab === 'journal' && <JournalTab />}
        {tab === 'compta' && <ComptaTab />}
        {tab === 'config' && <ConfigTab />}
      </div>
    </div>
  );
};
