// ============================================================
// YIKÉLI — Interface client (publique, sans compte)
// Parcours : 1) Menu & panier  2) Coordonnées  3) Paiement souhaité
// Le prix, le stock et le total sont recalculés par le serveur.
// ============================================================
import React, { useMemo, useState } from 'react';
import type { PaymentMethod } from '../../types';
import { usePublicMenu } from '../../hooks/usePublicMenu';
import { fmtFCFA, METHOD_LABELS, sendWhatsApp } from '../../utils';
import { act } from '../../lib/act';
import { BtnPrimary, BtnSecondary, Field, Input, ProductImage, Textarea, showToast } from '../shared';

interface CartLine { platId: string; name: string; price: number; qty: number; maxQty: number; }

const WHATSAPP_RESTAURANT = '2250501149244';

export const ClientPage: React.FC = () => {
  const { plats, loading, error, reload, placeOrder } = usePublicMenu();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState<'all' | 'PLATS_IVOIRIENS' | 'BOISSONS'>('all');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [nom, setNom] = useState('');
  const [tel, setTel] = useState('');
  const [adresse, setAdresse] = useState('');
  const [quartier, setQuartier] = useState('');
  const [specs, setSpecs] = useState('');
  const [mode, setMode] = useState<PaymentMethod | ''>('');
  const [montantEspeces, setMontantEspeces] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ total: number } | null>(null);

  const visible = useMemo(() => plats.filter(p =>
    (cat === 'all' || p.category === cat) &&
    (!search || p.name.toLowerCase().includes(search.toLowerCase()))
  ), [plats, cat, search]);

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const nbArticles = cart.reduce((s, i) => s + i.qty, 0);
  const remis = parseFloat(montantEspeces) || 0;
  const rendu = mode === 'ESPECE' && remis > total ? remis - total : 0;

  const addToCart = (platId: string) => {
    const p = plats.find(x => x.id === platId);
    if (!p || !p.available) return;
    const inCart = cart.find(i => i.platId === platId)?.qty ?? 0;
    if (inCart + 1 > p.maxQty) { showToast(`${p.name} : quantité maximale atteinte`); return; }
    setCart(prev => prev.some(i => i.platId === platId)
      ? prev.map(i => i.platId === platId ? { ...i, qty: i.qty + 1 } : i)
      : [...prev, { platId, name: p.name, price: p.price, qty: 1, maxQty: p.maxQty }]);
  };

  const changeQty = (platId: string, delta: number) => {
    if (delta > 0) { addToCart(platId); return; }
    setCart(prev => prev.map(i => i.platId === platId ? { ...i, qty: i.qty - 1 } : i).filter(i => i.qty > 0));
  };

  const goStep2 = () => { if (cart.length === 0) { showToast('Ajoutez au moins un plat'); return; } setStep(2); };
  const goStep3 = () => {
    if (nom.trim().length < 2) { showToast('Veuillez saisir votre nom'); return; }
    if (tel.replace(/\D/g, '').length < 8) { showToast('Veuillez saisir un téléphone valide'); return; }
    setStep(3);
  };

  const whatsappMessage = (orderTotal: number) => [
    '*Nouvelle commande — Restaurant Yikéli*', '',
    `Client : ${nom}`, `Téléphone : ${tel}`,
    adresse || quartier ? `Adresse : ${[adresse, quartier].filter(Boolean).join(', ')}` : '',
    '', '*Articles*',
    ...cart.map(i => `• ${i.name} x${i.qty} — ${fmtFCFA(i.price * i.qty)}`),
    '', `*Total : ${fmtFCFA(orderTotal)}*`,
    mode ? `Paiement : ${METHOD_LABELS[mode]}` : '',
    specs ? `Spécifications : ${specs}` : '',
  ].filter(l => l !== '').join('\n');

  const confirmer = async () => {
    if (!mode) { showToast('Choisissez un mode de paiement'); return; }
    setBusy(true);
    const r = await act(() => placeOrder({
      clientName: nom.trim(), clientPhone: tel.trim(),
      clientAddress: [adresse.trim(), quartier.trim()].filter(Boolean).join(' · ') || undefined,
      specs: specs.trim() || undefined, paymentPref: mode,
      items: cart.map(i => ({ platId: i.platId, quantity: i.qty })),
    }));
    setBusy(false);
    if (r.ok) setDone({ total: r.value.total });
    else void reload();            // le stock a peut-être changé : on rafraîchit le menu
  };

  const reset = () => {
    setCart([]); setNom(''); setTel(''); setAdresse(''); setQuartier(''); setSpecs('');
    setMode(''); setMontantEspeces(''); setStep(1); setDone(null); void reload();
  };

  if (done) {
    return (
      <div className="max-w-md mx-auto p-6 text-center">
        <div className="w-14 h-14 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-2xl mx-auto mb-4">✓</div>
        <h2 className="text-lg font-medium mb-2">Commande envoyée !</h2>
        <p className="text-xs text-zinc-500 mb-1">Total à régler : <strong>{fmtFCFA(done.total)}</strong></p>
        <p className="text-xs text-zinc-500 mb-5">Merci {nom}. Le restaurant vous contactera au {tel}.</p>
        <div className="flex flex-col gap-2">
          <BtnSecondary onClick={() => sendWhatsApp(WHATSAPP_RESTAURANT, whatsappMessage(done.total))} className="justify-center py-2.5">
            📲 Envoyer le récapitulatif par WhatsApp
          </BtnSecondary>
          <BtnPrimary onClick={reset} className="justify-center py-2.5">Nouvelle commande</BtnPrimary>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto p-4">
      <div className="bg-orange-500 rounded-xl p-5 text-white text-center mb-4">
        <div className="text-xl font-medium">Restaurant Yikéli</div>
        <div className="text-xs opacity-90">Plats ivoiriens · Djorogobité 1, 206 · Abidjan</div>
      </div>

      <div className="flex items-center gap-2 mb-5 text-[11px]">
        {['Menu', 'Coordonnées', 'Paiement'].map((label, i) => {
          const n = (i + 1) as 1 | 2 | 3;
          return (
            <React.Fragment key={label}>
              <div className={`flex items-center gap-1.5 ${step === n ? 'text-orange-600' : step > n ? 'text-zinc-600' : 'text-zinc-400'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-medium border ${step === n ? 'bg-orange-500 text-white border-orange-500' : 'border-zinc-300'}`}>{n}</span>
                {label}
              </div>
              {i < 2 && <div className="flex-1 h-px bg-zinc-200" />}
            </React.Fragment>
          );
        })}
      </div>

      {step === 1 && (
        <>
          <Input placeholder="Rechercher un plat…" value={search} onChange={e => setSearch(e.target.value)} />
          <div className="flex gap-2 my-3 flex-wrap">
            {(['all', 'PLATS_IVOIRIENS', 'BOISSONS'] as const).map(c => (
              <button key={c} onClick={() => setCat(c)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border cursor-pointer ${cat === c ? 'bg-orange-500 text-white border-orange-500' : 'bg-white border-zinc-300 text-zinc-500'}`}>
                {c === 'all' ? 'Tout' : c === 'PLATS_IVOIRIENS' ? 'Cuisine ivoirienne' : 'Boissons fraîches'}
              </button>
            ))}
          </div>

          {loading && <div className="text-center text-xs text-zinc-400 py-8">Chargement du menu…</div>}
          {error && (
            <div className="text-center text-xs text-red-600 py-6">
              {error} <button onClick={() => void reload()} className="underline cursor-pointer bg-transparent border-none text-red-600">Réessayer</button>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 mb-4">
            {visible.map(p => (
              <button key={p.id} disabled={!p.available} onClick={() => addToCart(p.id)}
                className={`text-left relative bg-white border rounded-xl overflow-hidden ${!p.available ? 'opacity-40 cursor-not-allowed border-zinc-200' : 'cursor-pointer border-zinc-200 hover:border-orange-400'}`}>
                <ProductImage src={p.imageUrl} name={p.name} category={p.category} className="w-full h-28" />
                <div className="p-3">
                  <div className="text-xs font-medium mb-1">{p.name}</div>
                  <div className="text-sm font-medium text-orange-500">{fmtFCFA(p.price)}</div>
                  {!p.available && <div className="text-[10px] text-red-500 mt-1">Rupture</div>}
                  {p.lowStock && <div className="text-[10px] text-amber-600 mt-1 animate-pulse">Bientôt épuisé !</div>}
                </div>
                {p.available && <span className="absolute top-2 right-2 w-6 h-6 rounded-full bg-orange-500 text-white text-base flex items-center justify-center leading-none shadow">+</span>}
              </button>
            ))}
          </div>

          <div className="bg-white border border-zinc-200 rounded-xl p-4">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Mon panier</span>
              <span className="text-[11px] text-zinc-400">{nbArticles} article{nbArticles > 1 ? 's' : ''}</span>
            </div>
            {cart.length === 0 ? (
              <div className="text-center text-xs text-zinc-400 py-4">Sélectionnez des plats ci-dessus</div>
            ) : cart.map(i => (
              <div key={i.platId} className="flex items-center gap-2 py-2 border-b border-zinc-100 last:border-0 text-xs">
                <span className="flex-1 font-medium">{i.name}</span>
                <button onClick={() => changeQty(i.platId, -1)} className="w-6 h-6 rounded-full border border-orange-300 bg-orange-50 text-orange-700 cursor-pointer">−</button>
                <span className="w-4 text-center">{i.qty}</span>
                <button onClick={() => changeQty(i.platId, 1)} className="w-6 h-6 rounded-full border border-orange-300 bg-orange-50 text-orange-700 cursor-pointer">+</button>
                <span className="w-16 text-right font-medium">{fmtFCFA(i.price * i.qty)}</span>
              </div>
            ))}
            {cart.length > 0 && (
              <>
                <div className="flex justify-between text-sm font-medium pt-3"><span>Total</span><span className="text-orange-500">{fmtFCFA(total)}</span></div>
                <BtnPrimary onClick={goStep2} className="w-full justify-center mt-3">Continuer →</BtnPrimary>
              </>
            )}
          </div>
        </>
      )}

      {step === 2 && (
        <div className="bg-white border border-zinc-200 rounded-xl p-4 flex flex-col gap-3">
          <div className="text-sm font-medium">Vos coordonnées</div>
          <Field label="Nom complet *"><Input value={nom} maxLength={100} onChange={e => setNom(e.target.value)} placeholder="Ex : Kouassi Amani" /></Field>
          <Field label="Téléphone *"><Input type="tel" value={tel} maxLength={30} onChange={e => setTel(e.target.value)} placeholder="Ex : +225 07 12 34 56" /></Field>
          <Field label="Adresse de livraison"><Input value={adresse} maxLength={120} onChange={e => setAdresse(e.target.value)} placeholder="Ex : Cocody Angré 8ème tranche" /></Field>
          <Field label="Quartier / Commune"><Input value={quartier} maxLength={60} onChange={e => setQuartier(e.target.value)} placeholder="Ex : Cocody, Yopougon…" /></Field>
          <Field label="Spécifications de commande" hint="Allergies, sans piment, heure souhaitée, instructions…">
            <Textarea rows={3} maxLength={500} value={specs} onChange={e => setSpecs(e.target.value)} placeholder="Ex : sans piment, livraison avant 13h" />
          </Field>
          <div className="flex gap-2">
            <BtnSecondary onClick={() => setStep(1)} className="flex-1 justify-center">← Retour</BtnSecondary>
            <BtnPrimary onClick={goStep3} className="flex-[2] justify-center">Paiement →</BtnPrimary>
          </div>
        </div>
      )}

      {step === 3 && (
        <>
          <div className="bg-white border border-zinc-200 rounded-xl p-4 mb-3 text-xs">
            <div className="text-sm font-medium mb-2">Récapitulatif</div>
            {cart.map(i => (
              <div key={i.platId} className="flex justify-between py-1 border-b border-zinc-100 last:border-0">
                <span>{i.name} <span className="text-zinc-400">x{i.qty}</span></span><span className="font-medium">{fmtFCFA(i.price * i.qty)}</span>
              </div>
            ))}
            <div className="flex justify-between text-sm font-medium pt-2"><span>Total estimé</span><span className="text-orange-500">{fmtFCFA(total)}</span></div>
            <div className="mt-3 pt-3 border-t border-zinc-100 text-zinc-500 leading-relaxed">
              {nom} · {tel}
              {(adresse || quartier) && <div>{[adresse, quartier].filter(Boolean).join(', ')}</div>}
              {specs && <div className="text-amber-600">📝 {specs}</div>}
            </div>
          </div>

          <div className="bg-white border border-zinc-200 rounded-xl p-4">
            <div className="text-sm font-medium mb-1">Mode de paiement souhaité</div>
            <div className="text-[10px] text-zinc-400 mb-2">Le paiement est encaissé par le restaurant à la remise de la commande.</div>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {(Object.keys(METHOD_LABELS) as PaymentMethod[]).map(m => (
                <button key={m} onClick={() => setMode(m)}
                  className={`py-2.5 rounded-lg text-xs font-medium border cursor-pointer ${mode === m ? 'border-orange-400 bg-orange-100 text-orange-700' : 'border-zinc-200 bg-zinc-50 text-zinc-500 hover:border-orange-300'}`}>
                  {METHOD_LABELS[m]}
                </button>
              ))}
            </div>
            {mode === 'ESPECE' && (
              <Field label="Montant que vous remettrez" hint={rendu > 0 ? `Monnaie à vous rendre : ${fmtFCFA(rendu)}` : undefined}>
                <Input type="number" value={montantEspeces} onChange={e => setMontantEspeces(e.target.value)} placeholder={`≥ ${total}`} />
              </Field>
            )}
            <div className="flex gap-2 mt-3">
              <BtnSecondary onClick={() => setStep(2)} className="flex-1 justify-center">← Retour</BtnSecondary>
              <BtnPrimary onClick={confirmer} disabled={busy} className="flex-[2] justify-center">{busy ? 'Envoi…' : '✓ Confirmer la commande'}</BtnPrimary>
            </div>
          </div>
        </>
      )}

      <BtnSecondary onClick={() => sendWhatsApp(WHATSAPP_RESTAURANT, "Bonjour Yikéli, j'ai une question.")} className="w-full justify-center mt-4 py-2.5">
        📲 Aide via WhatsApp · +225 05 01 14 92 44
      </BtnSecondary>
    </div>
  );
};
