import { useCallback, useEffect, useState } from 'react';
import type { CommandeItem, PaymentMethod, PublicPlat } from '../types';
import { api, ApiError } from '../lib/api';

export interface PublicOrderInput {
  clientName: string;
  clientPhone: string;
  clientAddress?: string;
  specs?: string;
  paymentPref?: PaymentMethod;
  items: { platId: string; quantity: number }[];
}
export interface PublicOrderResult { id: string; total: number; status: string; items: CommandeItem[]; }

export function usePublicMenu() {
  const [plats, setPlats] = useState<PublicPlat[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      const r = await api<{ plats: PublicPlat[] }>('/api/public/menu', { auth: false });
      setPlats(r.plats);
      setError(null);
    } catch (e) {
      const code = e instanceof ApiError ? e.code : 'réseau';
      setError(`Impossible de charger le menu (${code}).`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  const placeOrder = (input: PublicOrderInput) =>
    api<PublicOrderResult>('/api/public/orders', { method: 'POST', body: input, auth: false });

  return { plats, loading, error, reload, placeOrder };
}
