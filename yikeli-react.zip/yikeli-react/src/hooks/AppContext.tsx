import React, { createContext, useContext } from 'react';
import { useAppStore, type AppStore } from './useAppStore';

const AppContext = createContext<AppStore | null>(null);

/** À monter UNIQUEMENT quand l'utilisateur est authentifié (charge /api/bootstrap). */
export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const store = useAppStore();
  return <AppContext.Provider value={store}>{children}</AppContext.Provider>;
};

export const useApp = (): AppStore => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp doit être utilisé dans <AppProvider>');
  return ctx;
};
