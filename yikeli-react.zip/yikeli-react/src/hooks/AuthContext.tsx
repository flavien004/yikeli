// Session : au chargement on tente de la restaurer via le cookie refresh (HttpOnly).
// Rien n'est écrit dans localStorage / sessionStorage.
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { SessionUser } from '../types';
import { api, refreshSession, setAccessToken, SESSION_EXPIRED_EVENT, type SessionPayload } from '../lib/api';

type Status = 'loading' | 'anon' | 'authed';
interface AuthCtx {
  status: Status;
  user: SessionUser | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const Ctx = createContext<AuthCtx | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [status, setStatus] = useState<Status>('loading');
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    let alive = true;
    refreshSession().then(s => {
      if (!alive) return;
      setUser(s?.user ?? null);
      setStatus(s ? 'authed' : 'anon');
    });
    const onExpired = () => { setAccessToken(null); setUser(null); setStatus('anon'); };
    window.addEventListener(SESSION_EXPIRED_EVENT, onExpired);
    return () => { alive = false; window.removeEventListener(SESSION_EXPIRED_EVENT, onExpired); };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const s = await api<SessionPayload>('/api/auth/login', { method: 'POST', body: { email, password }, auth: false });
    setAccessToken(s.accessToken);
    setUser(s.user);
    setStatus('authed');
  }, []);

  const logout = useCallback(async () => {
    try { await api('/api/auth/logout', { method: 'POST', auth: false }); } catch { /* cookie purgé côté serveur si possible */ }
    setAccessToken(null);
    setUser(null);
    setStatus('anon');
  }, []);

  return <Ctx.Provider value={{ status, user, login, logout }}>{children}</Ctx.Provider>;
};

export const useAuth = (): AuthCtx => {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth doit être utilisé dans <AuthProvider>');
  return c;
};
