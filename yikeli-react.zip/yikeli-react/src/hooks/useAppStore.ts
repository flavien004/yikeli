// ============================================================
// Store connecté à l'API : le serveur est la source de vérité.
// Aucune persistance locale (ni localStorage, ni mot de passe, ni jeton).
// Après chaque écriture on recharge les données pour refléter stock, statuts, soldes.
// ============================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import type {
  AppData, Commande, Depense, ExpCategory, Ingredient, MouvementManuel,
  OrderStatus, PaymentMethod, Plat, User, UserRole,
} from '../types';
import { api } from '../lib/api';
import { useAuth } from './AuthContext';

const EMPTY: AppData = {
  plats: [], users: [], clients: [], commandes: [], paiements: [], depenses: [],
  expCategories: [], mouvementsManuel: [], ingredients: [], ingredientMovements: [], soldeInitial: 0,
};

export interface PlatInput {
  name: string; price: number; category: Plat['category']; isActive: boolean; isStocked: boolean;
  stock: number; lowStockAlert: number; expirationDelay?: string; imageUrl?: string | null;
}
export interface UserInput { name: string; email: string; phone?: string; role: UserRole; isActive?: boolean; password?: string; }
export interface StaffOrderInput {
  clientName?: string; type: 'SUR_PLACE' | 'LIVRAISON';
  items: { platId: string; quantity: number }[];
  payments: { method: PaymentMethod; amount: number }[];
}
export interface IngredientInput { name: string; unit: string; lowStockAlert: number; supplier?: string; }

const POLL_MS = 30_000;

export function useAppStore() {
  const { user } = useAuth();
  const [state, setState] = useState<AppData>(EMPTY);
  const [loading, setLoading] = useState(true);
  const alive = useRef(true);

  const reload = useCallback(async () => {
    const d = await api<AppData>('/api/bootstrap');
    if (alive.current) setState({ ...EMPTY, ...d });
  }, []);

  useEffect(() => {
    alive.current = true;
    setLoading(true);
    reload().catch(() => undefined).finally(() => alive.current && setLoading(false));
    // Rafraîchissement périodique (nouvelles commandes en ligne) quand l'onglet est visible
    const t = setInterval(() => { if (document.visibilityState === 'visible') reload().catch(() => undefined); }, POLL_MS);
    return () => { alive.current = false; clearInterval(t); };
  }, [reload, user?.id]);

  const mutate = useCallback(async <T,>(fn: () => Promise<T>): Promise<T> => {
    const r = await fn();
    await reload();
    return r;
  }, [reload]);

  const send = <T = unknown>(path: string, method: string, body?: unknown) => api<T>(path, { method, body });

  return {
    state, loading, reload,

    savePlat: (id: string | null, p: Partial<PlatInput>) =>
      mutate(() => id ? send<Plat>(`/api/plats/${id}`, 'PATCH', p) : send<Plat>('/api/plats', 'POST', p)),
    deletePlat: (id: string) => mutate(() => send(`/api/plats/${id}`, 'DELETE')),

    saveUser: (id: string | null, u: Partial<UserInput>) =>
      mutate(() => id ? send<User>(`/api/users/${id}`, 'PATCH', u) : send<User>('/api/users', 'POST', u)),
    deleteUser: (id: string) => mutate(() => send(`/api/users/${id}`, 'DELETE')),

    createStaffOrder: (o: StaffOrderInput) => mutate(() => send<Commande>('/api/orders', 'POST', o)),
    setOrderStatus: (id: string, status: Exclude<OrderStatus, 'EN_COURS' | 'PAYEE'>, reason?: string) =>
      mutate(() => send<Commande>(`/api/orders/${id}/status`, 'PATCH', { status, reason })),
    deleteCommande: (id: string) => mutate(() => send(`/api/orders/${id}`, 'DELETE')),

    addPaiement: (commandeId: string, method: PaymentMethod, amount: number) =>
      mutate(() => send('/api/payments', 'POST', { commandeId, method, amount })),
    deletePaiement: (id: string) => mutate(() => send(`/api/payments/${id}`, 'DELETE')),

    addDepense: (d: Omit<Depense, 'id' | 'ingredientMovementId'>) => mutate(() => send<Depense>('/api/expenses', 'POST', d)),
    updateDepense: (id: string, d: Partial<Omit<Depense, 'id'>>) => mutate(() => send<Depense>(`/api/expenses/${id}`, 'PATCH', d)),
    deleteDepense: (id: string) => mutate(() => send(`/api/expenses/${id}`, 'DELETE')),

    saveCategory: (id: string | null, name: string) =>
      mutate(() => id ? send<ExpCategory>(`/api/exp-categories/${id}`, 'PATCH', { name }) : send<ExpCategory>('/api/exp-categories', 'POST', { name })),
    deleteCategory: (id: string) => mutate(() => send(`/api/exp-categories/${id}`, 'DELETE')),

    addMouvement: (m: Pick<MouvementManuel, 'date' | 'type' | 'libelle' | 'montant'>) =>
      mutate(() => send<MouvementManuel>('/api/movements', 'POST', m)),
    deleteMouvement: (id: string) => mutate(() => send(`/api/movements/${id}`, 'DELETE')),
    saveSoldeInitial: (soldeInitial: number) => mutate(() => send('/api/settings', 'PATCH', { soldeInitial })),

    saveIngredient: (id: string | null, i: Partial<IngredientInput> & { isActive?: boolean }) =>
      mutate(() => id ? send<Ingredient>(`/api/ingredients/${id}`, 'PATCH', i) : send<Ingredient>('/api/ingredients', 'POST', i)),
    deleteIngredient: (id: string) => mutate(() => send(`/api/ingredients/${id}`, 'DELETE')),
    supplyIngredient: (id: string, s: { quantity: number; unitCost: number; supplier?: string; note?: string; recordExpense: boolean }) =>
      mutate(() => send(`/api/ingredients/${id}/supply`, 'POST', s)),
    adjustIngredient: (id: string, a: { delta: number; note: string }) =>
      mutate(() => send(`/api/ingredients/${id}/adjust`, 'POST', a)),

    uploadImage: async (img: { contentType: string; dataBase64: string }) =>
      (await send<{ url: string }>('/api/admin/upload-image', 'POST', img)).url,
  };
}

export type AppStore = ReturnType<typeof useAppStore>;
