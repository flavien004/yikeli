import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/index.css';

// Purge des données laissées par d'anciennes versions (état complet persisté en clair).
try { localStorage.removeItem('yikeli_app_state'); } catch { /* stockage indisponible */ }

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
