// ============================================================
// YIKÉLI — Types partagés avec l'API (src/types/index.ts)
// Aucun champ de mot de passe n'existe côté client.
// ============================================================
export type PlatCategory = 'PLATS_IVOIRIENS' | 'BOISSONS';
export type UserRole = 'ADMIN' | 'CHEF' | 'CAISSIER';
export type OrderType = 'SUR_PLACE' | 'EN_LIGNE' | 'LIVRAISON';
export type OrderStatus = 'EN_COURS' | 'ACCEPTEE' | 'SERVIE' | 'PAYEE' | 'ANNULEE';
export type PaymentMethod = 'ESPECE' | 'WAVE' | 'ORANGE_MONEY' | 'DJAMO' | 'MTN_MONEY';

export interface Plat {
  id: string;
  name: string;
  price: number;
  category: PlatCategory;
  isActive: boolean;
  isStocked: boolean;
  stock: number;
  lowStockAlert: number;
  expirationDelay?: string;
  imageUrl?: string;
}

/** Plat tel que vu par un client (pas de niveau de stock exact). */
export interface PublicPlat {
  id: string;
  name: string;
  price: number;
  category: PlatCategory;
  imageUrl?: string;
  available: boolean;
  maxQty: number;
  lowStock: boolean;
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  isActive: boolean;
  email?: string;
  phone?: string;
}

export interface SessionUser { id: string; name: string; role: UserRole; }

export interface Client {
  id: string;
  name: string;
  phone?: string;
  address?: string;
  totalSpent: number;
  createdAt: string;
}

export interface CommandeItem {
  id: string;
  platId: string;
  platName: string;
  quantity: number;
  unitPrice: number;
}

export interface Commande {
  id: string;
  clientId?: string;
  clientName: string;
  clientPhone?: string;
  clientAddress?: string;
  items: CommandeItem[];
  total: number;
  type: OrderType;
  status: OrderStatus;
  specs?: string;
  paymentPref?: PaymentMethod;
  cancelReason?: string;
  createdAt: string;
}

export interface Paiement {
  id: string;
  commandeId: string;
  userId: string;
  amount: number;
  method: PaymentMethod;
  createdAt: string;
}

export interface Depense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  ingredientMovementId?: string;
}

export interface ExpCategory { id: string; name: string; isSystem: boolean; }

export type MouvementType = 'RECETTE' | 'DEPENSE';
export interface MouvementManuel {
  id: string;
  date: string;
  type: MouvementType;
  libelle: string;
  montant: number;
  source: 'manuel';
}

export interface Ingredient {
  id: string;
  name: string;
  unit: string;
  stock: number;
  lowStockAlert: number;
  lastUnitCost: number;
  supplier?: string;
  isActive: boolean;
}

export interface IngredientMovement {
  id: string;
  ingredientId: string;
  type: 'APPROVISIONNEMENT' | 'AJUSTEMENT';
  quantity: number;
  unitCost?: number;
  supplier?: string;
  note?: string;
  stockAfter: number;
  createdAt: string;
}

export interface AppData {
  plats: Plat[];
  users: User[];
  clients: Client[];
  commandes: Commande[];
  paiements: Paiement[];
  depenses: Depense[];
  expCategories: ExpCategory[];
  mouvementsManuel: MouvementManuel[];
  ingredients: Ingredient[];
  ingredientMovements: IngredientMovement[];
  soldeInitial: number;
}
