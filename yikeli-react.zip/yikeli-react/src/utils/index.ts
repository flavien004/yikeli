// ============================================================
// YIKÉLI — Utilitaires (src/utils/index.ts)
// ============================================================
import type { Commande, Paiement, PaymentMethod } from '../types';

/** Formate un nombre en FCFA lisible */
export const fmtFCFA = (n: number): string =>
  Math.round(n).toLocaleString('fr-FR') + ' F';

/** Génère un identifiant unique léger */
export const uid = (): string =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

/** Libellés des modes de paiement */
export const METHOD_LABELS: Record<PaymentMethod, string> = {
  ESPECE:       'Espèces',
  WAVE:         'Wave',
  ORANGE_MONEY: 'Orange Money',
  DJAMO:        'Djamo',
  MTN_MONEY:    'MTN Money',
};

/** Couleurs par mode */
export const METHOD_COLORS: Record<PaymentMethod, string> = {
  ESPECE:       '#888780',
  WAVE:         '#1D9E75',
  ORANGE_MONEY: '#EF9F27',
  DJAMO:        '#378ADD',
  MTN_MONEY:    '#D85A30',
};

/** Catégories de dépenses avec couleurs */
export const CAT_COLORS: Record<string, { bg: string; text: string }> = {
  Provisions:  { bg: '#FFF0E6', text: '#C75F0A' },
  Salaires:    { bg: '#E6F1FB', text: '#185FA5' },
  Loyer:       { bg: '#FCEBEB', text: '#A32D2D' },
  Factures:    { bg: '#FAEEDA', text: '#854F0B' },
  Transport:   { bg: '#EAF3DE', text: '#3B6D11' },
  Livraison:   { bg: '#E1F5EE', text: '#085041' },
  Taxes:       { bg: '#EEEDFE', text: '#3C3489' },
  Réparations: { bg: '#FAECE7', text: '#993C1D' },
  Autres:      { bg: '#F1EFE8', text: '#5F5E5A' },
};

/** Calcule le montant total payé pour une commande */
export const getPaidAmount = (commandeId: string, paiements: Paiement[]): number =>
  paiements
    .filter(p => p.commandeId === commandeId)
    .reduce((sum, p) => sum + p.amount, 0);

/** Calcule le reste à payer */
export const getRemaining = (commande: Commande, paiements: Paiement[]): number =>
  Math.max(0, commande.total - getPaidAmount(commande.id, paiements));

/** Formate une date ISO en date courte FR */
export const formatDateShort = (iso: string): string =>
  new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });

/** Formate une date ISO en date longue FR */
export const formatDateLong = (iso: string): string =>
  new Date(iso).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

/** Formate l'heure d'une date ISO */
export const formatTime = (iso: string): string =>
  new Date(iso).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

/** Vérifie si une date YYYY-MM-DD est dans une plage */
export const inRange = (date: string, start: string, end: string): boolean =>
  date >= start && date <= end;

/** Exporte un tableau de lignes en CSV et déclenche le téléchargement */
export const downloadCSV = (rows: string[][], filename: string): void => {
  const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
};

/** Déclenche l'impression du composant ciblé par classe body */
export const printByClass = (bodyClass: string): void => {
  if (window.self !== window.top) {
    alert('Veuillez ouvrir l\'application dans un onglet autonome pour imprimer.');
    return;
  }
  document.body.classList.add(bodyClass);
  window.print();
  document.body.classList.remove(bodyClass);
};

/** Envoie le récapitulatif d'une commande via WhatsApp */
export const sendWhatsApp = (phone: string, message: string): void => {
  const encoded = encodeURIComponent(message);
  window.open(`https://wa.me/${phone.replace(/\D/g, '')}?text=${encoded}`, '_blank');
};

/** Détecte si l'app tourne dans un iframe */
export const isInIframe = (): boolean => window.self !== window.top;
