import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { SignJWT } from 'jose';

process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-123456';
process.env.ACCESS_TOKEN_TTL_SECONDS = '1';
process.env.REFRESH_TOKEN_TTL_SECONDS = '604800';

let A: typeof import('../netlify/lib/auth');
before(async () => { A = await import('../netlify/lib/auth'); });

const user = { id: '11111111-1111-4111-8111-111111111111', role: 'ADMIN' as const, name: 'Test' };
const key = (s: string) => new TextEncoder().encode(s);

test('JWT : signature puis vérification', async () => {
  const t = await A.signAccessToken(user);
  const u = await A.verifyAccessToken(t);
  assert.equal(u.id, user.id);
  assert.equal(u.role, 'ADMIN');
});

test('JWT : un jeton expiré est refusé', async () => {
  const t = await A.signAccessToken(user);
  await new Promise(r => setTimeout(r, 2200));
  await assert.rejects(() => A.verifyAccessToken(t), /Session expirée/);
});

test('JWT : signature falsifiée refusée', async () => {
  const t = await A.signAccessToken(user);
  const tampered = t.slice(0, -4) + (t.endsWith('AAAA') ? 'BBBB' : 'AAAA');
  await assert.rejects(() => A.verifyAccessToken(tampered));
});

test('JWT : jeton signé avec un autre secret refusé', async () => {
  const forged = await new SignJWT({ role: 'ADMIN', name: 'x' }).setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id).setIssuer('yikeli').setAudience('yikeli-api').setExpirationTime('1h').sign(key('another-secret-another-secret-123456789'));
  await assert.rejects(() => A.verifyAccessToken(forged));
});

test('JWT : mauvaise audience refusée', async () => {
  const t = await new SignJWT({ role: 'ADMIN', name: 'x' }).setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id).setIssuer('yikeli').setAudience('autre').setExpirationTime('1h').sign(key(process.env.JWT_SECRET!));
  await assert.rejects(() => A.verifyAccessToken(t));
});

test('JWT : algorithme « none » refusé', async () => {
  const b64 = (o: object) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const t = `${b64({ alg: 'none', typ: 'JWT' })}.${b64({ sub: user.id, role: 'ADMIN', iss: 'yikeli', aud: 'yikeli-api', exp: 9999999999 })}.`;
  await assert.rejects(() => A.verifyAccessToken(t));
});

test('JWT : rôle inconnu refusé', async () => {
  const t = await new SignJWT({ role: 'ROOT', name: 'x' }).setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id).setIssuer('yikeli').setAudience('yikeli-api').setExpirationTime('1h').sign(key(process.env.JWT_SECRET!));
  await assert.rejects(() => A.verifyAccessToken(t));
});

test('Mot de passe : hash bcrypt, jamais le clair', async () => {
  const h = await A.hashPassword('Mot-de-passe-12');
  assert.ok(h.startsWith('$2'));
  assert.ok(!h.includes('Mot-de-passe-12'));
  assert.equal(await A.verifyPassword('Mot-de-passe-12', h), true);
  assert.equal(await A.verifyPassword('mauvais', h), false);
  assert.equal(await A.verifyPassword('x', undefined), false); // utilisateur inconnu
});

test('Refresh token : aléatoire, haché en SHA-256', () => {
  const a = A.newRefreshToken(), b = A.newRefreshToken();
  assert.notEqual(a, b);
  assert.ok(a.length >= 64);
  assert.match(A.sha256(a), /^[0-9a-f]{64}$/);
});

test('Cookie refresh : HttpOnly, Secure, SameSite=Strict, chemin restreint', () => {
  const c = A.refreshCookie('abc');
  for (const flag of ['HttpOnly', 'Secure', 'SameSite=Strict', 'Path=/api/auth', 'Max-Age=604800']) {
    assert.ok(c.includes(flag), flag);
  }
  assert.ok(A.clearRefreshCookie().includes('Max-Age=0'));
});

test('Lecture de cookie', () => {
  const req = new Request('http://x', { headers: { cookie: 'a=1; yikeli_rt=tok%20en; b=2' } });
  assert.equal(A.readCookie(req, 'yikeli_rt'), 'tok en');
  assert.equal(A.readCookie(req, 'absent'), undefined);
});

test('authenticate : en-tête Bearer requis', async () => {
  await assert.rejects(() => A.authenticate(new Request('http://x')), /Authentification requise/);
  const t = await A.signAccessToken(user);
  const u = await A.authenticate(new Request('http://x', { headers: { authorization: `Bearer ${t}` } }));
  assert.equal(u.id, user.id);
});
