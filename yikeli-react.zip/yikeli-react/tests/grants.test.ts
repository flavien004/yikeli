// Reproduit « permission denied for table users » (Supabase ≥ mai 2026 : plus de droits par défaut)
// avec les vrais rôles anon / authenticated / service_role, et vérifie le correctif.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PGlite } from '@electric-sql/pglite';

const read = (f: string) => readFileSync(new URL(`../supabase/migrations/${f}`, import.meta.url), 'utf8');
const MIGRATION = read('001_init.sql');
const FIX = read('003_grants_service_role.sql');
const WITHOUT_GRANTS = MIGRATION.slice(0, MIGRATION.indexOf('-- ── Droits'));   // l'ancienne migration : aucun droit accordé

async function project(sql: string) {
  const pg = new PGlite();
  // Comme un projet Supabase récent : rôles présents, AUCUN droit par défaut sur les nouvelles tables
  await pg.exec(`
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    grant usage on schema public to anon, authenticated, service_role;`);
  await pg.exec(sql);
  return pg;
}
const as = async (pg: PGlite, role: string, sql: string) => {
  await pg.exec(`set role ${role}`);
  try { return await pg.query(sql); } finally { await pg.exec('reset role'); }
};

test('Reproduction : sans les droits explicites, service_role reçoit « permission denied for table users »', async () => {
  const pg = await project(WITHOUT_GRANTS);
  await assert.rejects(() => as(pg, 'service_role', 'select * from users'), /permission denied for table users/);
  await assert.rejects(
    () => as(pg, 'service_role', "insert into users(name,email,role,password_hash) values ('A','a@x.ci','ADMIN','h')"),
    /permission denied for table users/);
});

test('Correctif 003 appliqué sur une base existante : service_role fonctionne', async () => {
  const pg = await project(WITHOUT_GRANTS);
  await pg.exec(FIX);
  await as(pg, 'service_role', "insert into users(name,email,role,password_hash) values ('Admin','a@x.ci','ADMIN','h')");
  const r = await as(pg, 'service_role', "select email from users where email='a@x.ci'");
  assert.equal(r.rows.length, 1);
  // fonctions transactionnelles appelables
  await as(pg, 'service_role', "insert into plats(name,price,category) values ('Bissap',500,'BOISSONS')");
  const plat: any = (await as(pg, 'service_role', 'select id from plats limit 1')).rows[0];
  const cmd: any = (await as(pg, 'service_role',
    `select create_order('{"type":"SUR_PLACE","items":[{"plat_id":"${plat.id}","quantity":2}]}'::jsonb) as id`)).rows[0];
  assert.ok(cmd.id);
  await as(pg, 'service_role', "update plats set price = 600");
  await as(pg, 'service_role', "delete from login_attempts");
});

test('Nouvelle installation (001 seule) : droits déjà accordés', async () => {
  const pg = await project(MIGRATION);
  await as(pg, 'service_role', "insert into users(name,email,role,password_hash) values ('Admin','a@x.ci','ADMIN','h')");
  await as(pg, 'service_role', "select * from refresh_tokens");
  await as(pg, 'service_role', "insert into login_attempts(email) values ('a@x.ci')");   // séquence d'identité
});

test('Le correctif est idempotent et couvre les futures tables', async () => {
  const pg = await project(MIGRATION);
  await pg.exec(FIX); await pg.exec(FIX);
  await pg.exec('create table public.futur (id int)');
  await as(pg, 'service_role', 'select * from futur');
});

test('SÉCURITÉ : anon et authenticated n’ont accès à rien (tables ni fonctions)', async () => {
  const pg = await project(MIGRATION);
  await pg.exec(FIX);
  for (const role of ['anon', 'authenticated']) {
    for (const t of ['users', 'refresh_tokens', 'plats', 'commandes', 'paiements', 'depenses', 'ingredients', 'app_settings']) {
      await assert.rejects(() => as(pg, role, `select * from ${t}`), /permission denied/, `${role} lit ${t}`);
    }
    await assert.rejects(() => as(pg, role, "select create_order('{}'::jsonb)"), /permission denied for function/, `${role} appelle create_order`);
    await assert.rejects(() => as(pg, role, "select rotate_refresh_token('a','b',now(),'ua')"), /permission denied for function/);
  }
});
