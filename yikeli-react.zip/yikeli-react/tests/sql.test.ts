// Exécute la VRAIE migration dans PostgreSQL (PGlite) et teste les règles métier.
import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PGlite } from '@electric-sql/pglite';

let pg: PGlite;
let userId: string, steak: string, jus: string, inactive: string, ingA: string;

const q = async <T = any>(sql: string, params: any[] = []) => (await pg.query<T>(sql, params)).rows;
const one = async <T = any>(sql: string, params: any[] = []) => (await q<T>(sql, params))[0];
const fails = async (sql: string, params: any[], re: RegExp) =>
  assert.rejects(() => pg.query(sql, params), re);
const order = (items: any[], extra: any = {}) =>
  one<{ create_order: string }>('select create_order($1::jsonb)', [JSON.stringify({ type: 'SUR_PLACE', client_name: 'Test', items, cashier_id: userId, ...extra })]);

before(async () => {
  pg = new PGlite();
  await pg.exec(readFileSync(new URL('../supabase/migrations/001_init.sql', import.meta.url), 'utf8'));
  userId = (await one("insert into users(name,email,role,password_hash) values ('Caissier','c@x.ci','CAISSIER','h') returning id")).id;
  steak = (await one("insert into plats(name,price,category,is_stocked,stock,low_stock_alert) values ('Kedjenou',4000,'PLATS_IVOIRIENS',true,5,2) returning id")).id;
  jus = (await one("insert into plats(name,price,category) values ('Bissap',500,'BOISSONS') returning id")).id;
  inactive = (await one("insert into plats(name,price,category,is_active) values ('Ancien',1000,'BOISSONS',false) returning id")).id;
  ingA = (await one("insert into ingredients(name,unit,stock) values ('Poisson','kg',1) returning id")).id;
});

test('La migration crée le schéma et les types de dépense de base', async () => {
  const cats = await q('select name, is_system from exp_categories order by name');
  assert.ok(cats.some(c => c.name === 'Provisions' && c.is_system));
  assert.equal((await q('select * from pg_tables where schemaname=$1 and not rowsecurity', ['public'])).length, 0, 'RLS active partout');
});

test('create_order : prix et total calculés par la base, stock décrémenté', async () => {
  const { create_order: id } = await order([{ plat_id: steak, quantity: 2 }, { plat_id: jus, quantity: 3 }]);
  const c = await one('select * from commandes where id=$1', [id]);
  assert.equal(c.total, 2 * 4000 + 3 * 500);
  assert.equal(c.status, 'EN_COURS');
  assert.equal((await one('select stock from plats where id=$1', [steak])).stock, 3);
  assert.equal((await q('select * from commande_items where commande_id=$1', [id])).length, 2);
});

test('create_order : stock insuffisant → erreur et AUCUNE écriture', async () => {
  const before = (await one('select count(*)::int n from commandes')).n;
  await fails('select create_order($1::jsonb)', [JSON.stringify({ type: 'SUR_PLACE', client_name: 'X', client_phone: '0700000001', items: [{ plat_id: steak, quantity: 4 }] })], /stock_insufficient:Kedjenou/);
  assert.equal((await one('select count(*)::int n from commandes')).n, before);
  assert.equal((await one("select count(*)::int n from clients where phone='0700000001'")).n, 0);
  assert.equal((await one('select stock from plats where id=$1', [steak])).stock, 3);
});

test('create_order : lignes dupliquées regroupées (pas de contournement du stock)', async () => {
  await fails('select create_order($1::jsonb)', [JSON.stringify({ type: 'SUR_PLACE', items: [{ plat_id: steak, quantity: 2 }, { plat_id: steak, quantity: 2 }] })], /stock_insufficient/);
});

test('create_order : plat inactif ou quantité invalide refusés', async () => {
  await fails('select create_order($1::jsonb)', [JSON.stringify({ type: 'SUR_PLACE', items: [{ plat_id: inactive, quantity: 1 }] })], /plat_unavailable/);
  await fails('select create_order($1::jsonb)', [JSON.stringify({ type: 'SUR_PLACE', items: [{ plat_id: jus, quantity: 0 }] })], /invalid_quantity/);
  await fails('select create_order($1::jsonb)', [JSON.stringify({ type: 'SUR_PLACE', items: [{ plat_id: jus, quantity: 101 }] })], /invalid_quantity/);
  await fails('select create_order($1::jsonb)', [JSON.stringify({ type: 'PIRATE', items: [{ plat_id: jus, quantity: 1 }] })], /invalid_type/);
});

test('Paiement complet à la création → statut PAYEE, excédent = monnaie (non enregistré)', async () => {
  const { create_order: id } = await order([{ plat_id: jus, quantity: 2 }], { payments: [{ method: 'ESPECE', amount: 5000 }] });
  const c = await one('select * from commandes where id=$1', [id]);
  assert.equal(c.status, 'PAYEE');
  assert.equal((await one('select sum(amount)::int s from paiements where commande_id=$1', [id])).s, 1000);
});

test('Le statut PAYEE n’est posé QUE par les paiements (partiels puis solde)', async () => {
  const { create_order: id } = await order([{ plat_id: jus, quantity: 4 }]);       // 2000
  let r = (await one('select add_payment($1,$2,$3,$4) r', [id, 'WAVE', 500, userId])).r;
  assert.equal(r.status, 'EN_COURS'); assert.equal(r.remaining, 1500);
  r = (await one('select add_payment($1,$2,$3,$4) r', [id, 'DJAMO', 9999, userId])).r;   // dépasse le solde
  assert.equal(r.status, 'PAYEE'); assert.equal(r.applied, 1500); assert.equal(r.remaining, 0);
  await fails('select add_payment($1,$2,$3,$4)', [id, 'WAVE', 100, userId], /already_paid/);
  await fails('select add_payment($1,$2,$3,$4)', [id, 'BITCOIN', 100, userId], /invalid_method/);
  await fails('select add_payment($1,$2,$3,$4)', [id, 'WAVE', -5, userId], /invalid_amount/);
});

test('set_order_status ne permet pas de poser PAYEE ni de modifier une commande payée', async () => {
  const { create_order: id } = await order([{ plat_id: jus, quantity: 1 }]);
  await fails('select set_order_status($1,$2)', [id, 'PAYEE'], /invalid_status/);
  await pg.query('select set_order_status($1,$2)', [id, 'SERVIE']);
  await pg.query('select add_payment($1,$2,$3,$4)', [id, 'ESPECE', 500, userId]);
  assert.equal((await one('select status from commandes where id=$1', [id])).status, 'PAYEE');
  await fails('select set_order_status($1,$2)', [id, 'SERVIE'], /invalid_transition/);
});

test('delete_payment : la commande n’est plus « Payée »', async () => {
  const { create_order: id } = await order([{ plat_id: jus, quantity: 1 }], { payments: [{ method: 'WAVE', amount: 500 }] });
  const pm = await one('select id from paiements where commande_id=$1', [id]);
  await pg.query('select delete_payment($1)', [pm.id]);
  assert.equal((await one('select status from commandes where id=$1', [id])).status, 'EN_COURS');
});

test('cancel_order : stock restauré ; refusé si des paiements existent', async () => {
  const stockBefore = (await one('select stock from plats where id=$1', [steak])).stock;
  const { create_order: id } = await order([{ plat_id: steak, quantity: 2 }]);
  assert.equal((await one('select stock from plats where id=$1', [steak])).stock, stockBefore - 2);
  await pg.query('select cancel_order($1,$2)', [id, 'Client parti']);
  assert.equal((await one('select stock from plats where id=$1', [steak])).stock, stockBefore);
  const c = await one('select status, cancel_reason from commandes where id=$1', [id]);
  assert.equal(c.status, 'ANNULEE'); assert.equal(c.cancel_reason, 'Client parti');
  await fails('select cancel_order($1,$2)', [id, 'encore'], /already_cancelled/);

  const { create_order: paid } = await order([{ plat_id: jus, quantity: 1 }], { payments: [{ method: 'WAVE', amount: 500 }] });
  await fails('select cancel_order($1,$2)', [paid, 'x'], /order_has_payments/);
  await fails('select delete_order($1)', [paid], /order_has_payments/);
});

test('Rotation du refresh token : ok → course tolérée → réutilisation = révocation totale', async () => {
  const ins = (h: string) => pg.query("insert into refresh_tokens(user_id,token_hash,expires_at) values ($1,$2, now() + interval '1 day')", [userId, h]);
  await ins('h1');
  const rot = (o: string, n: string) => one('select * from rotate_refresh_token($1,$2, now() + interval \'1 day\', $3)', [o, n, 'ua']);

  assert.equal((await rot('h1', 'h2')).out_outcome, 'ok');
  assert.equal((await rot('h1', 'h3')).out_outcome, 'raced');            // dans la fenêtre de 10 s
  assert.equal((await rot('inconnu', 'h9')).out_outcome, 'invalid');

  await pg.query("update refresh_tokens set revoked_at = now() - interval '1 minute' where token_hash='h1'");
  assert.equal((await rot('h1', 'h4')).out_outcome, 'reused');           // rejeu tardif = vol probable
  const live = await one("select count(*)::int n from refresh_tokens where user_id=$1 and revoked_at is null", [userId]);
  assert.equal(live.n, 0, 'toutes les sessions révoquées');
  assert.equal((await rot('h2', 'h5')).out_outcome, 'reused');           // même le jeton « valide » est mort

  await ins('hexp');
  await pg.query("update refresh_tokens set expires_at = now() - interval '1 second' where token_hash='hexp'");
  assert.equal((await rot('hexp', 'h6')).out_outcome, 'expired');
});

test('Approvisionnement : stock, historique, dépense Provisions optionnelle', async () => {
  await pg.query('select supply_ingredient($1,$2,$3,$4,$5,$6,$7)', [ingA, 2.5, 2000, 'Marché', 'Livraison', userId, true]);
  const ing = await one('select * from ingredients where id=$1', [ingA]);
  assert.equal(Number(ing.stock), 3.5);
  assert.equal(Number(ing.last_unit_cost), 2000);
  assert.equal(ing.supplier, 'Marché');
  const dep = await one("select * from depenses where category='Provisions' and description like 'Approvisionnement : Poisson%'");
  assert.equal(dep.amount, 5000);
  const mov = await one('select * from ingredient_movements where ingredient_id=$1', [ingA]);
  assert.equal(Number(mov.stock_after), 3.5);

  await pg.query('select supply_ingredient($1,$2,$3,$4,$5,$6,$7)', [ingA, 1, 2000, '', '', userId, false]);
  assert.equal((await q("select * from depenses where description like 'Approvisionnement : Poisson%'")).length, 1, 'pas de dépense si désactivé');
  await fails('select supply_ingredient($1,$2,$3,$4,$5,$6,$7)', [ingA, 0, 1, '', '', userId, true], /invalid_quantity/);
});

test('Ajustement : motif obligatoire, stock jamais négatif', async () => {
  await fails('select adjust_ingredient($1,$2,$3,$4)', [ingA, -1, '  ', userId], /note_required/);
  await fails('select adjust_ingredient($1,$2,$3,$4)', [ingA, -100, 'Inventaire', userId], /stock_negative/);
  await pg.query('select adjust_ingredient($1,$2,$3,$4)', [ingA, -0.5, 'Perte', userId]);
  assert.equal(Number((await one('select stock from ingredients where id=$1', [ingA])).stock), 4);
});

test('Types de dépense : suppression refusée si utilisé, renommage en cascade', async () => {
  await pg.query("insert into exp_categories(name) values ('Gaz')");
  await pg.query("insert into depenses(category,description,amount,date) values ('Gaz','Bouteille',7000,current_date)");
  await assert.rejects(() => pg.query("delete from exp_categories where name='Gaz'"), /violates foreign key/);
  await pg.query("update exp_categories set name='Gaz cuisine' where name='Gaz'");
  assert.equal((await one("select category from depenses where description='Bouteille'")).category, 'Gaz cuisine');
  await assert.rejects(() => pg.query("insert into depenses(category,description,amount,date) values ('Inexistant','x',1,current_date)"), /violates foreign key/);
});

test('Ingrédient avec historique : suppression refusée (archivage requis)', async () => {
  await assert.rejects(() => pg.query('delete from ingredients where id=$1', [ingA]), /violates foreign key/);
});
