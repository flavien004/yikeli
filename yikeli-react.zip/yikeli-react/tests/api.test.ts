// Teste le routeur de l'API de bout en bout (sans réseau) : droits, validation, auth JWT + refresh.
// Supabase est simulé par un faux `fetch` en mémoire (tables users / refresh_tokens / login_attempts).
import { test, before, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import bcrypt from 'bcryptjs';

process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-123456';
process.env.SUPABASE_URL = 'http://supabase.test';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-key';

type Row = Record<string, any>;
const db = { users: [] as Row[], refresh_tokens: [] as Row[], login_attempts: [] as Row[] };
let handler: (req: Request, ctx: any) => Promise<Response>;
let signAccess: typeof import('../netlify/lib/auth').signAccessToken;

const sha = (s: string) => createHash('sha256').update(s).digest('hex');
const ADMIN = { id: '11111111-1111-4111-8111-111111111111', name: 'Admin', role: 'ADMIN' as const };
const STAFF = { id: '22222222-2222-4222-8222-222222222222', name: 'Caisse', role: 'CAISSIER' as const };
const UUID = '33333333-3333-4333-8333-333333333333';

// ── Faux PostgREST ────────────────────────────────────────────
function matches(row: Row, params: URLSearchParams): boolean {
  for (const [k, v] of params) {
    if (['select', 'order', 'limit', 'on_conflict', 'columns'].includes(k)) continue;
    const [op, ...rest] = v.split('.'); const val = rest.join('.');
    const cell = row[k];
    if (op === 'eq' && String(cell) !== val) return false;
    if (op === 'gte' && !(String(cell) >= val)) return false;
    if (op === 'lt' && !(String(cell) < val)) return false;
    if (op === 'is' && val === 'null' && cell !== null && cell !== undefined) return false;
  }
  return true;
}

globalThis.fetch = (async (input: any, init: any = {}) => {
  const req = input instanceof Request ? input : new Request(input, init);
  const url = new URL(req.url);
  const json = (data: unknown, status = 200, headers: Record<string, string> = {}) =>
    new Response(data === undefined ? null : JSON.stringify(data), { status, headers: { 'content-type': 'application/json', ...headers } });

  const rpc = /\/rest\/v1\/rpc\/(\w+)/.exec(url.pathname);
  if (rpc?.[1] === 'rotate_refresh_token') {
    const b = JSON.parse(await req.text());
    const old = db.refresh_tokens.find(t => t.token_hash === b.p_old_hash);
    if (!old) return json([{ out_user_id: null, out_outcome: 'invalid' }]);
    if (old.revoked_at) {
      db.refresh_tokens.filter(t => t.user_id === old.user_id).forEach(t => (t.revoked_at ??= new Date().toISOString()));
      return json([{ out_user_id: old.user_id, out_outcome: 'reused' }]);
    }
    if (old.expires_at < new Date().toISOString()) return json([{ out_user_id: old.user_id, out_outcome: 'expired' }]);
    db.refresh_tokens.push({ user_id: old.user_id, token_hash: b.p_new_hash, expires_at: b.p_expires, revoked_at: null });
    old.revoked_at = new Date().toISOString();
    return json([{ out_user_id: old.user_id, out_outcome: 'ok' }]);
  }

  const m = /\/rest\/v1\/(\w+)$/.exec(url.pathname);
  if (!m) return json({ message: 'unknown' }, 404);
  const table = (db as any)[m[1]] as Row[];
  if (!table) return json({ message: `table ${m[1]}` }, 404);

  if (req.method === 'HEAD' || req.method === 'GET') {
    const rows = table.filter(r => matches(r, url.searchParams));
    if (req.method === 'HEAD') return new Response(null, { status: 200, headers: { 'content-range': `*/${rows.length}` } });
    return json(rows);
  }
  if (req.method === 'POST') {
    const body = JSON.parse(await req.text());
    (Array.isArray(body) ? body : [body]).forEach(r => table.push({ revoked_at: null, ...r }));
    return new Response(null, { status: 201 });
  }
  if (req.method === 'DELETE') {
    for (let i = table.length - 1; i >= 0; i--) if (matches(table[i], url.searchParams)) table.splice(i, 1);
    return new Response(null, { status: 204 });
  }
  if (req.method === 'PATCH') {
    const patch = JSON.parse(await req.text());
    table.filter(r => matches(r, url.searchParams)).forEach(r => Object.assign(r, patch));
    return new Response(null, { status: 204 });
  }
  return json({}, 405);
}) as typeof fetch;

const call = (method: string, path: string, opts: { body?: unknown; token?: string; cookie?: string; raw?: string } = {}) =>
  handler(new Request(`http://site.test${path}`, {
    method,
    headers: {
      ...(opts.token ? { authorization: `Bearer ${opts.token}` } : {}),
      ...(opts.cookie ? { cookie: opts.cookie } : {}),
      'content-type': 'application/json',
    },
    body: opts.raw ?? (opts.body !== undefined ? JSON.stringify(opts.body) : undefined),
  }), { ip: '1.2.3.4' });

const cookieOf = (res: Response) => /yikeli_rt=([^;]*)/.exec(res.headers.get('set-cookie') ?? '')?.[1];

before(async () => {
  handler = (await import('../netlify/functions/api')).default as any;
  signAccess = (await import('../netlify/lib/auth')).signAccessToken;
});

beforeEach(async () => {
  db.users = [{ id: ADMIN.id, name: 'Admin', email: 'admin@yikeli.ci', role: 'ADMIN', is_active: true, password_hash: await bcrypt.hash('Un-bon-mot-de-passe', 4) }];
  db.refresh_tokens = []; db.login_attempts = [];
});

// ── Routage & droits ──────────────────────────────────────────
test('health, 404 et 405', async () => {
  assert.equal((await call('GET', '/api/health')).status, 200);
  assert.equal((await call('GET', '/api/inconnu')).status, 404);
  assert.equal((await call('DELETE', '/api/health')).status, 405);
});

test('Routes protégées : 401 sans jeton, 401 avec jeton invalide', async () => {
  assert.equal((await call('GET', '/api/bootstrap')).status, 401);
  assert.equal((await call('GET', '/api/bootstrap', { token: 'abc.def.ghi' })).status, 401);
});

test('Un caissier ne peut pas appeler les routes admin (403)', async () => {
  const t = await signAccess(STAFF);
  for (const [m, p] of [['POST', '/api/plats'], ['POST', '/api/users'], ['POST', '/api/exp-categories'], ['POST', '/api/ingredients'],
    ['POST', `/api/ingredients/${UUID}/supply`], ['DELETE', `/api/payments/${UUID}`], ['PATCH', '/api/settings'],
    ['POST', '/api/admin/upload-image'], ['DELETE', `/api/orders/${UUID}`]] as const) {
    assert.equal((await call(m, p, { token: t, body: {} })).status, 403, `${m} ${p}`);
  }
});

test('Un caissier ne peut enregistrer que des dépenses « Provisions »', async () => {
  const t = await signAccess(STAFF);
  const res = await call('POST', '/api/expenses', { token: t, body: { category: 'Loyer', description: 'x', amount: 100, date: '2026-01-01' } });
  assert.equal(res.status, 403);
});

test('Seul un admin peut annuler une commande', async () => {
  const t = await signAccess(STAFF);
  const res = await call('PATCH', `/api/orders/${UUID}/status`, { token: t, body: { status: 'ANNULEE', reason: 'test' } });
  assert.equal(res.status, 403);
});

test('Un admin ne peut pas se supprimer / désactiver / rétrograder lui-même', async () => {
  const t = await signAccess(ADMIN);
  assert.equal((await call('DELETE', `/api/users/${ADMIN.id}`, { token: t })).status, 409);
  assert.equal((await call('PATCH', `/api/users/${ADMIN.id}`, { token: t, body: { isActive: false } })).status, 409);
  assert.equal((await call('PATCH', `/api/users/${ADMIN.id}`, { token: t, body: { role: 'CAISSIER' } })).status, 409);
});

// ── Validation ────────────────────────────────────────────────
test('Validation : entrées invalides rejetées avant tout accès base (400)', async () => {
  const t = await signAccess(ADMIN);
  assert.equal((await call('POST', '/api/plats', { token: t, body: { name: '', price: 100 } })).status, 400);
  assert.equal((await call('POST', '/api/plats', { token: t, body: { name: 'A', price: -5 } })).status, 400);
  assert.equal((await call('POST', '/api/plats', { token: t, body: { name: 'A', price: 1.5 } })).status, 400);
  assert.equal((await call('POST', '/api/users', { token: t, body: { name: 'Bob', email: 'pas-un-email', password: 'longmotdepasse1' } })).status, 400);
  assert.equal((await call('POST', '/api/users', { token: t, body: { name: 'Bob', email: 'b@x.ci', password: 'court' } })).status, 400);
  assert.equal((await call('POST', `/api/ingredients/${UUID}/supply`, { token: t, body: { quantity: -1 } })).status, 400);
  assert.equal((await call('POST', `/api/ingredients/pas-un-uuid/adjust`, { token: t, body: { delta: 1, note: 'abc' } })).status, 400);
  assert.equal((await call('POST', '/api/admin/upload-image', { token: t, body: { contentType: 'image/svg+xml', dataBase64: 'aaaaaaaaaaaa' } })).status, 400);
  assert.equal((await call('POST', '/api/admin/upload-image', { token: t, body: { contentType: 'image/png', dataBase64: Buffer.from('ceci n’est pas une image').toString('base64') } })).status, 400);
});

test('Commande publique : validation (nom, téléphone, articles, quantités)', async () => {
  const ok = { clientName: 'Awa', clientPhone: '0700000000', items: [{ platId: UUID, quantity: 1 }] };
  assert.equal((await call('POST', '/api/public/orders', { body: { ...ok, clientName: 'A' } })).status, 400);
  assert.equal((await call('POST', '/api/public/orders', { body: { ...ok, clientPhone: 'abc' } })).status, 400);
  assert.equal((await call('POST', '/api/public/orders', { body: { ...ok, items: [] } })).status, 400);
  assert.equal((await call('POST', '/api/public/orders', { body: { ...ok, items: [{ platId: 'x', quantity: 1 }] } })).status, 400);
  assert.equal((await call('POST', '/api/public/orders', { body: { ...ok, items: [{ platId: UUID, quantity: 1000 }] } })).status, 400);
  assert.equal((await call('POST', '/api/public/orders', { body: { ...ok, paymentPref: 'BITCOIN' } })).status, 400);
});

test('Corps invalide ou trop volumineux', async () => {
  assert.equal((await call('POST', '/api/auth/login', { raw: '{pas du json' })).status, 400);
  assert.equal((await call('POST', '/api/auth/login', { raw: JSON.stringify({ email: 'a@b.ci', password: 'x'.repeat(5000) }) })).status, 413);
});

// ── Authentification : login → JWT → refresh → rotation ───────
test('Login : mauvais identifiants → 401 générique, comptés ; verrouillage après 5 échecs', async () => {
  for (let i = 0; i < 5; i++) {
    const r = await call('POST', '/api/auth/login', { body: { email: 'admin@yikeli.ci', password: 'faux-mot-de-passe' } });
    assert.equal(r.status, 401);
    assert.equal(((await r.json()) as any).error.message, 'Email ou mot de passe incorrect.');
  }
  const locked = await call('POST', '/api/auth/login', { body: { email: 'admin@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  assert.equal(locked.status, 429, 'même le bon mot de passe est refusé pendant le verrouillage');
});

test('Login : utilisateur inconnu et compte désactivé → même réponse', async () => {
  const unknown = await call('POST', '/api/auth/login', { body: { email: 'inconnu@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  db.users[0].is_active = false;
  const inactive = await call('POST', '/api/auth/login', { body: { email: 'admin@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  assert.equal(unknown.status, 401); assert.equal(inactive.status, 401);
  assert.deepEqual(await unknown.json(), await inactive.json());
});

test('Login réussi : JWT d’accès, cookie refresh HttpOnly, aucun hash dans la réponse', async () => {
  const res = await call('POST', '/api/auth/login', { body: { email: 'ADMIN@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  assert.equal(res.status, 200);
  const body = (await res.json()) as any;
  assert.ok(body.accessToken.split('.').length === 3);
  assert.equal(body.user.role, 'ADMIN');
  assert.ok(!JSON.stringify(body).includes('password'), 'aucun champ mot de passe');
  assert.ok(!JSON.stringify(body).includes('$2'), 'aucun hash bcrypt');
  const sc = res.headers.get('set-cookie')!;
  assert.match(sc, /HttpOnly/); assert.match(sc, /Secure/); assert.match(sc, /SameSite=Strict/); assert.match(sc, /Path=\/api\/auth/);
  const raw = cookieOf(res)!;
  assert.equal(db.refresh_tokens.length, 1);
  assert.equal(db.refresh_tokens[0].token_hash, sha(raw), 'seul le hash du refresh token est stocké');
  assert.ok(!JSON.stringify(db.refresh_tokens).includes(raw), 'jeton en clair jamais stocké');
  // Le JWT obtenu ouvre bien /api/auth/me
  const me = await call('GET', '/api/auth/me', { token: body.accessToken });
  assert.equal(me.status, 200);
  assert.equal(((await me.json()) as any).user.email, 'admin@yikeli.ci');
});

test('Refresh : nouveau JWT + rotation du cookie ; l’ancien jeton ne sert plus', async () => {
  const login = await call('POST', '/api/auth/login', { body: { email: 'admin@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  const rt1 = cookieOf(login)!;

  const r1 = await call('POST', '/api/auth/refresh', { cookie: `yikeli_rt=${rt1}` });
  assert.equal(r1.status, 200);
  const b1 = (await r1.json()) as any;
  assert.ok(b1.accessToken);
  const rt2 = cookieOf(r1)!;
  assert.notEqual(rt2, rt1, 'refresh token tourné à chaque usage');

  // Rejeu de l'ancien jeton (alors que le nouveau existe) → refus
  const replay = await call('POST', '/api/auth/refresh', { cookie: `yikeli_rt=${rt1}` });
  assert.equal(replay.status, 401);
  assert.match(replay.headers.get('set-cookie') ?? '', /Max-Age=0/, 'cookie effacé');
  // Après réutilisation détectée, toute la famille est révoquée : même le nouveau jeton est mort
  const dead = await call('POST', '/api/auth/refresh', { cookie: `yikeli_rt=${rt2}` });
  assert.equal(dead.status, 401);
});

test('Refresh : sans cookie, cookie inconnu ou compte désactivé → 401', async () => {
  assert.equal((await call('POST', '/api/auth/refresh')).status, 401);
  assert.equal((await call('POST', '/api/auth/refresh', { cookie: 'yikeli_rt=inconnu' })).status, 401);
  const login = await call('POST', '/api/auth/login', { body: { email: 'admin@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  db.users[0].is_active = false;
  assert.equal((await call('POST', '/api/auth/refresh', { cookie: `yikeli_rt=${cookieOf(login)}` })).status, 401);
});

test('Logout : révoque le refresh token et efface le cookie', async () => {
  const login = await call('POST', '/api/auth/login', { body: { email: 'admin@yikeli.ci', password: 'Un-bon-mot-de-passe' } });
  const rt = cookieOf(login)!;
  const out = await call('POST', '/api/auth/logout', { cookie: `yikeli_rt=${rt}` });
  assert.equal(out.status, 200);
  assert.match(out.headers.get('set-cookie') ?? '', /Max-Age=0/);
  assert.equal((await call('POST', '/api/auth/refresh', { cookie: `yikeli_rt=${rt}` })).status, 401);
});
